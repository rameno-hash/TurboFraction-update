/*
 * TurboFraction — Solicitação de TDE (Taxa de Dificuldade de Entrega)
 * Aberta pelo botão "Solicitar TDE" da consulta da remessa (no cartão ou em aba nova):
 * preenche a remessa e clica em Pesquisar. Tipo, valor, descrição e Processar ficam com o usuário.
 * Em todas as telas de TDE: o número da remessa nas tabelas é link para a consulta (outra aba).
 */
(() => {
  'use strict';

  // Tabelas de TDE (ex.: Aprovação): o número da remessa (14 dígitos) vira link para a consulta, em outra aba.
  function linkarRemessas() {
    document.querySelectorAll('tbody[id$="_data"] td').forEach(td => {
      if (td.children.length || td.dataset.tfRem) return;
      const n = (td.textContent || '').trim();
      if (!/^\d{14}$/.test(n)) return;
      td.dataset.tfRem = '1';
      const a = document.createElement('a');
      a.href = location.origin + '/FractionWeb/jad/tracking?cte=' + n;
      a.target = '_blank'; a.rel = 'noopener';
      a.textContent = n;
      a.title = 'Abrir a consulta da remessa ' + n + ' em outra aba';
      a.style.cssText = 'color:#c8102e;font-weight:600;text-decoration:underline';
      a.addEventListener('click', ev => ev.stopPropagation());   // não seleciona a linha da tabela
      td.textContent = ''; td.appendChild(a);
    });
  }
  let tL = 0;
  new MutationObserver(() => { clearTimeout(tL); tL = setTimeout(linkarRemessas, 100); }).observe(document.body, { childList: true, subtree: true });
  linkarRemessas();

  const m = /tf_remessa=(\d{6,})/.exec(location.hash);
  if (!m) return;
  const remessa = m[1].slice(0, 14);
  if (/tf_cartao=1/.test(location.hash)) document.documentElement.classList.add('tf-no-cartao');
  history.replaceState(null, '', location.pathname + location.search);   // não repete ao recarregar

  const F = 'form_taxa_dific_entrega_emissao';
  let n = 0;
  const t = setInterval(() => {
    const campo = document.getElementById(F + ':creCodi'), pesquisar = document.getElementById(F + ':pesquisar');
    if (!campo || !pesquisar) { if (++n > 50) clearInterval(t); return; }
    clearInterval(t);
    campo.value = remessa;
    campo.dispatchEvent(new Event('input', { bubbles: true }));
    campo.dispatchEvent(new Event('change', { bubbles: true }));
    setTimeout(() => pesquisar.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true })), 150);
  }, 200);
})();
