/*
 * TurboFraction — Emissão: botão "🔎 Consultar NF-e".
 * Aparece ao lado do campo Danfe quando a chave digitada é uma chave de NF-e válida (44 dígitos, modelo 55, DV ok).
 * Ao clicar: preenche Nota Fiscal e Série (vêm da própria chave) e abre a consulta da Receita com a chave
 * preenchida; o captcha é do usuário. Quando o resultado aparece, o receita.js devolve os dados e aqui se
 * preenchem Valor, Remetente (CNPJ do emitente) e Destinatário. Se o Fraction não conhecer o remetente ou o
 * destinatário, o card oferece abrir o cadastro já preenchido com os dados da nota (o Salvar é do usuário).
 */
(() => {
  'use strict';
  const PEDIDO = 'tf_nfe_pedido', RESULTADO = 'tf_nfe_resultado';
  const URL_RECEITA = 'https://www.nfe.fazenda.gov.br/portal/consultaRecaptcha.aspx?tipoConsulta=resumo&tipoConteudo=7PhJ+gAVw2g=';
  const PREFIXOS = ['form_emissao', 'form_add_nota'];
  const $ = id => document.getElementById(id);
  const dorme = ms => new Promise(r => setTimeout(r, ms));
  const digitos = s => String(s || '').replace(/\D/g, '');

  function chaveValida(k) {
    if (!/^\d{44}$/.test(k) || k.slice(20, 22) !== '55') return false;
    let s = 0, p = 2;
    for (let i = 42; i >= 0; i--) { s += +k[i] * p; p = p === 9 ? 2 : p + 1; }
    const r = s % 11;
    return (r < 2 ? 0 : 11 - r) === +k[43];
  }
  const daChave = k => ({ numero: String(+k.slice(25, 34)), serie: String(+k.slice(22, 25)), cnpj: k.slice(6, 20) });
  const moeda = v => v == null ? '' : v.toFixed(2).replace('.', ',');
  const fmtDoc = d => { d = digitos(d); return d.length === 14 ? d.replace(/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})$/, '$1.$2.$3/$4-$5') : d.length === 11 ? d.replace(/^(\d{3})(\d{3})(\d{3})(\d{2})$/, '$1.$2.$3-$4') : d; };

  /** Espera o Fraction terminar as requisições ajax (contador do emissao-ajax.js). */
  async function esperarAjax(min = 350, max = 12000) {
    await dorme(min);
    const ini = Date.now();
    if (document.documentElement.dataset.tfAjax == null) { await dorme(1200); return; }
    while (document.documentElement.dataset.tfAjax !== '0' && Date.now() - ini < max) await dorme(120);
    await dorme(120);
  }
  function definir(el, v, evento = true) {
    if (!el) return false;
    el.value = v;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    if (evento) el.dispatchEvent(new Event('change', { bubbles: true }));
    return true;
  }

  // ---------- botão ao lado do Danfe ----------
  // O botão fica na linha do "Adicionar Nota" (se existir); senão, logo depois do campo Danfe.
  function garantirBotoes() {
    PREFIXOS.forEach(pref => {
      const inp = $(pref + ':nova_nota_danfe');
      if (!inp) return;
      const ancora = $(pref + ':add_nota_fiscal') || inp;
      let b = ancora.nextElementSibling;
      if (!b || !b.classList.contains('tf-nfe-btn')) {
        document.querySelectorAll(`.tf-nfe-btn[data-pref="${pref}"]`).forEach(x => x.remove());
        b = document.createElement('button');
        b.type = 'button'; b.className = 'tf-nfe-btn'; b.dataset.pref = pref; b.textContent = '🔎 Consultar NF-e';
        if (ancora !== inp) b.classList.add('tf-nfe-linha');
        b.title = 'Consultar esta NF-e na Receita e importar número, série, valor, remetente e destinatário';
        b.addEventListener('click', e => { e.preventDefault(); e.stopPropagation(); consultar(pref); });
        ancora.insertAdjacentElement('afterend', b);
      }
      if (!inp.dataset.tfNfe) {
        inp.dataset.tfNfe = '1';
        ['input', 'keyup', 'paste', 'change'].forEach(ev => inp.addEventListener(ev, () => setTimeout(atualizarBotoes, 0)));
      }
    });
    atualizarBotoes();
  }
  function atualizarBotoes() {
    PREFIXOS.forEach(pref => {
      const inp = $(pref + ':nova_nota_danfe');
      const b = document.querySelector(`.tf-nfe-btn[data-pref="${pref}"]`);
      if (inp && b) b.hidden = !chaveValida(digitos(inp.value));
    });
  }
  let tObs = 0;
  new MutationObserver(() => { clearTimeout(tObs); tObs = setTimeout(garantirBotoes, 80); }).observe(document.body, { childList: true, subtree: true });
  garantirBotoes();

  // ---------- consulta ----------
  let atual = null;   // { pref, chave, res }

  async function consultar(pref) {
    const chave = digitos(($(pref + ':nova_nota_danfe') || {}).value);
    if (!chaveValida(chave)) return;
    atual = { pref, chave, res: null };
    try { await chrome.storage.local.set({ [PEDIDO]: { chave, quando: Date.now(), popup: true } }); }
    catch (e) { card('erro', 'A extensão foi atualizada — recarregue a página (F5) e tente de novo.'); return; }
    const w = window.open(URL_RECEITA + '#tf_chave=' + chave, 'tf_receita_nfe', 'width=1050,height=820,left=80,top=40');
    card('espera', w ? 'Resolva o captcha na janela da Receita e clique em Continuar. Os dados voltam para cá sozinhos.' : 'O navegador bloqueou a janela da Receita. Libere os pop-ups do Fraction e clique de novo.');
    await esperarAjax();   // o Fraction pode estar respondendo à mudança do campo Danfe
    const d = daChave(chave);
    preencherNota(pref, { numero: d.numero, serie: d.serie });
  }

  function preencherNota(pref, { numero, serie, valor }) {
    if (numero != null) definir($(pref + ':nota_numero'), numero, false);
    if (serie != null) definir($(pref + ':nota_serie'), serie, false);
    if (valor != null) definir($(pref + ':nota_valor'), moeda(valor), false);
  }

  chrome.storage.onChanged.addListener((mud, area) => {
    if (area !== 'local' || !mud[RESULTADO] || !mud[RESULTADO].newValue) return;
    const r = mud[RESULTADO].newValue;
    if (!atual || r.chave !== atual.chave) return;
    aplicar(r);
  });

  const estado = { remetente: '', destinatario: '' };   // 'ok' | 'novo' | 'difere' | 'preenchendo'

  async function aplicar(r) {
    atual.res = r;
    const { pref } = atual;
    await esperarAjax(0);
    preencherNota(pref, { numero: String(+r.numero || r.numero), serie: String(+r.serie || r.serie), valor: r.valor });
    estado.remetente = estado.destinatario = '';
    card('dados');
    if (pref !== 'form_emissao') return;   // remetente/destinatário só existem na tela principal
    for (const tipo of ['remetente', 'destinatario']) {
      const p = tipo === 'remetente' ? r.emitente : r.destinatario;
      const campo = $('form_emissao:' + tipo + '_cnpj_cpf');
      if (p && p.oculto && !p.documento) { estado[tipo] = 'oculto'; continue; }
      if (!p || !p.documento || !campo) continue;
      const atualDoc = digitos(campo.value);
      if (atualDoc && atualDoc !== digitos(p.documento)) { estado[tipo] = 'difere'; continue; }
      if (!atualDoc) { estado[tipo] = 'preenchendo'; card('dados'); definir(campo, digitos(p.documento)); await esperarAjax(); }
      estado[tipo] = conhecido(tipo) ? 'ok' : 'novo';
      card('dados');
    }
    card('dados');
  }
  const conhecido = tipo => !!(($('form_emissao:' + tipo + '_nome_fantasia') || {}).textContent || '').trim();

  async function usarDaNota(tipo) {
    const p = tipo === 'remetente' ? atual.res.emitente : atual.res.destinatario;
    estado[tipo] = 'preenchendo'; card('dados');
    definir($('form_emissao:' + tipo + '_cnpj_cpf'), digitos(p.documento));
    await esperarAjax();
    estado[tipo] = conhecido(tipo) ? 'ok' : 'novo';
    card('dados');
  }

  /** Abre o cadastro (ALT+R / ALT+D) e preenche com os dados da nota. Só campos vazios; o Salvar é do usuário. */
  async function cadastrar(tipo) {
    const p = tipo === 'remetente' ? atual.res.emitente : atual.res.destinatario;
    const botao = $('form_emissao:' + tipo + '_endereco');
    if (!p || !botao) return;
    estado[tipo] = 'cadastrando'; card('dados');
    botao.click();
    await esperarAjax(500);
    const P = id => $('form_pessoa:' + id);
    const vazio = el => el && !el.disabled && !digitos(el.value) && !String(el.value || '').replace(/[\s_().\-/]/g, '');
    const por = (id, v, ev = false) => { const el = P(id); if (v && vazio(el)) definir(el, v, ev); };
    try {
      // Pessoa física / jurídica
      const fis = digitos(p.documento).length === 11;
      const radio = P('pessoa_tipo:' + (fis ? 0 : 1));
      if (radio && !radio.checked) {
        const caixa = radio.closest('.ui-radiobutton');
        const alvo = caixa && caixa.querySelector('.ui-radiobutton-box');
        if (alvo) alvo.click();
        await dorme(150);
        const r2 = P('pessoa_tipo:' + (fis ? 0 : 1));
        if (r2 && !r2.checked) { r2.checked = true; r2.dispatchEvent(new Event('change', { bubbles: true })); }
        await esperarAjax();
      }
      const doc = P('pessoa_cnpj_cpf');
      if (doc && digitos(doc.value) !== digitos(p.documento)) { definir(doc, fmtDoc(p.documento)); await esperarAjax(); }
      por('pessoa_nome_fantasia_inclusao', p.nome.toUpperCase());
      if (p.ie && !/isento/i.test(p.ie)) por('pessoa_ie', p.ie);
      const cep = P('pessoa_cep');
      if (p.cep && vazio(cep)) { definir(cep, p.cep); await esperarAjax(); }
      por('pessoa_endereco', p.logradouro);
      por('pessoa_numero', p.numero);
      por('pessoa_complemento', p.complemento);
      por('pessoa_bairro', p.bairro);
      por('pessoa_cidade', p.cidade);
      por('pessoa_telefone', p.telefone);
      if (p.email && !/@ct\.vtex\.com\.br$/i.test(p.email)) por('pessoa_email', p.email.toLowerCase());
      const uf = P('pessoa_uf_input');
      if (uf && p.uf && !uf.value) { uf.value = p.uf; uf.dispatchEvent(new Event('change', { bubbles: true })); }
      estado[tipo] = 'conferir';
    } catch (e) { console.error('TurboFraction cadastro', e); estado[tipo] = 'erro'; }
    card('dados');
  }

  // ---------- card ----------
  function card(modo, texto) {
    let c = $('tf-nfe-card');
    if (!c) {
      c = document.createElement('div'); c.id = 'tf-nfe-card';
      document.body.appendChild(c);
      c.addEventListener('click', e => {
        const a = e.target.closest('[data-acao]'); if (!a) return;
        const { acao, tipo } = a.dataset;
        if (acao === 'fechar') c.hidden = true;
        if (acao === 'usar') usarDaNota(tipo);
        if (acao === 'cadastrar') cadastrar(tipo);
        if (acao === 'reabrir' && atual) consultar(atual.pref);
      });
    }
    c.hidden = false;
    c.className = 'tf-nfe-' + modo;
    const esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[ch]));
    const topo = (t) => `<div class="tf-nfe-topo"><b>${t}</b><button type="button" data-acao="fechar" title="Fechar">✕</button></div>`;
    if (modo !== 'dados') {
      const d = atual ? daChave(atual.chave) : null;
      c.innerHTML = topo(d ? `NF-e ${d.numero} · série ${d.serie}` : 'Consultar NF-e') +
        `<div class="tf-nfe-msg">${modo === 'espera' ? '⏳ ' : '⚠ '}${esc(texto)}</div>` +
        (modo === 'espera' ? '<div class="tf-nfe-acoes"><button type="button" data-acao="reabrir">Abrir a Receita de novo</button></div>' : '');
      return;
    }
    const r = atual.res;
    const linhaPessoa = (tipo, rot, p) => {
      if (!p) return '';
      const st = estado[tipo];
      let s = '';
      if (atual.pref === 'form_emissao') {
        if (st === 'ok') s = '<span class="tf-ok">✔ preenchido</span>';
        else if (st === 'preenchendo') s = '<span class="tf-esp">preenchendo…</span>';
        else if (st === 'cadastrando') s = '<span class="tf-esp">abrindo o cadastro…</span>';
        else if (st === 'conferir') s = '<span class="tf-ok">cadastro preenchido — confira e clique em Salvar</span>';
        else if (st === 'erro') s = '<span class="tf-err">não consegui preencher o cadastro</span>';
        else if (st === 'novo') s = `<span class="tf-err">não cadastrado no Fraction</span> <button type="button" data-acao="cadastrar" data-tipo="${tipo}">➕ Cadastrar com os dados da NF-e</button>`;
        else if (st === 'oculto') s = '<span class="tf-err">a Receita mostrou esses dados mascarados (consulta resumida) — preencha manualmente</span>';
        else if (st === 'difere') s = `<span class="tf-err">o campo já tem outro CNPJ/CPF</span> <button type="button" data-acao="usar" data-tipo="${tipo}">Usar o da NF-e</button>`;
      }
      return `<div class="tf-nfe-pes"><div class="tf-nfe-rot">${rot}</div><div><b>${esc(p.nome || p.mascara)}</b>${p.documento ? ' · ' + esc(fmtDoc(p.documento)) : ''}<br><small>${esc([p.logradouro, p.numero, p.complemento, p.bairro].filter(Boolean).join(', '))}${p.logradouro || p.bairro ? ' · ' : ''}${esc(p.cidade)}/${esc(p.uf)}${p.cep ? ' · CEP ' + esc(p.cep) : ''}</small>${s ? '<div class="tf-nfe-st">' + s + '</div>' : ''}</div></div>`;
    };
    c.innerHTML = topo(`NF-e ${esc(+r.numero || r.numero)} · série ${esc(+r.serie || r.serie)}`) +
      `<div class="tf-nfe-msg">✔ Nota Fiscal, Série e Valor preenchidos · <b>R$ ${esc(moeda(r.valor))}</b>${r.valorProdutos ? ' <small>(total dos produtos — a consulta resumida não mostra o total da nota)</small>' : ''}${r.volumes ? ` · ${r.volumes} volume(s)` : ''}${r.peso ? ` · ${String(r.peso.toFixed(3)).replace('.', ',')} kg` : ''}${r.emissao ? ` · emitida em ${esc(r.emissao.slice(0, 10))}` : ''}</div>` +
      linhaPessoa('remetente', 'Remetente (emitente)', r.emitente) +
      linhaPessoa('destinatario', 'Destinatário', r.destinatario);
  }
})();
