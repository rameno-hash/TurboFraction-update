/*
 * TurboFraction — ponte para o Lista On Time (que roda no mundo da página e não fala com a extensão).
 * Ctrl + Processar: devolve o Circuit das remessas lendo o arquivo da Performance de Entrega que a
 * extensão já guarda (o mesmo do Painel de Pendências). Nenhum pedido extra ao Fraction.
 */
(() => {
  'use strict';
  let cache = null;   // { quando, mapa: Map(codigo -> circuit) }

  const deBase64 = b64 => { const s = atob(b64), u8 = new Uint8Array(s.length); for (let i = 0; i < s.length; i++) u8[i] = s.charCodeAt(i); return u8; };

  async function mapaDaPerformance() {
    const c = (await chrome.storage.local.get('tf_cache_performance')).tf_cache_performance;
    if (!c || !c.b64) throw new Error('sem_arquivo');
    if (cache && cache.quando === c.quando) return cache;
    const { cabecalho, linhas } = await TFXlsx.lerArquivo(new Blob([deBase64(c.b64)]));
    const col = n => cabecalho.findIndex(h => String(h).trim().toLowerCase() === n);
    const iCod = col('codigo'), iCirc = col('circuit');
    if (iCod < 0 || iCirc < 0) throw new Error('o arquivo da Performance não tem as colunas Codigo / Circuit');
    const mapa = new Map();
    linhas.forEach(l => {
      const cod = String(l[iCod] ?? '').trim();
      if (!cod) return;
      let circ = String(l[iCirc] ?? '').trim();
      if (/^\d+(\.0+)?$/.test(circ)) circ = String(parseInt(circ, 10));
      mapa.set(cod, circ);
    });
    cache = { quando: c.quando, mapa };
    return cache;
  }

  window.addEventListener('message', async ev => {
    if (ev.source !== window || !ev.data || ev.data.tf !== 'circuits-pedido') return;
    const { id, remessas } = ev.data;
    let resp;
    try {
      const { quando, mapa } = await mapaDaPerformance();
      const achados = {};
      (remessas || []).forEach(r => { if (mapa.has(r)) achados[r] = mapa.get(r); });
      resp = { achados, quando };
    } catch (e) { resp = { erro: e.message === 'sem_arquivo' ? 'sem_arquivo' : (e.message || String(e)) }; }
    window.postMessage(Object.assign({ tf: 'circuits-resposta', id }, resp), location.origin);
  });
})();
