// TurboFraction — reimpressão da etiqueta Jadlog (uma etiqueta por volume).
(async () => {
  const id = location.hash.slice(1);
  let d = {};
  try {
    if (id) {
      const v = await chrome.storage.session.get(id);
      d = v[id] || {};
      await chrome.storage.session.remove(id);
    }
  } catch (e) { /* sem dados: etiqueta em branco */ }

  const so = s => String(s || '').replace(/\D/g, '');
  const cep = so(d.destCep);
  const ship = so(d.shipmentId);
  const volumes = Math.max(1, parseInt(d.volumes, 10) || 1);
  const sorter = String(d.codSorter || '').trim();          // ex.: S41
  const mSorter = /^([A-Za-z]+)\s*(\d+)$/.exec(sorter);

  function qrSvg(texto) {
    const q = new TFQRCode(-1, TFQRErrorCorrectLevel.M);
    q.addData(texto); q.make();
    const n = q.getModuleCount();
    let r = '';
    for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) if (q.isDark(y, x)) r += `M${x} ${y}h1v1h-1z`;
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${n} ${n}" shape-rendering="crispEdges"><path d="${r}" fill="#000"/></svg>`;
  }

  const modelo = document.getElementById('modelo');
  const lista = document.getElementById('etiquetas');

  for (let vol = 1; vol <= volumes; vol++) {
    const no = modelo.content.cloneNode(true);
    const etq = no.querySelector('.etq');
    // Modalidade .COM ou EXPRESSO: quadro "JADLOG S 41" com fundo preto e letra branca.
    if (/(^|\W)\.?COM\b|EXPRESS/i.test(d.modalidade || '')) etq.querySelector('.sort').classList.add('invertido');
    const vol3 = String(vol).padStart(3, '0');
    // Barra vertical: número da remessa (CT-e) + volume com 3 dígitos (001, 002, 003...).
    const codVertical = so(d.cte) ? so(d.cte) + vol3 : '';
    // QR: mesmo conteúdo do QR da etiqueta original (shipment $ volume 0 CEP).
    const chaveQr = ship ? `${ship}$${vol3}0${cep}` : '';
    // Barra de baixo: Shipment ID.
    const codBaixo = ship;
    const campos = {
      destNome: d.destNome,
      destEnd: d.destEnd,
      destBairro: d.destBairro,
      destCepCidade: [cep, d.destCidade].filter(Boolean).join(' '),
      destFone: d.destFone,
      cte: d.cte,
      sortLetra: mSorter ? mSorter[1].toUpperCase() : '',
      sortNum: mSorter ? mSorter[2] : sorter,
      volNum: String(vol),
      remNome: d.remNome,
      remDocs: [so(d.remDoc), d.nf ? 'N' + d.nf : '', d.pedido ? 'P' + d.pedido : ''].filter(Boolean).join(' '),
      // Linha de rota: "0 XXX-DDMM-XXX00", com DDMM = dia e mês da previsão de entrega.
      rota: (() => { const m = /(\d{2})\/(\d{2})/.exec(d.previsao || ''); return m ? `0 XXX-${m[1]}${m[2]}-XXX00` : ''; })(),
      shipFmt: ship ? ship.slice(0, 10) + ' ' + ship.slice(10) : '',
      peso: d.peso,
      volume: `${vol}/${volumes}`,
      sorter,
      circuit: d.circuit,
      unidade: d.unidade,
      rodape: [d.emissao, d.unidadeEmissao, codBaixo ? codBaixo.slice(0, 10) + ' ' + codBaixo.slice(10) : ''].filter(Boolean).join('   '),
    };
    for (const [k, v] of Object.entries(campos)) {
      const el = etq.querySelector(`[data-c="${k}"]`);
      if (el) el.textContent = v || '';
    }
    if (codVertical) etq.querySelector('.barra-v').innerHTML = TFCode128.svg(codVertical, { vertical: true, silencio: 0 });
    if (chaveQr) etq.querySelector('.qr').innerHTML = qrSvg(chaveQr);
    if (codBaixo) etq.querySelector('.barra-h').innerHTML = TFCode128.svg(codBaixo, { silencio: 0 });
    lista.appendChild(no);
  }

  // Textos que não cabem: reduz a fonte até caber (nome, endereço e remetente).
  document.querySelectorAll('.d-nome, .d-linha, .rem > div, .unidade').forEach(el => {
    let t = parseFloat(getComputedStyle(el).fontSize);
    while (el.scrollWidth > el.clientWidth + 1 && t > 6) { t -= 0.5; el.style.fontSize = t + 'px'; }
  });

  document.title = 'Etiqueta ' + (d.cte || '') + (volumes > 1 ? ` (${volumes} volumes)` : '');
  document.getElementById('info').textContent =
    `${volumes} etiqueta(s) — 100 × 75 mm. Na impressão, escolha a impressora de etiquetas e o tamanho do papel 100 × 75 mm, margens "Nenhuma".`;
  document.getElementById('imprimir').addEventListener('click', () => window.print());
  setTimeout(() => window.print(), 400);
})();
