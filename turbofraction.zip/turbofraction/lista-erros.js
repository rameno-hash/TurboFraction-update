/*
 * TurboFraction — Nova Lista de Entrega: na janela de inconsistências do "Adicionar",
 * esconde as mensagens que não exigem ação (item já na lista, código inválido, item não
 * localizado). As demais (finalizado/bloqueado, precisa ser devolvida…) aparecem normalmente.
 * Se só sobrarem mensagens ignoradas, a janela nem aparece.
 */
(() => {
  'use strict';
  const IGNORAR = /j.\s+est.\s+na\s+lista|erro\s+valida..o\s+dados|n.o\s+localizado/i;

  function filtrar() {
    const dlg = document.getElementById('errosAddLote');
    const corpo = dlg && dlg.querySelector('tbody.ui-datatable-data');
    if (!corpo || corpo.dataset.tfFiltrado === String(corpo.rows.length) + corpo.textContent.length) return;
    let visiveis = 0;
    [...corpo.rows].forEach(tr => {
      if (tr.classList.contains('ui-datatable-empty-message')) return;
      const desc = (tr.cells[0]?.textContent || '').trim();
      const ign = IGNORAR.test(desc);
      tr.style.display = ign ? 'none' : '';
      if (!ign) {
        tr.classList.toggle('ui-datatable-even', visiveis % 2 === 0);
        tr.classList.toggle('ui-datatable-odd', visiveis % 2 === 1);
        visiveis++;
      }
    });
    corpo.dataset.tfFiltrado = String(corpo.rows.length) + corpo.textContent.length;
    // Nada que exija ação: fecha a janela pelo próprio botão ✕ do Fraction.
    if (!visiveis && corpo.rows.length && getComputedStyle(dlg).display !== 'none') {
      dlg.querySelector('.ui-dialog-titlebar-close')?.click();
      dlg.style.display = 'none';
    }
  }

  let ag = 0;
  new MutationObserver(() => { if (!ag) ag = requestAnimationFrame(() => { ag = 0; filtrar(); }); })
    .observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['style'] });
  filtrar();
})();
