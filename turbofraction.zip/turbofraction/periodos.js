// TurboFraction — Performance de Coleta: atalhos de período (Mês anterior / Mês atual / 30 dias) ao lado da Data Inicial.
// (Mesmo comportamento dos atalhos da Performance de entrega.)
(() => {
  'use strict';
  const dma = d => `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}/${d.getFullYear()}`;

  function campoDoRotulo(rotulo) {
    const re = new RegExp('^' + rotulo + ':?$', 'i');
    const el = [...document.querySelectorAll('label, td, span')].find(e => e.children.length === 0 && re.test((e.textContent || '').trim()));
    if (!el) return null;
    if (el.htmlFor) { const alvo = document.getElementById(el.htmlFor); const inp = alvo && (alvo.matches('input') ? alvo : alvo.querySelector('input[type="text"], input:not([type])')); if (inp) return inp; }
    const linha = el.closest('tr') || el.parentElement;
    return linha && linha.querySelector('input[type="text"], input:not([type])');
  }
  // Preenche sem dar foco ao campo (o foco é o que abre o calendário do Fraction).
  function preencher(campo, valor) {
    Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(campo, valor);
    ['input', 'change'].forEach(t => campo.dispatchEvent(new Event(t, { bubbles: true })));
  }
  function fecharCalendario() {
    const c = document.getElementById('ui-datepicker-div');
    if (c && getComputedStyle(c).display !== 'none') c.style.display = 'none';
    if (document.activeElement && document.activeElement.matches('input.hasDatepicker, .ui-calendar input')) document.activeElement.blur();
  }

  function colocarPeriodos() {
    if (document.getElementById('tf-periodos')) return;
    const ini = campoDoRotulo('Data Inicial'), fim = campoDoRotulo('Data Final');
    if (!ini || !fim) return;
    const caixa = document.createElement('span');
    caixa.id = 'tf-periodos';
    const periodos = [
      ['Mês anterior', h => [new Date(h.getFullYear(), h.getMonth() - 1, 1), new Date(h.getFullYear(), h.getMonth(), 0)]],
      ['Mês atual', h => [new Date(h.getFullYear(), h.getMonth(), 1), h]],
      ['30 dias', h => [new Date(h.getFullYear(), h.getMonth(), h.getDate() - 30), h]],
    ];
    periodos.forEach(([rotulo, periodo]) => {
      const b = document.createElement('button');
      b.type = 'button'; b.className = 'tf-periodo'; b.textContent = rotulo;
      b.addEventListener('mouseenter', () => { const [a, z] = periodo(new Date()); b.title = `${dma(a)} a ${dma(z)}`; });
      b.addEventListener('click', () => {
        const [de, ate] = periodo(new Date());
        preencher(ini, dma(de)); preencher(fim, dma(ate)); fecharCalendario(); setTimeout(fecharCalendario, 50);
        caixa.querySelectorAll('.tf-periodo').forEach(x => x.classList.toggle('tf-periodo-on', x === b));
      });
      caixa.appendChild(b);
    });
    (ini.closest('.ui-calendar') || ini).after(caixa);
  }

  colocarPeriodos();
  let ag = 0;
  new MutationObserver(() => { if (!ag) ag = requestAnimationFrame(() => { ag = 0; colocarPeriodos(); }); })
    .observe(document.body, { childList: true, subtree: true });
})();
