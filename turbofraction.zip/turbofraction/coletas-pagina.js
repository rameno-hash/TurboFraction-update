// TurboFraction — relatório "COLETAS PICKUP" (Performance de Coleta: Pendente + DEPOSITADO NO PUDO, por PUDO).
(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const CHAVE_MOT = 'tf_pudo_motoristas';
  const CIDADES = ['VOLTA REDONDA', 'BARRA MANSA', 'BARRA DO PIRAI', 'RESENDE', 'VALENCA', 'PORTO REAL', 'PINHEIRAL', 'ITATIAIA', 'QUATIS', 'PIRAI', 'RIO CLARO', 'RIO DAS FLORES', 'MENDES', 'ENGENHEIRO PAULO DE FRONTIN', 'PARAIBA DO SUL', 'TRES RIOS', 'VASSOURAS'];
  const sem = t => String(t || '').normalize('NFD').replace(/[̀-ͯ]/g, '').trim().toLowerCase();
  let pudos = [];        // [{pudo, codigo, endereco, cidade, qtd}]
  let motoristas = {};
  let ordem = { col: 'motorista', asc: true };
  let quandoArq = 0, guardado = false, proximaAt = '', periodoTxt = '';

  function carregando(t) { $('carregando').hidden = t == null; $('carregando-texto').textContent = t || ''; }
  function erro(t, diag) {
    carregando(null); $('relatorio').hidden = true;
    const e = $('erro'); e.hidden = false; e.textContent = t;
    if (diag) { const s = document.createElement('small'); s.textContent = 'Caminho: ' + diag; e.appendChild(s); }
  }

  /** "RUA X 123  BAIRRO VOLTA REDONDA/RJ 27281060" -> { endereco: "RUA X 123 BAIRRO", cidade: "VOLTA REDONDA" } */
  function separar(e) {
    e = String(e || '').replace(/\s+/g, ' ').trim();
    const m = /^(.*)\/([A-Z]{2})\s+\d{8}$/.exec(e);
    if (!m) return { endereco: e, cidade: '' };
    const antes = m[1];
    for (const c of [...CIDADES].sort((a, b) => b.length - a.length)) if (antes.endsWith(' ' + c) || antes === c) return { endereco: antes.slice(0, -c.length).trim(), cidade: c };
    const p = antes.lastIndexOf(' ');
    return { endereco: antes.slice(0, p), cidade: antes.slice(p + 1) };
  }

  async function processar(buffer) {
    carregando('Lendo o arquivo…');
    const { cabecalho, linhas } = await TFXlsx.lerArquivo(new Blob([buffer]), t => carregando(t));
    const col = (...nomes) => { for (const n of nomes) { const i = cabecalho.findIndex(h => sem(h) === sem(n)); if (i >= 0) return i; } return -1; };
    const c = { status: col('Status'), desc: col('Descrição', 'Descricao'), razao: col('Razao Local Coleta'), end: col('Endereco Local Coleta', 'Endereço Local Coleta') };
    if (c.status < 0 || c.desc < 0 || c.razao < 0) throw new Error('o arquivo não tem as colunas Status / Descrição / Razao Local Coleta');
    const mapa = new Map();
    linhas.forEach(l => {
      if (sem(l[c.status]) !== 'pendente' || !/depositado no pudo/.test(sem(l[c.desc]))) return;
      const pudo = String(l[c.razao] || '').replace(/\s+/g, ' ').trim() || '(sem PUDO)';
      let x = mapa.get(pudo);
      if (!x) { const s = separar(c.end >= 0 ? l[c.end] : ''); x = { pudo, codigo: (/^(BR\d+)/.exec(pudo) || [])[1] || '', endereco: s.endereco, cidade: s.cidade, qtd: 0 }; mapa.set(pudo, x); }
      x.qtd++;
    });
    pudos = [...mapa.values()];
    try { motoristas = (await chrome.storage.local.get(CHAVE_MOT))[CHAVE_MOT] || {}; } catch (e) { motoristas = {}; }
    desenhar();
  }

  const motDe = p => (p.codigo && motoristas[p.codigo]) || '';
  function ordenar() {
    const f = { pudo: p => p.pudo, endereco: p => p.endereco, cidade: p => p.cidade, qtd: p => p.qtd, motorista: p => motDe(p) }[ordem.col];
    const s = ordem.asc ? 1 : -1;
    pudos.sort((a, b) => {
      if (ordem.col === 'motorista') { const va = motDe(a), vb = motDe(b); if (!va !== !vb) return va ? -1 : 1; }  // sem motorista no fim
      const va = f(a), vb = f(b);
      const r = typeof va === 'number' ? va - vb : String(va).localeCompare(String(vb), 'pt-BR', { numeric: true });
      return r * s || a.pudo.localeCompare(b.pudo, 'pt-BR', { numeric: true });
    });
  }

  // Os motoristas vêm do campo "Motorista" da tela Consultas PUDO (Pickup › Consultas Pudo). Sem motorista: INDEFINIDO.
  const URL_PUDOS = 'https://www.jadlog.com.br/FractionWeb/pages/pickup/transferenciaOrdemColetaConsulta/transferenciaOrdemColetaConsulta.jad';
  try {
    chrome.storage.onChanged.addListener((mud, area) => {
      if (area !== 'local' || !mud[CHAVE_MOT]) return;
      motoristas = mud[CHAVE_MOT].newValue || {};
      if (pudos.length) desenhar();
    });
  } catch (e) { /* ok */ }

  function desenhar() {
    ordenar();
    const hoje = new Date();
    $('data').textContent = `${String(hoje.getDate()).padStart(2, '0')}/${String(hoje.getMonth() + 1).padStart(2, '0')}/${hoje.getFullYear()}`;
    const corpo = $('corpo'); corpo.innerHTML = '';
    let total = 0, ant = null;
    pudos.forEach(p => {
      total += p.qtd;
      const tr = corpo.insertRow();
      const m = motDe(p);
      if (ordem.col === 'motorista' && ant !== null && m !== ant) tr.className = 'motorista-novo';
      ant = m;
      [p.pudo, p.endereco, p.cidade].forEach(v => { tr.insertCell().textContent = v; });
      const q = tr.insertCell(); q.className = 'num'; q.textContent = p.qtd;
      const tdm = tr.insertCell(); tdm.className = 'mot' + (m ? '' : ' vazio');
      if (m) tdm.textContent = m;
      else {
        const a = document.createElement('a');
        a.href = URL_PUDOS; a.target = '_blank'; a.rel = 'noopener';
        a.textContent = 'INDEFINIDO';
        a.title = 'Defina o motorista do PUDO ' + (p.codigo || p.pudo) + ' na tela Consultas PUDO (abre em outra aba)';
        tdm.appendChild(a);
      }
    });
    $('total').textContent = total;
    const q = quandoArq ? new Date(quandoArq) : null;
    const hh = q ? q.toLocaleTimeString('pt-BR').slice(0, 5) : '';
    const diaQ = q && q.toDateString() !== new Date().toDateString() ? ' de ' + q.toLocaleDateString('pt-BR') : '';
    $('origem').textContent = `${pudos.length} PUDO(s) · ${total} coleta(s) depositada(s)` + (periodoTxt ? ` · período: ${periodoTxt}` : '') + (q ? (guardado ? ` · arquivo guardado às ${hh}${diaQ}` : ` · gerado às ${hh}${diaQ}`) + (proximaAt ? ` · próxima atualização do Fraction: ${proximaAt}` : '') : '');
    carregando(null); $('erro').hidden = true; $('relatorio').hidden = false;
  }

  // Ordenar clicando no cabeçalho
  const COLS = ['pudo', 'endereco', 'cidade', 'qtd', 'motorista'];
  document.querySelectorAll('tr.cab th').forEach((th, i) => th.addEventListener('click', () => {
    const col = COLS[i];
    ordem = { col, asc: ordem.col === col ? !ordem.asc : col !== 'qtd' };
    desenhar();
  }));

  // "💾 Baixar arquivo": cópia do arquivo guardado na pasta Downloads.
  let arquivoAtual = null;
  $('baixar-arq').addEventListener('click', () => {
    if (!arquivoAtual) return;
    const q = new Date(arquivoAtual.quando || Date.now()), p = n => String(n).padStart(2, '0');
    const m = /^(.*?)(\.[^.]+)?$/.exec(arquivoAtual.nome);
    const a = document.createElement('a');
    a.href = URL.createObjectURL(arquivoAtual.blob);
    a.download = `${m[1]}_${q.getFullYear()}-${p(q.getMonth() + 1)}-${p(q.getDate())}_${p(q.getHours())}h${p(q.getMinutes())}${m[2] || ''}`;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 10000);
  });
  $('regerar').addEventListener('click', () => { carregando('Gerando de novo…'); $('relatorio').hidden = true; parent.postMessage({ tipo: 'tf-regerar' }, '*'); });
  /** Texto para o WhatsApp: um bloco por motorista, com os PUDOs e a quantidade (sem endereço). */
  function textoWhatsApp() {
    const titulo = s => s;   // mantém como vem do Fraction (maiúsculas)
    const grupos = new Map();
    [...pudos].sort((a, b) => b.qtd - a.qtd).forEach(p => { const m = motDe(p) || ''; if (!grupos.has(m)) grupos.set(m, []); grupos.get(m).push(p); });
    const nomes = [...grupos.keys()].sort((a, b) => (!a) - (!b) || a.localeCompare(b, 'pt-BR'));
    const total = pudos.reduce((t, p) => t + p.qtd, 0);
    const linhas = [`*📦 COLETAS PICKUP — ${$('data').textContent}*`, ''];
    nomes.forEach(m => {
      const lista = grupos.get(m), soma = lista.reduce((t, p) => t + p.qtd, 0);
      linhas.push(`*${m || 'INDEFINIDO'}* — ${soma} coleta(s)`);
      lista.forEach(p => {
        const nome = p.pudo.replace(/^BR\d+\s*/, '');
        linhas.push(`• ${titulo(nome)} (${p.codigo || '—'}): *${p.qtd}*`);
      });
      linhas.push('');
    });
    linhas.push(`Total: *${total}* coleta(s) em ${pudos.length} PUDO(s)`);
    return linhas.join('\n');
  }
  $('copiar').addEventListener('click', async () => {
    const txt = textoWhatsApp();
    try { await navigator.clipboard.writeText(txt); }
    catch (e) { const t = document.createElement('textarea'); t.value = txt; document.body.appendChild(t); t.select(); document.execCommand('copy'); t.remove(); }
    const b = $('copiar'); b.textContent = '✔ Copiado para o WhatsApp'; setTimeout(() => { b.textContent = '💬 Copiar p/ WhatsApp'; }, 1800);
  });

  window.addEventListener('message', async ev => {
    const d = ev.data;
    if (!d || ev.source !== parent) return;
    if (d.tipo === 'tf-status') { if (d.erro) erro(d.texto, d.diag); else { $('erro').hidden = true; $('relatorio').hidden = true; carregando(d.texto); } }
    if (d.tipo === 'tf-coletas' && d.buffer) {
      arquivoAtual = { blob: new Blob([d.buffer.slice(0)]), nome: d.nome || 'Performance de Coleta.zip', quando: d.quando };
      quandoArq = d.quando || Date.now(); guardado = !!d.guardado; proximaAt = d.proxima || ''; periodoTxt = d.periodo || '';
      try { await processar(d.buffer); } catch (e) { console.error(e); erro('Não consegui ler o arquivo: ' + e.message); }
    }
  });
})();
