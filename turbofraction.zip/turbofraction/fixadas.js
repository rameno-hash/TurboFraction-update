/*
 * TurboFraction — Remessas fixadas (📌)
 * Na consulta (tracking), um alfinete ao lado do número do Conhecimento (ou da Ordem de Coleta) guarda a remessa
 * numa lista no lado esquerdo da janela, em todas as telas do Fraction. Mouse no código: dados do destinatário.
 * (remetente, no caso de uma coleta). Clique: abre a consulta de novo. A lista fica guardada no navegador (chrome.storage) e vale para todas as abas.
 */
(() => {
  'use strict';
  if (window.top !== window) return;
  // Tela de login (ou qualquer tela sem o menu do Fraction, ex.: sessão expirada): a lista não aparece.
  if (/login/i.test(location.pathname)) return;
  const logado = () => !!document.querySelector('.ui-menubar');
  const CHAVE = 'tf_fixadas';
  const MAX = 40;
  const txt = el => (el?.textContent || '').replace(/\s+/g, ' ').trim();
  const esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  let lista = [];

  async function ler() { try { lista = (await chrome.storage.local.get(CHAVE))[CHAVE] || []; } catch (e) { lista = []; } }
  async function gravar() { try { await chrome.storage.local.set({ [CHAVE]: lista }); } catch (e) { /* ok */ } }

  /* ---------- Na consulta: número e destinatário ---------- */
  /** Número do Conhecimento (remessa) ou, se não houver, da Ordem de Coleta, com o <label> do valor. */
  function numeroDaTela() {
    if (!/\/jad\/tracking/.test(location.pathname)) return null;
    const rotulos = [...document.querySelectorAll('label')].filter(l => !l.closest('.ui-menu, .ui-menubar'));
    const achar = re => {
      const r = rotulos.find(l => re.test(txt(l)));
      const v = r && r.nextElementSibling;
      const n = v && txt(v).replace(/\D/g, '');
      return n && n.length >= 6 ? { num: n, el: v } : null;
    };
    const cte = achar(/^Conhecimento:$/i);
    if (cte) return { ...cte, tipo: 'remessa' };
    const col = achar(/^Ordem\s+(de\s+)?Coleta:$/i);
    return col ? { ...col, tipo: 'coleta' } : null;
  }
  /** Dados do quadro "Destinatário" (remessa) ou "Remetente" (coleta). */
  function pessoa(tipo) {
    const alvo = tipo === 'coleta' ? /^Remetente/i : /^Destinat/i;
    const titulo = [...document.querySelectorAll('.ui-panel-title')].find(t => alvo.test(txt(t)));
    const painel = titulo && titulo.closest('.ui-panel');
    const d = {};
    if (!painel) return d;
    painel.querySelectorAll('tr').forEach(tr => {
      const c = tr.cells; if (!c || c.length < 2) return;
      const rot = txt(c[0]).replace(/:$/, '').toLowerCase();
      const v = txt(c[1].querySelector('label') || c[1]).replace(/\s*WhatsApp\s*$/i, '');
      if (/^(dest|nome)/.test(rot)) d.nome = v;
      else if (/^end/.test(rot)) d.end = v;
      else if (/^cidade/.test(rot)) d.cidade = v;
      else if (/^bairro/.test(rot)) d.bairro = v;
      else if (/^cep/.test(rot)) d.cep = v;
      else if (/^telefone/.test(rot)) d.fone = v;
      else if (/^(cnpj|cpf)/.test(rot)) d.doc = v;
    });
    return d;
  }

  /** Último evento do quadro "Histórico" da consulta: data, hora, unidade e operação. */
  function ultimoStatus() {
    const corpo = document.querySelector('[id$=":trackHistorico_data"]');
    const linhas = corpo ? [...corpo.rows].filter(tr => tr.cells.length >= 5) : [];
    const u = linhas[linhas.length - 1];
    if (!u) return null;
    const c = [...u.cells].map(td => txt(td));
    return c[4] ? { data: c[1], hora: c[2], unidade: c[3], op: c[4] } : null;
  }
  /** Consulta aberta de uma remessa fixada: atualiza o último status guardado. */
  async function atualizarStatus(num) {
    const st = ultimoStatus();
    const i = lista.find(x => x.num === num);
    if (!st || !i) return;
    const igual = i.status && ['data', 'hora', 'unidade', 'op'].every(k => i.status[k] === st[k]);
    if (igual) return;
    await ler();
    const j = lista.find(x => x.num === num); if (!j) return;
    j.status = st; j.statusEm = Date.now();
    await gravar();
  }

  function colocarAlfinete() {
    const n = numeroDaTela();
    if (!n) return;
    atualizarStatus(n.num);
    let b = document.getElementById('tf-alfinete');
    if (!b) {
      b = document.createElement('button');
      b.id = 'tf-alfinete'; b.type = 'button';
      b.addEventListener('click', alternar);
    }
    // Na linha dos botões (Acareação / TDE / Gerar ocorrência); sem ela, ao lado do número.
    const barra = document.getElementById('tf-ocorrencia')?.parentElement;
    if (barra) { if (b.parentElement !== barra) barra.prepend(b); }
    else if (!b.isConnected) n.el.insertAdjacentElement('afterend', b);
    b.dataset.num = n.num; b.dataset.tipo = n.tipo;
    const fixada = lista.some(x => x.num === n.num);
    b.classList.toggle('fixada', fixada);
    b.textContent = '📌';
    b.title = fixada ? 'Tirar da lista de fixadas' : `Fixar ${n.tipo === 'coleta' ? 'esta coleta' : 'esta remessa'} na lista à esquerda`;
  }
  async function alternar() {
    const b = document.getElementById('tf-alfinete'); if (!b) return;
    await ler();
    const num = b.dataset.num;
    if (lista.some(x => x.num === num)) lista = lista.filter(x => x.num !== num);
    else {
      const st = ultimoStatus();
      lista.unshift({ num, tipo: b.dataset.tipo, ...pessoa(b.dataset.tipo), quando: Date.now(), ...(st ? { status: st, statusEm: Date.now() } : {}) });
      if (lista.length > MAX) lista.length = MAX;
    }
    await gravar();
    desenhar(); colocarAlfinete();
  }

  /* ---------- Lista à esquerda ---------- */
  let caixa = null, card = null, tCard = 0;
  function desenhar() {
    if (!lista.length || !logado()) { caixa?.remove(); caixa = null; card?.remove(); card = null; return; }
    if (!caixa) {
      caixa = document.createElement('aside');
      caixa.id = 'tf-fixadas';
      document.body.appendChild(caixa);
      caixa.addEventListener('click', async ev => {
        const x = ev.target.closest('.tf-fx-tirar');
        if (!x) return;
        ev.preventDefault(); ev.stopPropagation();
        await ler(); lista = lista.filter(i => i.num !== x.dataset.num); await gravar(); desenhar(); colocarAlfinete();
      });
      caixa.addEventListener('mouseover', ev => { const a = ev.target.closest('.tf-fx-item'); if (a) mostrarCard(a); });
      caixa.addEventListener('mouseout', ev => { if (ev.target.closest('.tf-fx-item')) { clearTimeout(tCard); tCard = setTimeout(esconderCard, 150); } });
    }
    const atual = numeroDaTela()?.num;
    caixa.innerHTML = `<div class="tf-fx-topo"><span>📌 Fixadas</span><b>${lista.length}</b></div><div class="tf-fx-lista">` +
      lista.map(i => `<a class="tf-fx-item${i.num === atual ? ' atual' : ''}" href="${location.origin}/FractionWeb/jad/tracking?cte=${encodeURIComponent(i.num)}" data-num="${esc(i.num)}">` +
        `<span class="tf-fx-num">${i.tipo === 'coleta' ? '<i title="Ordem de coleta">C</i>' : ''}${esc(i.num)}</span>` +
        `<span class="tf-fx-nome">${esc(i.nome || '')}</span>` +
        `<button type="button" class="tf-fx-tirar" data-num="${esc(i.num)}" title="Tirar da lista">✕</button></a>`).join('') + '</div>';
  }
  function mostrarCard(a) {
    clearTimeout(tCard);
    const i = lista.find(x => x.num === a.dataset.num); if (!i) return;
    if (!card) { card = document.createElement('div'); card.id = 'tf-fx-card'; document.body.appendChild(card); }
    const linha = (r, v) => v ? `<div><span>${r}</span>${esc(v)}</div>` : '';
    const dm = t => new Date(t).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
    const s = i.status;
    const status = s
      ? `<div class="tf-fx-status"><b>${esc(s.op)}</b><small>${esc([s.data, s.hora].filter(Boolean).join(' '))}${s.unidade ? ' · ' + esc(s.unidade) : ''}</small>` +
        `<em>Último status do histórico, visto na consulta em ${dm(i.statusEm || i.quando)}</em></div>`
      : '<div class="tf-fx-status sem"><em>Último status: abra a consulta desta remessa para registrar.</em></div>';
    card.innerHTML = `<div class="tf-fx-c-topo">${i.tipo === 'coleta' ? 'Coleta' : 'Remessa'} ${esc(i.num)}</div>` +
      `${status}<div class="tf-fx-c-corpo">${linha(i.tipo === 'coleta' ? 'Remet.' : 'Dest.', i.nome)}${linha('End.', i.end)}${linha('Bairro', i.bairro)}${linha('Cidade/UF', i.cidade)}${linha('Cep', i.cep)}${linha('Telefone', i.fone)}${linha('CPF/CNPJ', i.doc)}` +
      `${!i.nome && !i.end ? `<div class="tf-fx-vazio">Sem dados do ${i.tipo === 'coleta' ? 'remetente' : 'destinatário'}.</div>` : ''}<div class="tf-fx-quando">Fixada em ${dm(i.quando)}</div></div>`;
    card.hidden = false;
    const r = a.getBoundingClientRect();
    card.style.left = (r.right + 8) + 'px';
    card.style.top = Math.max(8, Math.min(r.top, innerHeight - card.offsetHeight - 8)) + 'px';
  }
  function esconderCard() { if (card) card.hidden = true; }

  chrome.storage.onChanged.addListener((m, area) => {
    if (area !== 'local' || !m[CHAVE]) return;
    lista = m[CHAVE].newValue || [];
    desenhar(); colocarAlfinete();
  });

  (async () => {
    await ler();
    desenhar();
    colocarAlfinete();
    setInterval(colocarAlfinete, 1000);   // a consulta é redesenhada pelo PrimeFaces
  })();
})();
