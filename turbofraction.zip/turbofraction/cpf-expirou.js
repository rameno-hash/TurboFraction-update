/*
 * TurboFraction — tela do resultado da pesquisa por CPF/CNPJ (/FractionWeb/jad/cpf_cnpj)
 * Quando o Fraction descarta a tela (muitas abas abertas ou tempo parado), a troca de página cai num erro
 * técnico ("findCpfCnpj"). Aqui a pesquisa é refeita sozinha pela tela Pesquisar, com o mesmo CPF/CNPJ.
 */
(() => {
  'use strict';
  const txt = document.body ? document.body.textContent || '' : '';
  if (!/Erro apresentado/i.test(txt) || !/findCpfCnpj|cpf_cnpj/i.test(txt)) return;
  let doc = '', tentou = 0;
  try { doc = sessionStorage.getItem('tf_ultimo_cpf') || ''; tentou = +sessionStorage.getItem('tf_cpf_reabriu') || 0; } catch (e) { /* ok */ }
  const aviso = document.createElement('div');
  aviso.id = 'tf-expirou';
  aviso.style.cssText = 'position:sticky;top:0;z-index:9999;margin:0 auto;max-width:900px;padding:12px 18px;background:#C8102E;color:#fff;font:14px Arial,sans-serif;text-align:center;border-radius:0 0 8px 8px;box-shadow:0 3px 12px rgba(0,0,0,.25)';
  if (doc && Date.now() - tentou > 15000) {
    try {
      sessionStorage.setItem('tf_cpf_reabriu', String(Date.now()));
      localStorage.setItem('tf_pesq_cpf', JSON.stringify({ v: doc, t: Date.now() }));
    } catch (e) { /* ok */ }
    aviso.innerHTML = '<b>A pesquisa expirou.</b> Refazendo a pesquisa do CPF/CNPJ <span></span>… (volta para a página 1)';
    aviso.querySelector('span').textContent = doc;
    document.body.prepend(aviso);
    setTimeout(() => location.replace(location.origin + '/FractionWeb/jad/pesquisar'), 700);
  } else {
    aviso.innerHTML = '<b>A pesquisa expirou.</b> O Fraction descartou esta tela (muitas abas abertas ou tempo parado). <a style="color:#fff;font-weight:bold;margin-left:8px;text-decoration:underline">Abrir a tela Pesquisar</a>';
    aviso.querySelector('a').href = location.origin + '/FractionWeb/jad/pesquisar';
    document.body.prepend(aviso);
  }
})();
