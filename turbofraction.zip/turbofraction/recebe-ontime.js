/*
 * TurboFraction — "On Time": leitura contínua de códigos (roda no mundo da página, world MAIN)
 *   Recebimento de Remessa (recebe.jad): adiciona e processa cada código ("Entrada On Time").
 *   Lista de Entrega (listaEntrega.jad): adiciona cada código à nova lista ("Lista On Time").
 *
 * Abre um campo de leitura: cada código lido (Enter do leitor) entra numa fila e, um por vez,
 * a extensão faz o que a pessoa faria — coloca o código no campo Remessa, clica em "Adicionar"
 * e depois em "Processar lista". As mensagens do Fraction não aparecem em popups: os erros vão
 * para um painel lateral, onde ficam. "Item já está na lista" é ignorado.
 * Todo código lido fica guardado (buffer invisível no navegador) e pode ser salvo em .txt.
 */
(() => {
  'use strict';
  if (window.top !== window || window.__tfOnTime) return;
  window.__tfOnTime = true;

  // Duas telas: Recebimento de Remessa (adiciona e processa cada código) e Lista de Entrega
  // (só adiciona cada código à nova lista; Rota e Processar ficam com a pessoa no fim).
  const LISTA = /listaEntrega/.test(location.pathname);
  const F = LISTA ? 'form_nova_lista_entrega' : 'form_recebe_remessa';
  const ID = LISTA
    ? { texto: F + ':txtArea', add: F + ':addLote', processar: null }
    : { texto: F + ':txtArea', add: F + ':addLote', processar: F + ':botao_processar_lista' };
  const CHAVE_BUFFER = LISTA ? 'tf_ontime_lista_buffer' : 'tf_ontime_buffer';
  const CHAVE_ERROS = LISTA ? 'tf_ontime_lista_erros' : 'tf_ontime_erros';
  const NOME = LISTA ? 'Lista On Time' : 'Entrada On Time';
  const ARQ = LISTA ? 'ListaOnTime' : 'EntradaOnTime';
  const IGNORAR = /j.\s+est.\s+na\s+lista/i;
  const $id = id => document.getElementById(id);
  const esperar = ms => new Promise(r => setTimeout(r, ms));
  const agora = () => new Date().toLocaleTimeString('pt-BR');

  /* ---------- Acompanhar os pedidos do Fraction ---------- */
  const ouvintes = new Set();
  const XO = XMLHttpRequest.prototype.open, XS = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (m, url) { this.__tfUrl = String(url || ''); return XO.apply(this, arguments); };
  XMLHttpRequest.prototype.send = function (corpo) {
    if (/recebe|listaEntrega/.test(this.__tfUrl) && typeof corpo === 'string') {
      const f = (/(?:^|&)javax\.faces\.source=([^&]*)/.exec(corpo) || [])[1];
      const origem = f ? decodeURIComponent(f.replace(/\+/g, ' ')) : '';
      this.addEventListener('loadend', () => ouvintes.forEach(fn => fn(origem, this.responseText || '', this.status)));
    }
    return XS.apply(this, arguments);
  };
  function esperarResposta(origem, limite = 60000) {
    return new Promise((ok, falha) => {
      const t = setTimeout(() => { ouvintes.delete(fn); const e = new Error('o Fraction não respondeu'); e.semResposta = true; falha(e); }, limite);
      const fn = (o, txt, st) => { if (o === origem) { clearTimeout(t); ouvintes.delete(fn); ok({ txt, st }); } };
      ouvintes.add(fn);
    });
  }
  function mensagens(xml) {
    const lista = [];
    const reUpd = /<update id="form_notificacao:(mensagemTmp|mensagemFixa)"><!\[CDATA\[([\s\S]*?)\]\]><\/update>/g;
    let u;
    while ((u = reUpd.exec(xml))) {
      const reMsg = /"?summary"?\s*:\s*"((?:[^"\\]|\\.)*)"\s*,\s*"?detail"?\s*:\s*"((?:[^"\\]|\\.)*)"\s*,\s*"?severity"?\s*:\s*["'](\w+)["']/g;
      let m;
      while ((m = reMsg.exec(u[2]))) {
        const dec = s => { try { return JSON.parse('"' + s + '"'); } catch (e) { return s; } };
        const resumo = dec(m[1]).replace(/<[^>]+>/g, ''), detalhe = dec(m[2]).replace(/<[^>]+>/g, '');
        lista.push({ texto: detalhe && detalhe !== resumo ? detalhe : resumo, nivel: m[3].toLowerCase() });
      }
    }
    if (/<partial-response>\s*<error|<error-name>/.test(xml)) lista.push({ texto: 'Erro do servidor do Fraction', nivel: 'error' });
    return lista;
  }

  const clicar = el => el && el.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));
  function definir(el, v) {
    const d = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(el), 'value');
    if (d && d.set) d.set.call(el, v); else el.value = v;
    el.dispatchEvent(new Event('input', { bubbles: true }));
  }

  /* ---------- Buffer (todo código lido) ---------- */
  const ler = (k, padrao) => { try { return JSON.parse(localStorage.getItem(k)) || padrao; } catch (e) { return padrao; } };
  const gravar = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* cheio/bloqueado */ } };
  let buffer = ler(CHAVE_BUFFER, []);        // [{c, t}]
  // Erros só da sessão: a página recarregada começa limpa (o buffer de códigos continua guardado).
  let erros = [];                            // [{c, t, msg}]
  try { localStorage.removeItem(CHAVE_ERROS); } catch (e) { /* ok */ }

  /* ---------- Fila ---------- */
  const fila = [];
  let rodando = false, ok = 0, falhas = 0, dups = 0, lidosSessao = 0, numLeitura = 0;
  let corretos = 0;   // Lista: leituras certas que continuam na lista (numeração e contagem falada)

  /** Linhas da janela de inconsistências do Adicionar (errosAddLote), vindas na resposta. */
  function inconsistencias(xml) {
    const u = /<update id="[^"]*errosAddLote[^"]*"><!\[CDATA\[([\s\S]*?)\]\]><\/update>/.exec(xml);
    if (!u) return [];
    const doc = new DOMParser().parseFromString('<table>' + u[1] + '</table>', 'text/html');
    return [...doc.querySelectorAll('tbody tr')]
      .filter(tr => tr.cells.length >= 2 && !tr.classList.contains('ui-datatable-empty-message'))
      .map(tr => ({ desc: tr.cells[0].textContent.trim(), texto: (tr.cells[1].textContent || tr.cells[0].textContent).trim() }));
  }
  const qtdNaLista = txt => { const m = /adicionados\s+a\s+lista\s+(\d+)\s+ite/i.exec(txt || ''); return m ? +m[1] : null; };

  /* ---------- Lista de Entrega: remessas multi-volume incompletas (linhas laranja do Fraction) ---------- */
  const incompletos = new Map();   // remessa -> { total, vols:Set, incompleto }
  function lerTabelaNovaLista(xml) {
    const u = /<update id="form_nova_lista_entrega:panel_nova_lista_entrega"><!\[CDATA\[([\s\S]*?)\]\]><\/update>/.exec(xml);
    if (!u) return;
    const doc = new DOMParser().parseFromString(u[1], 'text/html');
    const corpo = doc.querySelector('[id$="dataListaEnvioRemessa_data"]');
    if (!corpo) return;
    const vistos = new Map();
    const linhas = [];
    [...corpo.rows].forEach(tr => {
      if (tr.cells.length < 4) return;
      const remessa = tr.cells[1].textContent.trim(), vol = parseInt(tr.cells[2].textContent, 10), total = parseInt(tr.cells[3].textContent, 10);
      if (!/^\d{6,}$/.test(remessa)) return;
      linhas.push({ cod: tr.cells[0].textContent.trim(), remessa, chave: tr.cells[0].textContent.trim() + '|' + tr.cells[2].textContent.trim() + '|' + remessa });
      const laranja = [...tr.cells].some(td => /orange/i.test(td.getAttribute('style') || ''));
      const v = vistos.get(remessa) || { total: total || 1, vols: [], laranja: false };
      if (vol) v.vols.push(vol);
      v.laranja = v.laranja || laranja;
      vistos.set(remessa, v);
    });
    vistos.forEach((v, remessa) => {
      const e = incompletos.get(remessa) || { total: v.total, vols: new Set() };
      e.total = v.total; v.vols.forEach(x => e.vols.add(x));
      // Quem manda é a cor do Fraction: laranja = incompleta; sem laranja = lote completo.
      e.incompleto = v.laranja;
      incompletos.set(remessa, e);
    });
    return linhas;
  }
  /** Remessa (da lista do Fraction) do código lido: a linha cujo código é o lido ou o começo dele. */
  function remessaDoCodigo(linhas, codigo, soTabela) {
    const c = String(codigo).trim();
    let melhor = null;
    (linhas || []).forEach(l => { if (l.cod && (c === l.cod || c.startsWith(l.cod) || c === l.remessa) && (!melhor || l.cod.length > melhor.cod.length)) melhor = l; });
    if (melhor) return melhor.remessa;
    if (soTabela) return '';
    const m = /^(\d{14})(\d{3})?$/.exec(c);
    return m ? m[1] : '';
  }
  /** A tabela da nova lista mostra o máximo de linhas por página (para enxergar todos os volumes). */
  function seletorLinhas() { return document.querySelector('select[name="' + F + ':dataListaEnvioRemessa_rppDD"], select[id="' + F + ':dataListaEnvioRemessa_rppDD"]'); }
  function maisLinhasNecessario() {
    const sel = seletorLinhas();
    if (!sel || !sel.options.length) return false;
    const max = Math.max(...[...sel.options].map(o => +o.value || 0));
    return +sel.value < max;
  }
  function mostrarTodasAsLinhas() {
    const sel = document.querySelector('select[name="' + F + ':dataListaEnvioRemessa_rppDD"], select[id="' + F + ':dataListaEnvioRemessa_rppDD"]');
    if (!sel || !sel.options.length) return;
    const max = [...sel.options].reduce((m, o) => (+o.value > +m.value ? o : m), sel.options[0]);
    if (sel.value !== max.value) { sel.value = max.value; sel.dispatchEvent(new Event('change', { bubbles: true })); }
  }

  /** Linhas da nova lista (na tela) que pertencem à remessa. */
  const linhasDaRemessa = remessa => [...(document.getElementById(F + ':dataListaEnvioRemessa_data')?.rows || [])]
    .filter(tr => tr.cells.length > 2 && tr.cells[1].textContent.trim() === remessa);

  /** Tira da nova lista todos os volumes da remessa (o mesmo "Excluir" de cada linha do Fraction). */
  async function excluirRemessa(remessa) {
    while (rodando) await esperar(200);   // termina as leituras em andamento
    rodando = true;
    let n = 0, erro = '';
    try {
      for (let volta = 0; volta < 200; volta++) {
        const tr = linhasDaRemessa(remessa)[0];
        if (!tr) break;
        const link = [...tr.querySelectorAll('a')].find(a => /excluir/i.test(a.textContent));
        if (!link) { erro = 'não achei o Excluir da linha'; break; }
        const r = esperarResposta(link.id, 20000);
        clicar(link);
        const { txt } = await r;
        const m = mensagens(txt).filter(x => /error|fatal/.test(x.nivel));
        if (m.length) { erro = m.map(x => x.texto).join(' · '); break; }
        n++;
        await esperar(150);
      }
    } catch (e) { erro = e.message; }
    rodando = false;
    if (!erro) incompletos.delete(remessa);
    return { n, erro };
  }

  /** Lista de Entrega: só o Adicionar (à nova lista). */
  async function adicionarNaLista(codigo) {
    const ta = $id(ID.texto), add = $id(ID.add);
    if (!ta || !add) throw new Error('a janela "Nova lista" do Fraction não está aberta');
    const antes = qtdNaLista($id(F)?.textContent);
    // Linhas que já estavam na lista: a linha nova revela a remessa de códigos que não a contêm (ex.: etiqueta do cliente).
    const jaNaLista = new Set([...(document.getElementById(F + ':dataListaEnvioRemessa_data')?.rows || [])]
      .filter(tr => tr.cells.length > 2).map(tr => tr.cells[0].textContent.trim() + '|' + tr.cells[2].textContent.trim() + '|' + tr.cells[1].textContent.trim()));
    definir(ta, codigo);
    const r1 = esperarResposta(ID.add);
    clicar(add);
    const t1 = (await r1).txt;
    const linhasT = lerTabelaNovaLista(t1);
    let remessa = remessaDoCodigo(linhasT, codigo, true);
    if (!remessa) {
      const nova = (linhasT || []).find(l => !jaNaLista.has(l.chave));
      remessa = nova ? nova.remessa : '';
    }
    if (!remessa) { const m = /^(\d{14})(\d{3})?$/.exec(String(codigo).trim()); remessa = m ? m[1] : ''; }
    // A tabela do Fraction pagina de 10 em 10: garante todas as linhas na tela (para ver todos os volumes).
    if (maisLinhasNecessario()) { const rp = esperarResposta(F + ':dataListaEnvioRemessa', 10000).catch(() => null); mostrarTodasAsLinhas(); await rp; }
    const inc = inconsistencias(t1);
    const jaEstava = inc.some(i => IGNORAR.test(i.desc + ' ' + i.texto));
    const erros = inc.filter(i => !IGNORAR.test(i.desc + ' ' + i.texto));
    const msgs = mensagens(t1).filter(m => !IGNORAR.test(m.texto) && (/error|fatal|warn/.test(m.nivel) || /erro|inv.lido|n.o\s+localizado|n.o\s+permite/i.test(m.texto)));
    if (erros.length || msgs.length) return { ok: false, remessa, msg: [...erros.map(i => i.desc && i.desc !== i.texto ? `${i.desc}: ${i.texto}` : i.texto), ...msgs.map(m => m.texto)].join(' · ') };
    if (jaEstava) return { ok: true, dup: true, remessa, msg: 'Leitura duplicada' };
    const depois = qtdNaLista(t1);
    if (depois !== null && antes !== null && depois <= antes) return { ok: false, remessa, msg: 'O Fraction não colocou o código na lista' };
    return { ok: true, remessa, msg: 'Adicionado à lista.' };
  }

  async function processarUm(codigo) {
    if (LISTA) return adicionarNaLista(codigo);
    const ta = $id(ID.texto), add = $id(ID.add);
    if (!ta || !add) throw new Error('campo Remessa não encontrado');
    // 1) Adicionar
    definir(ta, codigo);
    const r1 = esperarResposta(ID.add);
    clicar(add);
    const t1 = (await r1).txt;
    const m1 = mensagens(t1);
    // Quantos itens a lista do Fraction tem depois do Adicionar (rodapé "Já foram adicionados a lista N itens").
    const qtd = t1.match(/adicionados\s+a\s+lista\s+(\d+)\s+ite/i);
    const listaVazia = /N.o\s+existe\s+item\s+na\s+lista/i.test(t1) && !qtd;
    const err1 = m1.filter(m => /error|fatal|warn/.test(m.nivel) || /erro|inv.lido|n.o\s+localizado|n.o\s+permite/i.test(m.texto)).filter(m => !IGNORAR.test(m.texto));
    if (err1.length) return { ok: false, msg: err1.map(m => m.texto).join(' · ') };
    if (listaVazia) return { ok: false, msg: 'O Fraction não colocou o código na lista' + (m1.length ? ' (' + m1.map(m => m.texto).join(' · ') + ')' : '') };
    await esperar(150);
    // 2) Processar lista
    const proc = $id(ID.processar);
    if (!proc) throw new Error('botão Processar lista não encontrado');
    const r2 = esperarResposta(ID.processar);
    clicar(proc);
    const p = await r2;
    if (p.st >= 400) return { ok: false, msg: 'Erro do servidor (' + p.st + ')' };
    const m2 = mensagens(p.txt).filter(m => !IGNORAR.test(m.texto));
    const err2 = m2.filter(m => /error|fatal|warn/.test(m.nivel) || /erro|inv.lido|n.o\s+permite|bloquead|finalizad/i.test(m.texto));
    if (err2.length) return { ok: false, msg: err2.map(m => m.texto).join(' · ') };
    // Depois do Processar a lista deve esvaziar; se os itens continuam lá, não foi processado.
    const ficou = p.txt.match(/adicionados\s+a\s+lista\s+(\d+)\s+ite/i);
    if (ficou && +ficou[1] > 0) return { ok: false, msg: `Não foi processado: ${ficou[1]} item(ns) continuam na lista do Fraction` + (m2.length ? ` (resposta: ${m2.map(m => m.texto).join(' · ')})` : '') };
    const passos = `Adicionar: ${m1.map(m => m.texto).join(' · ') || (qtd ? qtd[1] + ' item(ns) na lista' : 'ok')} → Processar: ${m2.map(m => m.texto).join(' · ') || 'sem mensagem'}`;
    return { ok: true, msg: (m2[0] && m2[0].texto) || 'Recebida', detalhe: passos };
  }

  /* ---------- Lista de Entrega: Circuit de cada remessa (consulta da remessa) ---------- */
    // O Circuit vem do arquivo da Performance guardado pela extensão (ponte-circuit.js): nenhum pedido ao Fraction.
  let idPedido = 0;
  function circuitsDaPerformance(remessas) {
    const id = 'c' + (++idPedido) + '_' + Date.now();
    return new Promise((ok, falha) => {
      const fim = setTimeout(() => { window.removeEventListener('message', ouvir); falha(new Error('a extensão não respondeu')); }, 60000);
      function ouvir(ev) {
        if (ev.source !== window || !ev.data || ev.data.tf !== 'circuits-resposta' || ev.data.id !== id) return;
        clearTimeout(fim); window.removeEventListener('message', ouvir);
        if (ev.data.erro) falha(new Error(ev.data.erro)); else ok(ev.data);
      }
      window.addEventListener('message', ouvir);
      window.postMessage({ tf: 'circuits-pedido', id, remessas }, location.origin);
    });
  }
  /** Remessas da nova lista (na tela), com a quantidade de volumes lidos de cada uma. */
  function remessasDaLista() {
    const m = new Map();
    [...(document.getElementById(F + ':dataListaEnvioRemessa_data')?.rows || [])].forEach(tr => {
      if (tr.cells.length < 4) return;
      const rem = tr.cells[1].textContent.trim();
      if (!/^\d{6,}$/.test(rem)) return;
      const e = m.get(rem) || { lidos: 0, total: parseInt(tr.cells[3].textContent, 10) || 1 };
      e.lidos++; m.set(rem, e);
    });
    return m;
  }

  /* ---------- Bipes da Lista On Time (código certo, duplicado, erro) ---------- */
  let audio = null;
  // Modo do som (lembrado neste navegador): '1' = bipes · 'n' = contagem falada · '0' = silenciado.
  const CHAVE_SOM = 'tf_ontime_som';
  const modoSom = () => { try { const v = localStorage.getItem(CHAVE_SOM); return v === '0' || v === 'n' ? v : '1'; } catch (e) { return '1'; } };
  const somLigado = () => modoSom() !== '0';
  const ctxAudio = () => { audio = audio || new (window.AudioContext || window.webkitAudioContext)(); if (audio.state === 'suspended') audio.resume(); return audio; };

  /* Contagem falada: voz do próprio Chrome (leitor de texto do navegador, em português do Brasil). */
  const fala = window.speechSynthesis;
  let vozPt = null;
  function escolherVoz() {
    if (!fala) return null;
    const vs = fala.getVoices().filter(v => /^pt[-_]BR/i.test(v.lang) || /portugu.s do brasil|brazil/i.test(v.name));
    // Preferência: vozes naturais (Google / "Online (Natural)"), depois qualquer pt-BR.
    vozPt = vs.find(v => /google/i.test(v.name)) || vs.find(v => /natural/i.test(v.name)) || vs.find(v => v.localService) || vs[0] || null;
    return vozPt;
  }
  if (fala) { escolherVoz(); fala.addEventListener('voiceschanged', escolherVoz); }
  function falarNumero(n) {
    if (!fala) { bipe('ok', true); return; }
    try {
      fala.cancel();   // a leitura nova interrompe a contagem anterior
      const u = new SpeechSynthesisUtterance(String(n));
      u.lang = 'pt-BR';
      if (vozPt || escolherVoz()) u.voice = vozPt;
      u.rate = 1.35; u.volume = 1;
      fala.speak(u);
    } catch (e) { bipe('ok', true); }
  }

  function bipe(tipo, forcar) {
    if (!somLigado() && !forcar) return;
    try {
      ctxAudio();
      if (audio.state === 'suspended') audio.resume();
      const t0 = audio.currentTime + 0.01;
      const tom = (freqs, ini, dur, vol, forma) => {
        const g = audio.createGain();
        g.gain.setValueAtTime(0, ini);
        g.gain.linearRampToValueAtTime(vol, ini + 0.004);
        g.gain.setValueAtTime(vol, ini + dur - 0.01);
        g.gain.linearRampToValueAtTime(0, ini + dur);
        g.connect(audio.destination);
        freqs.forEach(f => { const o = audio.createOscillator(); o.type = forma; o.frequency.value = f; o.connect(g); o.start(ini); o.stop(ini + dur + 0.02); });
      };
      if (tipo === 'ok') tom([1320], t0, 0.14, 0.45, 'sine');                                   // bipe positivo
      else if (tipo === 'dup') { tom([990], t0, 0.07, 0.4, 'sine'); tom([990], t0 + 0.13, 0.07, 0.4, 'sine'); }  // dois bipes curtos
      else tom([622, 659, 932], t0, 0.16, 0.18, 'square');                                     // buzina de erro
    } catch (e) { /* sem som neste navegador */ }
  }

  const tentativas = new Map(), MAX_TENTATIVAS = 5;
  async function trabalhar() {
    if (rodando) return;
    rodando = true;
    if (LISTA && janela) janela.querySelector('.ot-processar').disabled = true;
    while (fila.length) {
      const codigo = fila.shift();
      ui.atual(codigo);
      let r;
      try { r = await processarUm(codigo); } catch (e) { r = { ok: false, msg: e.message, semResposta: !!e.semResposta }; }
      // Sem resposta do Fraction: o código volta para o começo da fila e é tentado de novo.
      if (r.semResposta) {
        const n = (tentativas.get(codigo) || 0) + 1;
        tentativas.set(codigo, n);
        if (n < MAX_TENTATIVAS) {
          fila.unshift(codigo);
          for (let s = 10; s > 0; s--) {
            if (janela) janela.querySelector('.ot-agora').textContent = `⏳ O Fraction não respondeu (${codigo}). Tentando de novo em ${s} s — tentativa ${n + 1} de ${MAX_TENTATIVAS}. ${fila.length} código(s) na fila.`;
            await esperar(1000);
          }
          continue;
        }
        r.msg = `o Fraction não respondeu (${MAX_TENTATIVAS} tentativas)`;
      }
      tentativas.delete(codigo);
      if (r.dup) dups++; else if (r.ok) ok++; else { falhas++; erros.unshift({ c: codigo, t: agora(), msg: r.msg }); if (erros.length > 500) erros.length = 500; }
      ui.resultado(codigo, r);
      await esperar(200);
    }
    rodando = false;
    if (LISTA && janela) janela.querySelector('.ot-processar').disabled = false;
    ui.atual(null);
  }

  /**
   * Recebimento: entrada de um arquivo inteiro de uma vez, em dois passos, como na tela do Fraction:
   *   "▶ Dar entrada em todos" = todos os códigos no campo Remessa e um único Adicionar;
   *   "▶ Processar"            = um único Processar lista.
   * Arquivos grandes vão em lotes de até LOTE códigos (o Fraction processa no máximo 1.000 itens por operação).
   * Os códigos que não entraram na lista e as mensagens de erro vão para o painel de erros.
   */
  const LOTE = 500;
  const arquivo = { lotes: [], n: 0, fase: '' };   // fase: 'adicionar' | 'processar' | '' (nada pendente)
  const erroDe = (c, msg) => { falhas++; erros.unshift({ c, t: agora(), msg }); if (erros.length > 1000) erros.length = 1000; };
  const nomeLote = () => arquivo.lotes.length > 1 ? `Lote ${arquivo.n + 1}/${arquivo.lotes.length}` : 'Arquivo';
  const statusArq = t => { if (janela) janela.querySelector('.ot-agora').textContent = `${nomeLote()} (${arquivo.lotes[arquivo.n].length} código(s)): ${t}`; };

  async function iniciarArquivo(codigos) {
    virarDia();
    codigos.forEach(c => { buffer.push({ c, t: new Date().toISOString() }); lidosSessao++; });
    gravar(CHAVE_BUFFER, buffer);
    while (rodando) await esperar(300);   // termina as leituras que já estavam na fila
    rodando = true;                        // novas leituras esperam o arquivo terminar
    arquivo.lotes = []; arquivo.n = 0;
    for (let i = 0; i < codigos.length; i += LOTE) arquivo.lotes.push(codigos.slice(i, i + LOTE));
    arquivo.fase = 'adicionar';
  }
  function encerrarArquivo() {
    arquivo.lotes = []; arquivo.n = 0; arquivo.fase = '';
    rodando = false;
    ui.atual(null);
    trabalhar();   // leituras feitas durante o arquivo
  }

  /** Passo 1: todos os códigos do lote no campo Remessa (um por linha) e um único Adicionar. */
  async function adicionarArquivo() {
    const lote = arquivo.lotes[arquivo.n], nome = nomeLote();
    const casa = (c, l) => c === l.cod || c === l.remessa || (l.cod && (l.cod.startsWith(c) || c.startsWith(l.cod)));
    try {
      const ta = $id(ID.texto), add = $id(ID.add);
      if (!ta || !add) throw new Error('campo Remessa não encontrado');
      statusArq('adicionando…');
      definir(ta, lote.join('\n'));
      const r1 = esperarResposta(ID.add, 300000);
      clicar(add);
      const t1 = (await r1).txt;
      const m1 = mensagens(t1).filter(m => !IGNORAR.test(m.texto));
      const inc = inconsistencias(t1);
      const doc = new DOMParser().parseFromString('<div>' + ((/<update id="form_recebe_remessa:panel_recebe_remessa"><!\[CDATA\[([\s\S]*?)\]\]><\/update>/.exec(t1) || [])[1] || '') + '</div>', 'text/html');
      const linhas = [...doc.querySelectorAll('tbody[id$="dataListaRecebeRemessa_data"] tr')]
        .filter(tr => tr.cells.length > 2)
        .map(tr => ({ cod: tr.cells[0].textContent.trim(), remessa: tr.cells[1].textContent.trim() }));
      const achados = lote.filter(c => linhas.some(l => casa(c, l)));
      const semPar = lote.filter(c => !achados.includes(c));
      // Código sem linha correspondente (ex.: etiqueta do cliente, QR code) só é erro se faltarem linhas na lista.
      const fora = lote.length > linhas.length ? semPar : [];
      const naLista = lote.length - fora.length;
      const avisos = [...m1.filter(m => /error|fatal|warn/.test(m.nivel) || /erro|inv.lido|n.o\s+localizado|n.o\s+permite/i.test(m.texto)).map(m => m.texto),
        ...inc.map(i => i.desc && i.desc !== i.texto ? `${i.desc}: ${i.texto}` : i.texto)];
      // Cada código fora da lista leva a mensagem que o cita (se houver).
      const usados = new Set();
      fora.forEach(c => {
        const proprias = avisos.filter(x => x.includes(c) || (c.length > 14 && x.includes(c.slice(0, 14))));
        proprias.forEach(x => usados.add(x));
        erroDe(c, proprias.length ? proprias.join(' · ') : 'Não encontrado na lista do Fraction (confira)');
      });
      avisos.filter(x => !usados.has(x)).forEach(x => erroDe(nome + ' · Adicionar', x));
      arquivo.naLista = naLista;
      ui.resultado(nome + ' · Adicionar', naLista
        ? { ok: true, msg: `${naLista} de ${lote.length} na lista do Fraction` + (fora.length ? ` · ${fora.length} erro(s)` : '') + ' — clique em ▶ Processar', detalhe: m1.map(m => m.texto).join(' · ') }
        : { ok: false, msg: `nenhum código entrou na lista (${fora.length} erro(s))` });
      arquivo.fase = naLista ? 'processar' : (arquivo.n + 1 < arquivo.lotes.length ? 'proximo' : '');
    } catch (e) {
      lote.forEach(c => erroDe(c, e.semResposta ? 'o Fraction não respondeu (arquivo)' : e.message));
      ui.resultado(nome + ' · Adicionar', { ok: false, msg: e.message });
      arquivo.fase = arquivo.n + 1 < arquivo.lotes.length ? 'proximo' : '';
    }
    ui.desenharErros();
    if (janela) janela.querySelector('.ot-agora').textContent = arquivo.fase === 'processar' ? `${nomeLote()}: ${arquivo.naLista} código(s) na lista do Fraction. Confira os erros e clique em ▶ Processar.` : '';
  }

  /** Passo 2: um único Processar lista. */
  async function processarListaArquivo() {
    const nome = nomeLote();
    try {
      statusArq('processando a lista…');
      const proc = $id(ID.processar);
      if (!proc) throw new Error('botão Processar lista não encontrado');
      const r2 = esperarResposta(ID.processar, 300000);
      clicar(proc);
      const p = await r2;
      const m2 = mensagens(p.txt).filter(m => !IGNORAR.test(m.texto));
      const err2 = p.st >= 400 ? ['Erro do servidor (' + p.st + ')'] : m2.filter(m => /error|fatal|warn/.test(m.nivel) || /erro|inv.lido|n.o\s+permite|bloquead|finalizad/i.test(m.texto)).map(m => m.texto);
      const ficou = p.txt.match(/adicionados\s+a\s+lista\s+(\d+)\s+ite/i);
      if (ficou && +ficou[1] > 0) err2.push(`Não foi processado: ${ficou[1]} item(ns) continuam na lista do Fraction`);
      err2.forEach(x => erroDe(nome + ' · Processar', x));
      if (!err2.length) ok += arquivo.naLista || 0;
      ui.resultado(nome + ' · Processar', err2.length
        ? { ok: false, msg: err2.join(' · ') }
        : { ok: true, msg: `${arquivo.naLista} processado(s)` + ((m2[0] && ' — ' + m2[0].texto) || ''), detalhe: m2.map(m => m.texto).join(' · ') });
    } catch (e) {
      erroDe(nome + ' · Processar', e.semResposta ? 'o Fraction não respondeu ao Processar lista' : e.message);
      ui.resultado(nome + ' · Processar', { ok: false, msg: e.message });
    }
    ui.desenharErros();
    arquivo.fase = arquivo.n + 1 < arquivo.lotes.length ? 'proximo' : '';
  }

  function receber(texto) {
    virarDia();
    const cods = (texto.match(/[A-Za-z0-9$-]{4,}/g) || []);
    cods.forEach(c => {
      buffer.push({ c, t: new Date().toISOString() });
      lidosSessao++;
      fila.push(c);
    });
    gravar(CHAVE_BUFFER, buffer);
    ui.contar();
    trabalhar();
  }

  /** Link da consulta da remessa (os 14 primeiros dígitos do código lido), em outra aba. */
  /** Chave de NF-e (44 dígitos) -> número da NF (posições 26 a 34, sem zeros à esquerda). */
  const nfDaChave = k => String(parseInt(k.slice(25, 34), 10) || '');

  function linkRemessa(codigo, classe) {
    // Remessa (14 dígitos, ou 17 com o volume): abre a consulta da remessa.
    // QR code e código de barras começam pelo Shipment ID, que não abre a consulta da remessa.
    const cte = (/^(\d{14})(\d{3})?$/.exec(codigo) || [])[1];
    const chave = /^\d{44}$/.test(codigo) ? codigo : '';
    const el = document.createElement(cte || chave ? 'a' : 'span');
    el.className = classe;
    el.textContent = codigo;
    if (cte) { el.href = location.origin + '/FractionWeb/jad/tracking?cte=' + cte; el.target = '_blank'; el.rel = 'noopener'; el.title = 'Abrir a consulta da remessa ' + cte; }
    else if (chave) linkNotaFiscal(el, nfDaChave(chave));
    return el;
  }

  /** Link que abre a Consulta com a Nota Fiscal preenchida e o período dos últimos 30 dias. */
  function linkNotaFiscal(el, nf) {
    el.href = location.origin + '/FractionWeb/jad/consulta';
    el.target = '_blank'; el.rel = 'noopener';
    el.title = `Chave de NF-e: abrir a Consulta com a Nota Fiscal ${nf} (últimos 30 dias)`;
    el.addEventListener('click', () => { try { localStorage.setItem('tf_cons_nf', JSON.stringify({ v: nf, t: Date.now() })); } catch (e) { /* ok */ } });
  }

  /** Para onde o cartão de erro leva: {cte} (consulta da remessa) ou {nf} (Consulta pela Nota Fiscal). */
  function destinoDoErro(e) {
    const cod = String(e.c || ''), msg = String(e.msg || '');
    const cteCod = (/^(\d{14})(\d{3})?$/.exec(cod) || [])[1];
    const cteMsg = (/\b(\d{14})\b/.exec(msg) || [])[1];
    if (cteCod || cteMsg) return { cte: cteCod || cteMsg };
    const chave = (/^\d{44}$/.test(cod) && cod) || (/\b(\d{44})\b/.exec(msg) || [])[1];
    if (chave) return { nf: nfDaChave(chave) };
    return null;
  }

  /** Texto da mensagem de erro com os números de remessa/CT-e (14 dígitos) e chaves de NF-e como links. */
  function textoComLinks(texto) {
    const frag = document.createDocumentFragment();
    let ultimo = 0;
    texto.replace(/\b(\d{44}|\d{14})\b/g, (m, num, pos) => {
      if (pos > ultimo) frag.appendChild(document.createTextNode(texto.slice(ultimo, pos)));
      const a = document.createElement('a');
      a.className = 'ot-e-link';
      a.textContent = num;
      if (num.length === 44) linkNotaFiscal(a, nfDaChave(num));
      else { a.href = location.origin + '/FractionWeb/jad/tracking?cte=' + num; a.target = '_blank'; a.rel = 'noopener'; a.title = 'Abrir a consulta da remessa ' + num; }
      frag.appendChild(a);
      ultimo = pos + m.length;
      return m;
    });
    if (ultimo < texto.length) frag.appendChild(document.createTextNode(texto.slice(ultimo)));
    return frag;
  }


  /* ---------- Janela ---------- */
  const ui = {};
  function montar() {
    const caixa = document.createElement('div');
    caixa.id = 'tf-ontime';
    caixa.innerHTML = `
      <div class="ot-topo"><b>⏱ ${NOME}</b><span class="ot-cont"></span>
        <button type="button" class="ot-salvar" title="Salva um arquivo .txt com todos os códigos lidos">💾 Salvar códigos</button>
        ${LISTA ? '<button type="button" class="ot-som"></button>' : ''}
        <button type="button" class="ot-fechar" title="Fechar (a leitura em andamento termina)">✕</button></div>
      <div class="ot-arquivo" hidden><span class="ot-arq-txt"></span><button type="button" class="ot-arq-sim">▶ Dar entrada em todos</button><button type="button" class="ot-arq-nao">Cancelar</button></div>
      <div class="ot-confirma" hidden><div class="ot-c-caixa"><b>⚠ Atenção</b><p class="ot-c-txt"></p><div><button type="button" class="ot-c-sim">Sim, processar</button><button type="button" class="ot-c-nao">Não</button></div></div></div>
      <div class="ot-solte">📄 Solte aqui o arquivo .txt do buffer para dar entrada de novo</div>
      <div class="ot-corpo">
        <div class="ot-esq">
          <label for="ot-campo">Leia ou digite o código e tecle Enter</label>
          <input id="ot-campo" type="text" autocomplete="off" spellcheck="false">
          <div class="ot-agora"></div>
          <ol class="ot-log" reversed></ol>
          <div class="ot-circ" hidden></div>
        </div>
        <div class="ot-dir">
          <div class="ot-dir-topo"><b>Erros</b><span class="ot-nerros"></span>
            <a href="#" class="ot-reenviar" hidden title="Põe de novo na fila os códigos que ficaram sem resposta do Fraction">reenviar</a><a href="#" class="ot-copiar">copiar</a><a href="#" class="ot-limpar-erros">limpar</a></div>
          <ul class="ot-erros"></ul>
        </div>
      </div>
      <div class="ot-rodape"><span class="ot-buffer"></span><span class="ot-info" tabindex="0" aria-label="Sobre o buffer">⚠</span>${LISTA ? '<span class="ot-esp"></span><label class="ot-rota">Rota <input type="text" maxlength="26" autocomplete="off"></label><button type="button" class="ot-processar">▶ Processar lista</button>' : ''}</div>`;
    document.body.appendChild(caixa);
    const campo = caixa.querySelector('#ot-campo');
    const log = caixa.querySelector('.ot-log'), listaErros = caixa.querySelector('.ot-erros');

    campo.addEventListener('keydown', ev => {
      if (ev.key !== 'Enter') return;
      ev.preventDefault(); ev.stopPropagation();
      const v = campo.value.trim(); campo.value = '';
      if (v) receber(v);
    });
    campo.addEventListener('paste', ev => {
      const t = (ev.clipboardData || window.clipboardData).getData('text');
      if (/\s/.test(t.trim())) { ev.preventDefault(); receber(t); }
    });
    caixa.querySelector('.ot-fechar').addEventListener('click', fechar);
    caixa.querySelector('.ot-salvar').addEventListener('click', salvar);
    const somBtn = caixa.querySelector('.ot-som');
    if (somBtn) {
      const MODOS = {
        '1': { txt: '🔊', tit: 'Bipes ligados' },
        'n': { txt: '🔊123', tit: 'Contagem falada' },
        '0': { txt: '🔇', tit: 'Som desligado' },
      };
      const marcarSom = () => { const m = MODOS[modoSom()]; somBtn.textContent = m.txt; const nomeVoz = () => { const n = (vozPt || escolherVoz() || {}).name || ''; return /google/i.test(n) ? 'Google Português Brasil' : (n || 'padrão do navegador'); };
        somBtn.title = m.tit + (modoSom() === 'n' ? ` (voz ${nomeVoz()})` : ''); somBtn.classList.toggle('mudo', modoSom() === '0'); somBtn.classList.toggle('numeros', modoSom() === 'n'); };
      somBtn.addEventListener('click', () => {
        const prox = { '1': 'n', 'n': '0', '0': '1' }[modoSom()];
        try { localStorage.setItem(CHAVE_SOM, prox); } catch (e) { /* ok */ }
        marcarSom();
        if (prox === 'n') falarNumero(Math.max(1, corretos)); else if (prox === '1') bipe('ok');
        focarCampo();
      });
      marcarSom();
    }
    caixa.querySelector('.ot-copiar').addEventListener('click', async ev => {
      ev.preventDefault();
      const t = erros.map(e => `${e.c}\t${e.msg}`).join('\n');
      try { await navigator.clipboard.writeText(t); } catch (e) { const ta = document.createElement('textarea'); ta.value = t; document.body.appendChild(ta); ta.select(); document.execCommand('copy'); ta.remove(); }
      ev.target.textContent = 'copiado'; setTimeout(() => { ev.target.textContent = 'copiar'; }, 1500);
    });
    caixa.querySelector('.ot-reenviar').addEventListener('click', ev => {
      ev.preventDefault();
      const semResp = erros.filter(e => /n.o respondeu/.test(e.msg || ''));
      if (!semResp.length) return;
      erros = erros.filter(e => !semResp.includes(e));
      falhas = Math.max(0, falhas - semResp.length);
      semResp.reverse().forEach(e => fila.push(e.c));
      desenharErros(); ui.contar(); focarCampo();
      trabalhar();
    });
    caixa.querySelector('.ot-limpar-erros').addEventListener('click', ev => { ev.preventDefault(); erros = []; desenharErros(); });
    // Arrastar um .txt do buffer (ou qualquer lista de códigos) para dar entrada de novo.
    const barraArq = caixa.querySelector('.ot-arquivo');
    let codigosArquivo = [];
    const temArquivo = ev => [...(ev.dataTransfer?.types || [])].includes('Files');
    caixa.addEventListener('dragenter', ev => { if (temArquivo(ev)) { ev.preventDefault(); caixa.classList.add('ot-arrastando'); } });
    caixa.addEventListener('dragover', ev => { if (temArquivo(ev)) { ev.preventDefault(); ev.dataTransfer.dropEffect = 'copy'; } });
    caixa.addEventListener('dragleave', ev => { if (!caixa.contains(ev.relatedTarget)) caixa.classList.remove('ot-arrastando'); });
    caixa.addEventListener('drop', async ev => {
      if (!temArquivo(ev)) return;
      ev.preventDefault();
      caixa.classList.remove('ot-arrastando');
      const arq = ev.dataTransfer.files[0];
      if (!arq) return;
      if (arquivo.fase) { ui.aviso('Termine (ou cancele) o arquivo em andamento antes de soltar outro.'); return; }
      const texto = await arq.text();
      // Cada linha: código [TAB data]. A linha de título ("Entrada On Time — …") é ignorada.
      codigosArquivo = texto.split(/\r?\n/)
        .filter(l => l.trim() && !/(Entrada|Lista) On Time/i.test(l))
        .map(l => l.trim().split(/[\t;,]|\s{2,}/)[0].trim())
        .filter(c => /^[A-Za-z0-9$-]{4,}$/.test(c));
      if (!LISTA) codigosArquivo = [...new Set(codigosArquivo)];   // leituras repetidas entram uma vez só
      barraArq.hidden = false;
      barraArq.querySelector('.ot-arq-txt').textContent = codigosArquivo.length
        ? `${arq.name}: ${codigosArquivo.length} código(s) para dar entrada novamente.`
        : `${arq.name}: nenhum código encontrado no arquivo.`;
      const b = barraArq.querySelector('.ot-arq-sim');
      b.hidden = !codigosArquivo.length; b.disabled = false; b.textContent = '▶ Dar entrada em todos'; b.title = '';
    });
    const sim = barraArq.querySelector('.ot-arq-sim'), nao = barraArq.querySelector('.ot-arq-nao'), txtArq = barraArq.querySelector('.ot-arq-txt');
    /** Botão da barra conforme o passo do arquivo (Recebimento). */
    const passoArquivo = () => {
      const tot = arquivo.lotes.length, lote = tot > 1 ? ` — lote ${arquivo.n + 1} de ${tot}` : '';
      sim.disabled = false; nao.disabled = false;
      if (arquivo.fase === 'adicionar') { sim.textContent = '▶ Dar entrada em todos'; sim.title = 'Coloca os códigos no campo Remessa e clica em Adicionar'; txtArq.textContent = `${arquivo.lotes[arquivo.n].length} código(s) para dar entrada${lote}.`; }
      else if (arquivo.fase === 'processar') { sim.textContent = '▶ Processar'; sim.title = 'Clica em Processar lista'; txtArq.textContent = `${arquivo.naLista} código(s) na lista do Fraction${lote}. Confira os erros e clique em Processar.`; }
      else if (arquivo.fase === 'proximo') { sim.textContent = '▶ Próximo lote'; sim.title = ''; txtArq.textContent = `Lote ${arquivo.n + 1} de ${tot} concluído. Faltam ${tot - arquivo.n - 1} lote(s).`; }
      else { barraArq.hidden = true; encerrarArquivo(); }
    };
    sim.addEventListener('click', async () => {
      if (LISTA) { barraArq.hidden = true; if (codigosArquivo.length) receber(codigosArquivo.join('\n')); codigosArquivo = []; focarCampo(); return; }
      if (sim.disabled) return;
      sim.disabled = true; nao.disabled = true;
      if (!arquivo.fase) { if (!codigosArquivo.length) { sim.disabled = false; nao.disabled = false; return; } await iniciarArquivo(codigosArquivo); codigosArquivo = []; }
      if (arquivo.fase === 'proximo') { arquivo.n++; arquivo.fase = 'adicionar'; }
      if (arquivo.fase === 'adicionar') { sim.textContent = 'Adicionando…'; await adicionarArquivo(); }
      else if (arquivo.fase === 'processar') { sim.textContent = 'Processando…'; await processarListaArquivo(); }
      passoArquivo();
      focarCampo();
    });
    nao.addEventListener('click', () => {
      barraArq.hidden = true; codigosArquivo = [];
      if (arquivo.fase) {
        if (arquivo.fase === 'processar') ui.aviso('Arquivo cancelado: os códigos já adicionados continuam na lista do Fraction (não processados).');
        encerrarArquivo();
      }
      focarCampo();
    });

    caixa.querySelector('.ot-info').title = LISTA
      ? 'Buffer: cópia de segurança dos códigos lidos para esta lista, guardada neste navegador.\n' +
        'É esvaziado ao clicar em ▶ Processar lista. Se a página for recarregada antes de processar,\n' +
        `as leituras são salvas sozinhas num .txt (${ARQ}_…_nao_processada.txt, na pasta Downloads) e o buffer recomeça vazio.\n` +
        'Para dar entrada de novo nos códigos de um .txt, arraste o arquivo para esta janela.'
      : 'Buffer: cópia de segurança de todos os códigos lidos hoje, guardada neste navegador.\n' +
        'Se o Fraction travar ou a página recarregar, nada se perde: use "💾 Salvar códigos" para baixar o .txt.\n' +
        `Na virada do dia o buffer é salvo sozinho num .txt (${ARQ}_AAAAMMDD.txt, na pasta Downloads) e recomeça vazio.\n` +
        'Para dar entrada de novo nos códigos de um .txt, arraste o arquivo para esta janela.';
    // Lista de Entrega: Rota + Processar (o mesmo "Processar" da janela Nova lista do Fraction).
    if (LISTA) {
      const rota = caixa.querySelector('.ot-rota input'), proc = caixa.querySelector('.ot-processar');
      rota.value = $id(F + ':txtRota')?.value || '';
      rota.addEventListener('keydown', ev => ev.stopPropagation());
      const confirma = caixa.querySelector('.ot-confirma');
      const limparParaNovaLista = () => {
        erros = []; incompletos.clear(); desenharErros();
        log.innerHTML = '';
        buffer = []; gravar(CHAVE_BUFFER, buffer);
        ok = 0; falhas = 0; dups = 0; lidosSessao = 0; numLeitura = 0; corretos = 0;
        rota.value = '';
        ui.contar(); ui.atual(null);
      };
      const perguntar = (texto) => new Promise(res => {
        confirma.querySelector('.ot-c-txt').textContent = texto;
        confirma.hidden = false;
        const fim = v => { confirma.hidden = true; confirma.querySelector('.ot-c-sim').onclick = confirma.querySelector('.ot-c-nao').onclick = null; res(v); };
        confirma.querySelector('.ot-c-sim').onclick = () => fim(true);
        confirma.querySelector('.ot-c-nao').onclick = () => fim(false);
      });
      proc.title = 'Ctrl + clique: agrupar as remessas da lista por Circuit (não processa)';
      proc.addEventListener('click', async ev => {
        if (ev.ctrlKey || ev.metaKey) { agruparPorCircuit(); return; }
        if (rodando || fila.length) { ui.aviso('Espere terminar as leituras da fila antes de processar.'); return; }
        const original = $id(F + ':botao_processar_nova_lista_process');
        if (!original) { ui.aviso('Não encontrei o botão Processar da Nova lista.'); return; }
        const campoRota = $id(F + ':txtRota');
        if (campoRota) definir(campoRota, rota.value.trim());
        proc.disabled = true;
        caixa.querySelector('.ot-agora').textContent = 'Processando a lista…';
        try {
          // 1) Processar (o Fraction pode perguntar sobre remessas multi-volume faltantes).
          const r1 = esperarResposta(original.id, 60000);
          const final = esperarResposta(F + ':botao_processar_nova_lista', 90000).catch(() => null);
          clicar(original);
          const t1 = (await r1).txt;
          const args = (/<extension[^>]*type="args"[^>]*>([\s\S]*?)<\/extension>/.exec(t1) || [])[1] || '';
          if (/"mensagemAlerta"\s*:\s*true/.test(args)) {
            const upd = /<update id="confirm_dialog_delete_tracking"><!\[CDATA\[([\s\S]*?)\]\]><\/update>/.exec(t1);
            const msgDlg = (upd && new DOMParser().parseFromString(upd[1], 'text/html').querySelector('.ui-confirm-dialog-message, .ui-dialog-content')?.textContent.trim())
              || document.querySelector('#confirm_dialog_delete_tracking .ui-dialog-content')?.textContent.trim()
              || 'Existem remessas multi-volume faltantes. Deseja prosseguir?';
            const sim = await perguntar(msgDlg.replace(/\s+/g, ' '));
            if (!sim) { clicar($id('j_idt527') || [...document.querySelectorAll('#confirm_dialog_delete_tracking button')].find(b => /n.o/i.test(b.textContent))); ui.atual(null); return; }
            clicar($id('j_idt526') || [...document.querySelectorAll('#confirm_dialog_delete_tracking button')].find(b => /sim/i.test(b.textContent)));
          }
          // 2) Resultado do processamento.
          const r2 = await final;
          if (!r2) throw new Error('o Fraction não respondeu ao processar');
          const msgs = mensagens(r2.txt);
          const erro = msgs.filter(m => /error|fatal/.test(m.nivel) || /erro|n.o\s+foi|inv.lid/i.test(m.texto));
          if (erro.length) {
            erros.unshift({ c: 'Processar lista', t: agora(), msg: erro.map(m => m.texto).join(' · ') });
            desenharErros(); ui.atual(null);
            return;
          }
          // 3) Lista criada: a janela continua aberta e limpa para a próxima lista.
          const info = msgs.map(m => m.texto).join(' · ');
          limparParaNovaLista();
          caixa.querySelector('.ot-agora').textContent = '✔ Lista processada' + (info ? ': ' + info : '.') + ' Pronto para a próxima lista.';
          // Abre de novo a "Nova lista" do Fraction para as próximas leituras.
          const b = botaoNovaLista();
          if (b) { const r = esperarResposta(b.id, 15000).catch(() => null); clicar(b); await r; mostrarTodasAsLinhas(); }
        } catch (e) {
          erros.unshift({ c: 'Processar lista', t: agora(), msg: e.message });
          desenharErros(); ui.atual(null);
        } finally {
          proc.disabled = false;
          focarCampo();
        }
      });
    }
    // Mantém o cursor no campo de leitura.
    caixa.addEventListener('mouseup', ev => { if (!ev.target.closest('a, button, input, label, .ot-erros, .ot-log')) campo.focus(); });

    // Ctrl + Processar: as remessas da lista agrupadas por Circuit, na coluna da esquerda.
    const circ = caixa.querySelector('.ot-circ');
    let agrupando = false;
    const mostrarLeituras = () => { circ.hidden = true; log.hidden = false; };
    async function agruparPorCircuit() {
      if (agrupando) return;
      if (rodando || fila.length) { ui.aviso('Espere terminar as leituras da fila antes de agrupar.'); return; }
      agrupando = true;
      try {
        if (maisLinhasNecessario()) { const rp = esperarResposta(F + ':dataListaEnvioRemessa', 10000).catch(() => null); mostrarTodasAsLinhas(); await rp; }
        const rems = remessasDaLista();
        log.hidden = true; circ.hidden = false;
        circ.innerHTML = '<div class="ot-circ-topo"><b>Agrupado por Circuit</b> <span class="ot-circ-prog"></span><a href="#" class="ot-circ-voltar">voltar às leituras</a></div><div class="ot-circ-grupos"></div>';
        circ.querySelector('.ot-circ-voltar').addEventListener('click', e => { e.preventDefault(); mostrarLeituras(); focarCampo(); });
        const prog = circ.querySelector('.ot-circ-prog');
        if (!rems.size) { prog.textContent = '— nenhuma remessa na lista.'; return; }
        const lista = [...rems.keys()], achados = new Map(), motivos = new Map();
        prog.textContent = '— lendo o arquivo da Performance…';
        let resp;
        try { resp = await circuitsDaPerformance(lista); }
        catch (e) {
          prog.textContent = '';
          const aviso = document.createElement('p'); aviso.className = 'ot-circ-aviso';
          aviso.textContent = e.message === 'sem_arquivo'
            ? 'Ainda não há arquivo da Performance guardado. Abra Gerencial › Performance de Entrega, processe e clique em "📊 Dashboard"; depois volte aqui e use Ctrl + Processar de novo.'
            : 'Não consegui ler o arquivo da Performance: ' + e.message;
          circ.querySelector('.ot-circ-grupos').appendChild(aviso);
          return;
        }
        lista.forEach(rem => achados.set(rem, Object.prototype.hasOwnProperty.call(resp.achados, rem) ? resp.achados[rem] : null));
        const dataArq = resp.quando ? new Date(resp.quando) : null;
        const quandoTxt = dataArq ? dataArq.toLocaleDateString('pt-BR') + ' ' + dataArq.toLocaleTimeString('pt-BR').slice(0, 5) : '';
        // Monta os grupos (sem Circuit / erro no fim).
        const grupos = new Map();
        lista.forEach(rem => { const c = achados.get(rem); const k = c === null ? '\u0002' : (c || '\u0001'); if (!grupos.has(k)) grupos.set(k, []); grupos.get(k).push(rem); });
        const ordem = k => (k === '\u0002' ? 2 : k === '\u0001' ? 1 : 0);
        const chaves = [...grupos.keys()].sort((a, b) => ordem(a) - ordem(b) || a.localeCompare(b, 'pt-BR', { numeric: true }));
        const caixaG = circ.querySelector('.ot-circ-grupos');
        chaves.forEach(k => {
          const nome = k === '\u0002' ? 'Fora do arquivo da Performance' : k === '\u0001' ? 'Sem Circuit' : 'Circuit ' + k;
          const sec = document.createElement('section'); sec.className = 'ot-circ-grupo' + (k === '\u0002' ? ' ot-circ-falha' : '');
          const h = document.createElement('h4'); sec.appendChild(h);
          const dobra = document.createElement('button'); dobra.type = 'button'; dobra.className = 'ot-circ-dobra'; dobra.textContent = '−'; dobra.title = 'Recolher';
          const tit = document.createElement('span');
          h.append(dobra, tit);
          h.addEventListener('click', ev3 => {
            ev3.preventDefault();
            const fechado = sec.classList.toggle('ot-circ-fechado');
            dobra.textContent = fechado ? '+' : '−'; dobra.title = fechado ? 'Expandir' : 'Recolher';
          });
          const ul = document.createElement('ul');
          const contar = () => { tit.textContent = `${nome} — ${ul.children.length} remessa(s)`; if (!ul.children.length) sec.remove(); };
          grupos.get(k).forEach(rem => {
            const li = document.createElement('li');
            const x = document.createElement('button'); x.type = 'button'; x.className = 'ot-l-x'; x.textContent = '✕';
            x.title = 'Excluir da lista todos os volumes da remessa ' + rem;
            const a = document.createElement('a'); a.className = 'ot-l-cod'; a.textContent = rem;
            a.href = location.origin + '/FractionWeb/jad/tracking?cte=' + rem; a.target = '_blank'; a.rel = 'noopener';
            a.title = 'Abrir a consulta da remessa em nova aba';
            const v = document.createElement('span'); v.className = 'ot-circ-vol';

            const e = rems.get(rem); v.textContent = e.total > 1 ? `${e.lidos} de ${e.total} vol.` : '';
            x.addEventListener('click', async ev2 => {
              ev2.preventDefault(); ev2.stopPropagation();
              if (x.disabled) return;
              x.disabled = true; x.textContent = '…';
              const r = await excluirRemessa(rem);
              registrarExclusao(rem, r);
              if (!r.erro) { li.remove(); contar(); prog.textContent = `— ${circ.querySelectorAll('.ot-circ-grupo li').length} remessa(s) em ${circ.querySelectorAll('.ot-circ-grupo').length} grupo(s)`; }
              else { x.disabled = false; x.textContent = '✕'; }
            });
            li.append(x, a, v);
            if (motivos.has(rem)) { const mo = document.createElement('span'); mo.className = 'ot-circ-motivo'; mo.textContent = motivos.get(rem); li.append(mo); }
            ul.appendChild(li);
          });
          sec.appendChild(ul); caixaG.appendChild(sec); contar();
        });
        const nGrupos = chaves.filter(k => k !== '\u0002').length;
        prog.textContent = `— ${lista.length} remessa(s) em ${nGrupos} circuit(s)` + (quandoTxt ? ` · Performance de ${quandoTxt}` : '');
        if (grupos.has('\u0002')) {
          const aviso = document.createElement('p'); aviso.className = 'ot-circ-aviso';
          aviso.textContent = `${grupos.get('\u0002').length} remessa(s) não estão no arquivo da Performance${quandoTxt ? ' de ' + quandoTxt : ''} (chegaram depois dele). Para incluí-las, gere o Dashboard da Performance de Entrega de novo depois da próxima atualização do Fraction.`;
          caixaG.appendChild(aviso);
        }
      } finally { agrupando = false; focarCampo(); }
    }
    /** Lista: só as leituras certas que continuam na lista levam número (a mais nova = total de corretos). */
    function renumerar() {
      let n = corretos;
      [...log.children].forEach(li => {
        const vale = li.classList.contains('ot-ok') && !li.classList.contains('ot-excluida');
        li.classList.toggle('ot-sem-num', !vale);
        if (vale) li.value = Math.max(n--, 1);
      });
    }
    function registrarExclusao(remessa, r) {
      if (r.erro) {
        const li2 = document.createElement('li');
        li2.className = 'ot-erro';
        li2.innerHTML = '<span class="ot-l-cod ot-l-sem-x"></span> <span class="ot-l-msg"></span>';
        li2.querySelector('.ot-l-cod').textContent = remessa;
        li2.querySelector('.ot-l-msg').textContent = `✖ Exclusão incompleta (${r.n} excluído(s)): ${r.erro}`;
        log.prepend(li2);
      } else {
        // As leituras desta remessa passam a "Excluído da lista", com a remessa riscada.
        log.querySelectorAll('li').forEach(li => {
          const a = li.querySelector('a.ot-l-cod');
          if (!a || a.textContent !== remessa || li.classList.contains('ot-erro')) return;
          if (li.classList.contains('ot-ok') && !li.classList.contains('ot-excluida')) corretos = Math.max(0, corretos - 1);
          li.classList.add('ot-excluida');
          li.querySelector('.ot-l-msg').textContent = 'Excluído da lista';
        });
        renumerar();
      }
      desenharErros(); ui.contar(); focarCampo();
      if (fila.length) trabalhar();
    }
    function desenharErros() {
      listaErros.innerHTML = '';
      // Remessas multi-volume ainda incompletas (somem quando todos os volumes forem lidos).
      let nInc = 0;
      incompletos.forEach((e, remessa) => {
        if (!e.incompleto) return;
        nInc++;
        const li = document.createElement('li');
        const cartao = document.createElement('a');
        cartao.className = 'ot-e-cartao ot-e-incompleta';
        cartao.href = location.origin + '/FractionWeb/jad/tracking?cte=' + remessa;
        cartao.target = '_blank'; cartao.rel = 'noopener';
        cartao.title = 'Abrir a consulta da remessa ' + remessa;
        const lidos = Math.min(e.vols.size, e.total), faltam = Math.max(0, e.total - e.vols.size);
        cartao.innerHTML = '<span class="ot-e-cod">Remessa incompleta</span><div class="ot-e-msg"></div>';
        cartao.querySelector('.ot-e-msg').textContent = `${remessa} — ${lidos} de ${e.total} volume(s) lido(s) · falta(m) ${faltam || '?'}`;
        li.className = 'ot-li-inc';
        li.appendChild(cartao);
        // Excluir: tira da lista todos os volumes já lidos desta remessa.
        const exc = document.createElement('button');
        exc.type = 'button'; exc.className = 'ot-excluir'; exc.textContent = 'Excluir';
        exc.title = `Tirar da lista os ${lidos} volume(s) da remessa ${remessa}`;
        exc.addEventListener('click', async ev => {
          ev.preventDefault(); ev.stopPropagation();
          if (exc.disabled) return;
          exc.disabled = true; exc.textContent = 'Excluindo…';
          const r = await excluirRemessa(remessa);
          registrarExclusao(remessa, r);
        });
        // Completar: adiciona os volumes que faltam (remessa + 001, 002, …). Pede um 2º clique para confirmar.
        const faltantes = [];
        for (let v = 1; v <= e.total; v++) if (!e.vols.has(v)) faltantes.push(remessa + String(v).padStart(3, '0'));
        const comp = document.createElement('button');
        comp.type = 'button'; comp.className = 'ot-completar'; comp.textContent = 'Completar';
        comp.title = faltantes.length ? `Adicionar à lista o(s) volume(s) que falta(m): ${faltantes.join(', ')}` : 'Nenhum volume faltante identificado';
        comp.disabled = !faltantes.length;
        let tConf = 0;
        comp.addEventListener('click', ev => {
          ev.preventDefault(); ev.stopPropagation();
          if (comp.disabled) return;
          if (!comp.classList.contains('ot-confirmar')) {
            comp.classList.add('ot-confirmar'); comp.textContent = `Confirmar (${faltantes.length})`;
            tConf = setTimeout(() => { comp.classList.remove('ot-confirmar'); comp.textContent = 'Completar'; }, 4000);
            return;
          }
          clearTimeout(tConf);
          comp.disabled = true; comp.textContent = 'Adicionando…';
          receber(faltantes.join(' '));
          focarCampo();
        });
        const acoes = document.createElement('div');
        acoes.className = 'ot-acoes';
        acoes.append(exc, comp);
        li.appendChild(acoes);
        listaErros.appendChild(li);
      });
      listaErros.dataset.inc = nInc;
      erros.forEach(e => {
        const li = document.createElement('li');
        // O cartão inteiro é o link: remessa/CT-e (14 dígitos, no código ou na mensagem) abre a consulta
        // da remessa; chave de NF-e (44 dígitos) abre a Consulta pela Nota Fiscal (últimos 30 dias).
        const destino = destinoDoErro(e);
        const cartao = document.createElement(destino ? 'a' : 'div');
        cartao.className = 'ot-e-cartao';
        cartao.innerHTML = '<span class="ot-e-cod"></span><span class="ot-e-hora"></span><div class="ot-e-msg"></div>';
        cartao.querySelector('.ot-e-cod').textContent = e.c;
        cartao.querySelector('.ot-e-hora').textContent = e.t;
        cartao.querySelector('.ot-e-msg').textContent = e.msg || '';
        if (destino && destino.cte) {
          cartao.href = location.origin + '/FractionWeb/jad/tracking?cte=' + destino.cte;
          cartao.target = '_blank'; cartao.rel = 'noopener';
          cartao.title = 'Abrir a consulta da remessa ' + destino.cte;
        } else if (destino && destino.nf) linkNotaFiscal(cartao, destino.nf);
        li.appendChild(cartao);
        listaErros.appendChild(li);
      });
      caixa.querySelector('.ot-reenviar').hidden = !erros.some(e => /n.o respondeu/.test(e.msg || ''));
      const tot = erros.length + (+listaErros.dataset.inc || 0);
      caixa.querySelector('.ot-nerros').textContent = tot ? String(tot) : '';
    }
    ui.contar = () => {
      caixa.querySelector('.ot-cont').textContent = `lidos ${lidosSessao} · ✔ ${ok} · ✖ ${falhas}` + (dups ? ` · ! ${dups} duplicada(s)` : '') + (fila.length ? ` · na fila ${fila.length}` : '');
      caixa.querySelector('.ot-buffer').textContent = `Buffer: ${buffer.length} código(s) guardados neste navegador`;
    };
    ui.desenharErros = desenharErros;
    ui.aviso = t => { const el = caixa.querySelector('.ot-buffer'); el.textContent = t; setTimeout(() => ui.contar(), 8000); };
    ui.atual = c => { caixa.querySelector('.ot-agora').textContent = c ? `Processando ${c}…` : (fila.length ? '' : (LISTA ? 'Pronto para ler. Ao terminar, informe a Rota e clique em ▶ Processar lista.' : 'Pronto para ler.')); ui.contar(); };
    ui.resultado = (c, r) => {
      if (LISTA) {
        if (r.ok && !r.dup) corretos++;
        if (r.ok && !r.dup && modoSom() === 'n') falarNumero(corretos);
        else bipe(r.ok ? (r.dup ? 'dup' : 'ok') : 'erro');
      }
      mostrarLeituras();
      setTimeout(focarCampo, 0);
      const li = document.createElement('li');
      li.className = r.dup ? 'ot-dup' : r.ok ? 'ot-ok' : 'ot-erro';
      li.innerHTML = ' <span class="ot-l-msg"></span>';
      if (LISTA && r.remessa) {
        // Lista: mostra a remessa da lista do Fraction (link para a consulta) e um ✕ para tirá-la da lista.
        const a = document.createElement('a'); a.className = 'ot-l-cod'; a.textContent = r.remessa;
        a.href = location.origin + '/FractionWeb/jad/tracking?cte=' + r.remessa; a.target = '_blank'; a.rel = 'noopener';
        a.title = 'Código lido: ' + c + ' — abrir a consulta da remessa em nova aba';
        li.prepend(a);
        const x = document.createElement('button'); x.type = 'button'; x.className = 'ot-l-x'; x.textContent = '✕';
        x.title = 'Excluir da lista todos os volumes da remessa ' + r.remessa;
        x.addEventListener('click', async ev => {
          ev.preventDefault(); ev.stopPropagation();
          if (x.disabled) return;
          x.disabled = true; x.textContent = '…';
          const rr = await excluirRemessa(r.remessa);
          registrarExclusao(r.remessa, rr);
          x.textContent = '✕';
          x.disabled = false;
        });
        if (r.ok) li.prepend(x); else a.classList.add('ot-l-sem-x');
      } else {
        const sp = document.createElement('span'); sp.className = 'ot-l-cod'; sp.textContent = c; li.prepend(sp);
      }
      // Esquerda: só o resultado curto; o erro completo fica no painel da direita.
      li.querySelector('.ot-l-msg').textContent = r.dup ? '! Leitura duplicada' : r.ok ? '✔ ' + (r.msg || 'salvo com sucesso.') : '✖ Erro';
      li.title = r.dup ? 'Este volume já estava na lista: não foi adicionado de novo.' : r.ok ? (r.detalhe || '') : (r.msg || '');
      log.prepend(li);
      // Número fixo da leitura na sessão (continua sequencial quando as antigas saem da tela).
      if (LISTA) renumerar(); else li.value = ++numLeitura;
      while (log.children.length > 500) log.lastChild.remove();
      if (!r.ok || LISTA) desenharErros();
      ui.contar();
    };
    desenharErros();
    ui.contar();
    ui.atual(null);
    return caixa;
  }

  const p2 = n => String(n).padStart(2, '0');
  const diaDe = iso => { const d = new Date(iso); return `${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())}`; };
  const hojeStr = () => diaDe(new Date().toISOString());

  /** Baixa um .txt com os códigos (lista = itens do buffer; nome conforme o dia ou a hora). */
  function baixarTxt(lista, nome, titulo) {
    const linhas = lista.map(b => `${b.c}\t${new Date(b.t).toLocaleString('pt-BR')}`);
    const blob = new Blob([`${titulo} — ${lista.length} código(s)\r\n` + linhas.join('\r\n') + '\r\n'], { type: 'text/plain;charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = nome;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 5000);
  }

  function salvar() {
    const d = new Date();
    baixarTxt(buffer, `${ARQ}_${d.getFullYear()}${p2(d.getMonth() + 1)}${p2(d.getDate())}_${p2(d.getHours())}${p2(d.getMinutes())}.txt`,
      `${NOME} — salvo em ${d.toLocaleString('pt-BR')}`);
  }

  /**
   * Virada do dia: os códigos de dias anteriores são salvos automaticamente num .txt por dia
   * (EntradaOnTime_AAAAMMDD.txt) e saem do buffer, que recomeça com os de hoje.
   */
  function virarDia() {
    const hoje = hojeStr();
    const antigos = buffer.filter(b => diaDe(b.t) !== hoje);
    if (!antigos.length) return;
    const porDia = new Map();
    antigos.forEach(b => { const k = diaDe(b.t); if (!porDia.has(k)) porDia.set(k, []); porDia.get(k).push(b); });
    porDia.forEach((lista, dia) => {
      const [y, m, d] = dia.split('-');
      baixarTxt(lista, `${ARQ}_${y}${m}${d}.txt`, `${NOME} — ${d}/${m}/${y} (salvo automaticamente na virada do dia)`);
    });
    buffer = buffer.filter(b => diaDe(b.t) === hoje);
    gravar(CHAVE_BUFFER, buffer);
    if (ui.contar) ui.contar();
    if (ui.aviso) ui.aviso(`Buffer de ${[...porDia.keys()].map(k => k.split('-').reverse().slice(0, 2).join('/')).join(', ')} salvo em .txt e zerado.`);
  }


  let janela = null;
  /*
   * Foco sempre no campo de leitura enquanto a janela está aberta: o Fraction devolve, a cada
   * Adicionar/Processar, um script que põe o foco no campo Remessa dele (PrimeFaces.focus).
   */
  const aberta = () => janela && !janela.hidden;
  const focarCampo = () => { if (aberta()) { const c = janela.querySelector('#ot-campo'); if (c && document.activeElement !== c) c.focus({ preventScroll: true }); } };
  document.addEventListener('focusin', ev => {
    if (aberta() && !janela.contains(ev.target)) setTimeout(focarCampo, 0);
  }, true);
  (function travarFocoDoFraction() {
    const pf = window.PrimeFaces;
    if (!pf || typeof pf.focus !== 'function' || pf.focus.__tf) { if (!pf) setTimeout(travarFocoDoFraction, 300); return; }
    const original = pf.focus;
    pf.focus = function () { if (aberta()) { focarCampo(); return; } return original.apply(this, arguments); };
    pf.focus.__tf = true;
  })();

  /** Lista de Entrega: botão "Adicionar" da tela (abre a janela "Nova lista" do Fraction). */
  const botaoNovaLista = () => [...($id('form_lista_entrega')?.querySelectorAll('button') || [])].find(b => /^\s*Adicionar\s*$/.test(b.textContent) && /NovaLista/i.test(b.getAttribute('onclick') || ''));
  const novaListaAberta = () => { const t = $id(ID.texto); return !!(t && t.offsetParent); };

  async function abrir() {
    if (LISTA && !novaListaAberta()) {
      const b = botaoNovaLista();
      if (b) {
        const resp = esperarResposta(b.id, 15000).catch(() => null);
        clicar(b);
        await Promise.race([resp, esperar(15000)]);
        for (let i = 0; i < 30 && !$id(ID.texto); i++) await esperar(200);
      }
    }
    if (LISTA) mostrarTodasAsLinhas();
    if (!janela) janela = montar();
    virarDia();
    janela.hidden = false;
    document.documentElement.classList.add('tf-ontime-aberto');
    janela.querySelector('#ot-campo').focus();
  }
  function fechar() {
    if (janela) janela.hidden = true;
    document.documentElement.classList.remove('tf-ontime-aberto');
  }

  function colocarBotao() {
    if ($id('tf-ontime-botao')) return;
    if (LISTA) {
      const add = botaoNovaLista();
      if (!add) return;
      const b = document.createElement('button');
      b.id = 'tf-ontime-botao';
      b.type = 'button';
      b.className = 'ui-button ui-widget ui-corner-all ui-button-text-only tf-ontime-vermelho';
      b.innerHTML = '<span class="ui-button-text ui-c">On Time</span>';
      b.title = 'Lista On Time: lê os códigos um a um e adiciona cada um à nova lista automaticamente';
      b.addEventListener('click', abrir);
      add.after(b);
      return;
    }
    const proc = $id(ID.processar);
    if (!proc) return;
    const b = document.createElement('button');
    b.id = 'tf-ontime-botao';
    b.type = 'button';
    b.className = 'ui-button ui-widget ui-corner-all ui-button-text-only tf-ontime-vermelho';
    b.innerHTML = '<span class="ui-button-text ui-c">On Time</span>';
    b.title = 'Entrada On Time: lê os códigos um a um e adiciona e processa cada um automaticamente';
    b.addEventListener('click', abrir);
    const td = document.createElement('td');
    td.appendChild(b);
    proc.closest('tr') ? proc.closest('tr').appendChild(td) : proc.after(b);
    // A tabela dos botões tem largura fixa (230px): deixa crescer para os três caberem numa linha só.
    const tab = proc.closest('table'); if (tab) { tab.removeAttribute('width'); tab.style.width = 'auto'; }
    centralizar();
  }

  /** Centraliza a linha de botões em relação ao quadro "Leitura a partir da etiqueta" logo abaixo. */
  function centralizar() {
    if (LISTA) return;
    const tab = $id(ID.processar)?.closest('table');
    const quadro = $id(ID.texto)?.closest('table.ui-panelgrid') || $id(ID.texto)?.closest('table');
    if (!tab || !quadro) return;
    const rq = quadro.getBoundingClientRect(), rt = tab.getBoundingClientRect();
    if (!rq.width || !rt.width) return;
    const atual = parseFloat(getComputedStyle(tab).marginLeft) || 0;
    const novo = Math.max(0, Math.round(atual + (rq.left + rq.width / 2) - (rt.left + rt.width / 2)));
    if (Math.abs(novo - atual) > 1) tab.style.marginLeft = novo + 'px';
  }

  // Lista de Entrega: cada lista começa com o buffer vazio. Se a página for recarregada com leituras
  // ainda não processadas, elas são salvas num .txt antes de limpar (para não perder nada se o Fraction travar).
  if (LISTA && buffer.length) {
    const d = new Date();
    baixarTxt(buffer, `${ARQ}_${d.getFullYear()}${p2(d.getMonth() + 1)}${p2(d.getDate())}_${p2(d.getHours())}${p2(d.getMinutes())}_nao_processada.txt`,
      `${NOME} — leituras não processadas, salvas ao recarregar a página em ${d.toLocaleString('pt-BR')}`);
    buffer = []; gravar(CHAVE_BUFFER, buffer);
  }

  colocarBotao();
  addEventListener('resize', centralizar);
  new MutationObserver(() => { colocarBotao(); centralizar(); }).observe(document.body, { childList: true, subtree: true });
})();
