// TurboFraction — Emissão (mundo da página): conta as requisições ajax do PrimeFaces em andamento
// em <html data-tf-ajax="n">, para o script da extensão saber quando o Fraction terminou de responder.
(() => {
  'use strict';
  let n = 0;
  const marca = () => { document.documentElement.dataset.tfAjax = String(n); };
  function ligar() {
    const $ = window.jQuery;
    if (!$) return false;
    $(document).on('pfAjaxSend', () => { n++; marca(); });
    $(document).on('pfAjaxComplete', () => { n = Math.max(0, n - 1); marca(); });
    marca();
    return true;
  }
  if (!ligar()) { let k = 0; const t = setInterval(() => { if (ligar() || ++k > 40) clearInterval(t); }, 250); }
})();
