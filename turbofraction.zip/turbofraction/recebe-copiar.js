/*
 * TurboFraction — Recebimento de Remessa (/FractionWeb/pages/recebeRemessa/recebe.jad)
 * Ctrl + Shift + C copia para a área de transferência todos os números da coluna REMESSA da lista
 * (todas as páginas da tabela, sem repetir).
 * O número da remessa na tabela é link para a consulta (outra aba).
 */
(() => {
  'use strict';
  const TAB = 'form_recebe_remessa:dataListaRecebeRemessa';
  const esperar = ms => new Promise(r => setTimeout(r, ms));
  const corpo = () => document.getElementById(TAB + '_data');
  const pag = () => document.getElementById(TAB + '_paginator_bottom');

  function aviso(msg, erro) {
    let d = document.getElementById('tf-rc-aviso');
    if (!d) { d = document.createElement('div'); d.id = 'tf-rc-aviso'; document.body.appendChild(d); }
    d.style.cssText = 'position:fixed;top:14px;left:50%;transform:translateX(-50%);z-index:99999;padding:10px 18px;border-radius:6px;color:#fff;font:bold 13px Arial,sans-serif;box-shadow:0 3px 12px rgba(0,0,0,.3);background:' + (erro ? '#C8102E' : '#1d7a35');
    d.textContent = msg; d.hidden = false;
    clearTimeout(d._t); d._t = setTimeout(() => { d.hidden = true; }, 3500);
  }

  function colunaRemessa() {
    const ths = [...document.querySelectorAll('[id="' + TAB + '"] thead th, [id="' + TAB + '_head"] th')];
    const i = ths.findIndex(th => /^\s*remessa/i.test(th.textContent));
    return i >= 0 ? i : 1;
  }
  function lerPagina(col, set) {
    [...(corpo()?.rows || [])].forEach(tr => {
      const v = tr.cells[col] ? tr.cells[col].textContent.trim() : '';
      if (/^\d{6,}$/.test(v)) set.add(v);
    });
  }
  /** Espera a tabela ser redesenhada pelo Fraction depois de um clique. */
  function esperarTabela(acao, limite = 8000) {
    return new Promise(ok => {
      const alvo = document.getElementById(TAB) || document.body;
      let fim;
      const obs = new MutationObserver(() => { clearTimeout(fim); fim = setTimeout(() => { obs.disconnect(); ok(true); }, 250); });
      obs.observe(alvo.parentElement || alvo, { childList: true, subtree: true });
      setTimeout(() => { obs.disconnect(); ok(false); }, limite);
      acao();
    });
  }

  let copiando = false;
  async function copiar() {
    if (copiando) return;
    copiando = true;
    try {
      const col = colunaRemessa();
      const set = new Set();
      lerPagina(col, set);
      // Mais de uma página: passa por todas (e volta para a primeira).
      const paginas = () => [...(pag()?.querySelectorAll('.ui-paginator-page') || [])];
      if (paginas().length > 1) {
        aviso('Lendo todas as páginas da lista…');
        const total = paginas().length;
        for (let i = 0; i < total; i++) {
          const a = paginas()[i];
          if (!a) break;
          if (!a.classList.contains('ui-state-active')) await esperarTabela(() => a.click());
          lerPagina(col, set);
        }
        const primeira = paginas()[0];
        if (primeira && !primeira.classList.contains('ui-state-active')) await esperarTabela(() => primeira.click());
      }
      if (!set.size) { aviso('Nenhuma remessa na lista para copiar.', true); return; }
      const texto = [...set].join('\n');
      let ok = false;
      try { await navigator.clipboard.writeText(texto); ok = true; }
      catch (e) {
        const ta = document.createElement('textarea'); ta.value = texto; ta.style.position = 'fixed'; ta.style.opacity = '0';
        document.body.appendChild(ta); ta.select(); try { ok = document.execCommand('copy'); } catch (e2) { /* nada */ } ta.remove();
      }
      aviso(ok ? `✔ ${set.size} remessa(s) copiada(s)` : 'Não consegui copiar.', !ok);
    } finally { copiando = false; }
  }

  // Atalho: Ctrl + Shift + C (em qualquer lugar da tela).
  document.addEventListener('keydown', ev => {
    if (ev.ctrlKey && ev.shiftKey && !ev.altKey && (ev.key === 'C' || ev.key === 'c' || ev.code === 'KeyC')) {
      ev.preventDefault(); ev.stopPropagation();
      copiar();
    }
  }, true);

  // Número da remessa na tabela vira link para a consulta (outra aba).
  function linkarRemessas() {
    const c = corpo(); if (!c) return;
    const col = colunaRemessa();
    [...c.rows].forEach(tr => {
      const td = tr.cells[col];
      if (!td || td.children.length || td.dataset.tfRem) return;
      const n = td.textContent.trim();
      if (!/^\d{14}$/.test(n)) return;
      td.dataset.tfRem = '1';
      const l = document.createElement('a');
      l.href = location.origin + '/FractionWeb/jad/tracking?cte=' + n;
      l.target = '_blank'; l.rel = 'noopener';
      l.textContent = n;
      l.title = 'Abrir a consulta da remessa ' + n + ' em outra aba';
      l.style.cssText = 'color:#c8102e;font-weight:600;text-decoration:underline';
      l.addEventListener('click', ev => ev.stopPropagation());
      td.textContent = ''; td.appendChild(l);
    });
  }
  let tL = 0;
  new MutationObserver(() => { clearTimeout(tL); tL = setTimeout(linkarRemessas, 100); }).observe(document.body, { childList: true, subtree: true });
  linkarRemessas();

})();
