/*
 * TurboFraction — textos prontos para "Incluir Observação" (consulta da remessa)
 * Alt + T abre o cartão com os textos guardados: + adiciona, ✎ edita, 🗑 exclui, ➤ envia.
 * Enviar: abre "Incluir Observação", preenche a Descrição (e o Status, se o texto tiver um) e clica em Salvar.
 */
(() => {
  'use strict';
  const CHAVE = 'tf_obs_textos';
  const PENDENTE = 'tf_obs_pendente';
  const STATUS = ['INICIADO', 'EM ANDAMENTO', 'AGUARDANDO INFORMACOES DO REMETENTE', 'AGUARDANDO INFORMACOES DO DESTINATARIO', 'AGUARDANDO LIBERACAO', 'FINALIZADO', 'ENVIADO PELO MOTORISTA'];
  const esperar = ms => new Promise(r => setTimeout(r, ms));
  let textos = [];

  const carregar = async () => { try { textos = (await chrome.storage.local.get(CHAVE))[CHAVE] || []; } catch (e) { textos = []; } };
  const gravar = () => { try { chrome.storage.local.set({ [CHAVE]: textos }); } catch (e) { /* ok */ } };
  const formObs = () => document.getElementById('form_add_obs');
  const botaoIncluir = () => [...document.querySelectorAll('button, a')].find(b => /^Incluir Observa/i.test((b.textContent || '').trim()));

  function faixa(msg, erro) {
    let d = document.getElementById('tf-obs-aviso');
    if (!d) { d = document.createElement('div'); d.id = 'tf-obs-aviso'; document.body.appendChild(d); }
    d.className = erro ? 'erro' : '';
    d.textContent = msg; d.hidden = false;
    clearTimeout(d._t); d._t = setTimeout(() => { d.hidden = true; }, 4000);
  }

  /* ---------- Preencher e salvar na tela "Inclusão de Observação" ---------- */
  async function escolherStatus(nome) {
    const sel = document.getElementById('form_add_obs:statusOco_input');
    if (!sel || !nome) return true;
    const i = [...sel.options].findIndex(o => o.text.trim().toUpperCase() === nome.toUpperCase());
    if (i < 0) return false;
    const item = document.querySelectorAll('[id="form_add_obs:statusOco_items"] li')[i];
    if (item) item.click();
    else { sel.selectedIndex = i; sel.dispatchEvent(new Event('change', { bubbles: true })); }
    await esperar(300);
    return true;
  }
  async function preencherESalvar(p) {
    const ta = document.getElementById('form_add_obs:descObsv');
    const salvar = [...(formObs()?.querySelectorAll('button') || [])].find(b => /^Salvar$/i.test(b.textContent.trim()));
    if (!ta || !salvar) { faixa('Não encontrei os campos da observação.', true); return; }
    if (!(await escolherStatus(p.status))) { faixa('Status "' + p.status + '" não existe nesta tela; confira e salve.', true); }
    ta.value = p.texto;
    ['input', 'keyup', 'change'].forEach(t => ta.dispatchEvent(new Event(t, { bubbles: true })));
    if (p.salvar === false) { faixa('Texto preenchido. Confira e clique em Salvar.'); return; }
    faixa('Salvando a observação…');
    await esperar(300);
    salvar.click();
  }
  // Ao abrir a tela de inclusão (vindo do "Enviar"), preenche e salva.
  async function verPendente() {
    if (!formObs()) return;
    let p = null;
    try { p = JSON.parse(sessionStorage.getItem(PENDENTE) || 'null'); } catch (e) { /* ok */ }
    if (!p || Date.now() - p.t > 60000) return;
    sessionStorage.removeItem(PENDENTE);
    await esperar(400);
    preencherESalvar(p);
  }

  async function enviar(t) {
    fecharCartao();
    const p = { texto: t.texto, status: t.status || '', t: Date.now() };
    if (formObs()) { preencherESalvar(p); return; }           // já está na tela de inclusão
    const b = botaoIncluir();
    if (!b) { faixa('Não encontrei o botão "Incluir Observação" nesta tela.', true); return; }
    try { sessionStorage.setItem(PENDENTE, JSON.stringify(p)); } catch (e) { /* ok */ }
    faixa('Abrindo "Incluir Observação"…');
    b.click();
    // A inclusão pode abrir na mesma página (sem recarregar): espera o formulário aparecer.
    for (let i = 0; i < 60; i++) { await esperar(250); if (formObs()) { verPendente(); return; } }
  }

  /* ---------- Cartão (Alt + T) ---------- */
  function fecharCartao() { document.getElementById('tf-obs-fundo')?.remove(); document.removeEventListener('keydown', escCartao, true); }
  function escCartao(ev) { if (ev.key === 'Escape') { ev.stopPropagation(); fecharCartao(); } }

  function abrirCartao() {
    if (document.getElementById('tf-obs-fundo')) { fecharCartao(); return; }
    const fundo = document.createElement('div');
    fundo.id = 'tf-obs-fundo';
    fundo.innerHTML = `
      <div class="tf-obs-cartao" role="dialog" aria-label="Textos de observação">
        <div class="tf-obs-topo"><b>Textos de observação</b><span class="tf-obs-dica">Alt + T</span>
          <button type="button" class="tf-obs-mais" title="Adicionar texto">+</button>
          <button type="button" class="tf-obs-x" title="Fechar (Esc)">✕</button></div>
        <input type="search" class="tf-obs-busca" placeholder="Pesquisar">
        <div class="tf-obs-editor" hidden>
          <input class="tf-obs-tit" maxlength="60" placeholder="Título (ex.: T1, AT1 - LUCAS)">
          <textarea class="tf-obs-txt" rows="4" placeholder="Texto da observação"></textarea>
          <label>Status <select class="tf-obs-st"><option value="">(manter o da tela)</option>${STATUS.map(s => `<option>${s}</option>`).join('')}</select></label>
          <div class="tf-obs-ed-acoes"><button type="button" class="tf-obs-cancelar">Cancelar</button><button type="button" class="tf-obs-salvar">Salvar texto</button></div>
        </div>
        <ul class="tf-obs-lista"></ul>
        <div class="tf-obs-rodape" title="Cópia dos textos prontos e dos motoristas dos PUDOs"><span>Backup:</span><button type="button" class="tf-obs-exp">⬇ Exportar</button><button type="button" class="tf-obs-imp">⬆ Importar</button><span class="tf-obs-bk-msg"></span></div>
      </div>`;
    const q = s => fundo.querySelector(s);
    const lista = q('.tf-obs-lista'), editor = q('.tf-obs-editor'), busca = q('.tf-obs-busca');
    let editando = null;

    function abrirEditor(t) {
      editando = t || null;
      q('.tf-obs-tit').value = t ? t.titulo : '';
      q('.tf-obs-txt').value = t ? t.texto : '';
      q('.tf-obs-st').value = t ? (t.status || '') : '';
      editor.hidden = false;
      q('.tf-obs-tit').focus();
    }
    function desenhar() {
      const f = busca.value.trim().toLowerCase();
      lista.innerHTML = '';
      const vis = textos.filter(t => !f || (t.titulo + ' ' + t.texto).toLowerCase().includes(f));
      if (!vis.length) { const li = document.createElement('li'); li.className = 'tf-obs-vazio'; li.textContent = textos.length ? 'Nenhum texto encontrado.' : 'Nenhum texto ainda. Clique em + para adicionar.'; lista.appendChild(li); return; }
      vis.forEach(t => {
        const li = document.createElement('li');
        li.innerHTML = '<span class="tf-obs-ico">Tt</span><span class="tf-obs-info"><b></b><small></small></span><button type="button" class="tf-obs-ed" title="Editar">✎</button><button type="button" class="tf-obs-del" title="Excluir">🗑</button><button type="button" class="tf-obs-env" title="Enviar: incluir esta observação na remessa">➤</button>';
        li.querySelector('b').textContent = t.titulo;
        li.querySelector('small').textContent = (t.status ? '[' + t.status + '] ' : '') + t.texto;
        li.title = t.texto;
        li.querySelector('.tf-obs-ed').addEventListener('click', () => abrirEditor(t));
        const del = li.querySelector('.tf-obs-del');
        del.addEventListener('click', () => {
          if (!del.classList.contains('confirma')) { del.classList.add('confirma'); del.textContent = 'Excluir?'; setTimeout(() => { del.classList.remove('confirma'); del.textContent = '🗑'; }, 3000); return; }
          textos = textos.filter(x => x !== t); gravar(); desenhar();
        });
        li.querySelector('.tf-obs-env').addEventListener('click', () => enviar(t));
        li.querySelector('.tf-obs-info').addEventListener('dblclick', () => enviar(t));
        lista.appendChild(li);
      });
    }
    q('.tf-obs-mais').addEventListener('click', () => abrirEditor(null));
    q('.tf-obs-x').addEventListener('click', fecharCartao);
    q('.tf-obs-cancelar').addEventListener('click', () => { editor.hidden = true; editando = null; });
    q('.tf-obs-salvar').addEventListener('click', () => {
      const titulo = q('.tf-obs-tit').value.trim(), texto = q('.tf-obs-txt').value.trim(), status = q('.tf-obs-st').value;
      if (!texto) { q('.tf-obs-txt').focus(); return; }
      const tit = titulo || texto.slice(0, 30);
      if (editando) Object.assign(editando, { titulo: tit, texto, status });
      else textos.push({ id: Date.now().toString(36), titulo: tit, texto, status });
      textos.sort((a, b) => a.titulo.localeCompare(b.titulo, 'pt-BR', { numeric: true }));
      gravar(); editor.hidden = true; editando = null; desenhar();
    });
    const bkMsg = (t, erro) => { const m = q('.tf-obs-bk-msg'); m.textContent = t; m.classList.toggle('erro', !!erro); };
    q('.tf-obs-exp').addEventListener('click', async () => { try { bkMsg(await window.TFBackup.exportar()); } catch (e) { bkMsg('Não consegui exportar: ' + e.message, true); } });
    q('.tf-obs-imp').addEventListener('click', async () => {
      try { const r = await window.TFBackup.importar(); if (r) { bkMsg(r); await carregar(); desenhar(); } }
      catch (e) { bkMsg('Não consegui importar: ' + e.message, true); }
    });
    busca.addEventListener('input', desenhar);
    // Enter na busca envia o primeiro da lista.
    busca.addEventListener('keydown', ev => { if (ev.key === 'Enter') { const f = busca.value.trim().toLowerCase(); const t = textos.find(x => !f || (x.titulo + ' ' + x.texto).toLowerCase().includes(f)); if (t) enviar(t); } });
    fundo.addEventListener('mousedown', ev => { if (ev.target === fundo) fecharCartao(); });
    // As teclas digitadas no cartão não vão para a página.
    fundo.addEventListener('keydown', ev => ev.stopPropagation());
    document.addEventListener('keydown', escCartao, true);
    document.body.appendChild(fundo);
    desenhar();
    busca.focus();
  }

  document.addEventListener('keydown', async ev => {
    if (ev.altKey && !ev.ctrlKey && !ev.shiftKey && (ev.code === 'KeyT' || ev.key === 't' || ev.key === 'T')) {
      ev.preventDefault(); ev.stopPropagation();
      await carregar();
      abrirCartao();
    }
  }, true);
  chrome.storage.onChanged.addListener((m, area) => { if (area === 'local' && m[CHAVE]) textos = m[CHAVE].newValue || []; });

  // Botão "Textos prontos" ao lado do "Incluir Observação" (abre o mesmo cartão do Alt + T).
  function colocarBotao() {
    if (document.getElementById('tf-obs-botao') || formObs()) return;
    const inc = botaoIncluir();
    if (!inc) return;
    const b = document.createElement('button');
    b.type = 'button'; b.id = 'tf-obs-botao';
    b.className = 'ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only';
    b.innerHTML = '<span class="ui-button-text ui-c">📝 Textos prontos</span>';
    b.title = 'Abrir os textos de observação (Alt + T)';
    b.addEventListener('click', async ev => { ev.preventDefault(); ev.stopPropagation(); await carregar(); abrirCartao(); });
    inc.style.display = 'inline-block';
    inc.after(b);
  }
  colocarBotao();
  new MutationObserver(() => colocarBotao()).observe(document.body, { childList: true, subtree: true });

  carregar();
  verPendente();
})();
