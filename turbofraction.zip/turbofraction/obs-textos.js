/*
 * TurboFraction — textos prontos para "Incluir Observação" (consulta da remessa)
 * Alt + T abre o cartão com os textos guardados: + adiciona, ✎ edita, 🗑 exclui, ➤ envia; ⋮⋮ arrasta para ordenar.
 * Enviar: abre "Incluir Observação", preenche a Descrição e clica em Salvar (Status fica o padrão, INICIADO).
 */
(() => {
  'use strict';
  const CHAVE = 'tf_obs_textos';
  const PENDENTE = 'tf_obs_pendente';
  const STATUS = ['INICIADO', 'EM ANDAMENTO', 'AGUARDANDO INFORMACOES DO REMETENTE', 'AGUARDANDO INFORMACOES DO DESTINATARIO', 'AGUARDANDO LIBERACAO', 'FINALIZADO', 'ENVIADO PELO MOTORISTA'];
  const esperar = ms => new Promise(r => setTimeout(r, ms));
  let textos = [];

  const comId = l => (l || []).map(t => (t.id ? t : Object.assign({}, t, { id: Date.now().toString(36) + Math.random().toString(36).slice(2, 7) })));
  const carregar = async () => { try { textos = comId((await chrome.storage.local.get(CHAVE))[CHAVE]); } catch (e) { textos = []; } };
  const gravar = () => { try { chrome.storage.local.set({ [CHAVE]: textos }); } catch (e) { /* ok */ } };
  const formObs = () => document.getElementById('form_add_obs');
  const botaoIncluir = () => [...document.querySelectorAll('button, a')].find(b => /^Incluir Observa/i.test((b.textContent || '').trim()));

  function faixa(msg, erro) {
    let d = document.getElementById('tf-obs-aviso');
    if (!d) { d = document.createElement('div'); d.id = 'tf-obs-aviso'; document.body.appendChild(d); }
    d.className = erro ? 'erro' : '';
    d.textContent = msg; d.hidden = false;
    clearTimeout(d._t); d._t = setTimeout(() => { d.hidden = true; }, 4000);
  }

  /* ---------- Preencher e salvar na tela "Inclusão de Observação" ---------- */
  async function escolherStatus(nome) {
    const sel = document.getElementById('form_add_obs:statusOco_input');
    if (!sel || !nome) return true;
    const i = [...sel.options].findIndex(o => o.text.trim().toUpperCase() === nome.toUpperCase());
    if (i < 0) return false;
    const item = document.querySelectorAll('[id="form_add_obs:statusOco_items"] li')[i];
    if (item) item.click();
    else { sel.selectedIndex = i; sel.dispatchEvent(new Event('change', { bubbles: true })); }
    await esperar(300);
    return true;
  }
  async function preencherESalvar(p) {
    const ta = document.getElementById('form_add_obs:descObsv');
    const salvar = [...(formObs()?.querySelectorAll('button') || [])].find(b => /^Salvar$/i.test(b.textContent.trim()));
    if (!ta || !salvar) { faixa('Não encontrei os campos da observação.', true); return; }
    if (!(await escolherStatus(p.status))) { faixa('Status "' + p.status + '" não existe nesta tela; confira e salve.', true); }
    ta.value = p.texto;
    ['input', 'keyup', 'change'].forEach(t => ta.dispatchEvent(new Event(t, { bubbles: true })));
    if (p.salvar === false) { faixa('Texto preenchido. Confira e clique em Salvar.'); return; }
    faixa('Salvando a observação…');
    await esperar(300);
    salvar.click();
  }
  // Ao abrir a tela de inclusão (vindo do "Enviar"), preenche e salva.
  async function verPendente() {
    if (!formObs()) return;
    let p = null;
    try { p = JSON.parse(sessionStorage.getItem(PENDENTE) || 'null'); } catch (e) { /* ok */ }
    if (!p || Date.now() - p.t > 60000) return;
    sessionStorage.removeItem(PENDENTE);
    await esperar(400);
    preencherESalvar(p);
  }

  async function enviar(t) {
    fecharCartao();
    const p = { texto: t.texto, status: '', t: Date.now() };   // o Fraction só aceita o status INICIADO (o padrão da tela)
    if (formObs()) { preencherESalvar(p); return; }           // já está na tela de inclusão
    const b = botaoIncluir();
    if (!b) { faixa('Não encontrei o botão "Incluir Observação" nesta tela.', true); return; }
    try { sessionStorage.setItem(PENDENTE, JSON.stringify(p)); } catch (e) { /* ok */ }
    faixa('Abrindo "Incluir Observação"…');
    b.click();
    // A inclusão pode abrir na mesma página (sem recarregar): espera o formulário aparecer.
    for (let i = 0; i < 60; i++) { await esperar(250); if (formObs()) { verPendente(); return; } }
  }

  /* ---------- Cartão (Alt + T) ---------- */
  function fecharCartao() { document.getElementById('tf-obs-fundo')?.remove(); document.removeEventListener('keydown', escCartao, true); }
  function escCartao(ev) { if (ev.key === 'Escape') { ev.stopPropagation(); fecharCartao(); } }

  function abrirCartao() {
    if (document.getElementById('tf-obs-fundo')) { fecharCartao(); return; }
    const fundo = document.createElement('div');
    fundo.id = 'tf-obs-fundo';
    fundo.innerHTML = `
      <div class="tf-obs-cartao" role="dialog" aria-label="Textos de observação">
        <div class="tf-obs-topo"><b>Textos de observação</b><span class="tf-obs-dica">Alt + T</span>
          <button type="button" class="tf-obs-mais" title="Adicionar texto">+</button>
          <button type="button" class="tf-obs-x" title="Fechar (Esc)">✕</button></div>
        <input type="search" class="tf-obs-busca" placeholder="Pesquisar">
        <div class="tf-obs-editor" hidden>
          <input class="tf-obs-tit" maxlength="60" placeholder="Título">
          <textarea class="tf-obs-txt" rows="4" placeholder="Texto da observação"></textarea>
          <div class="tf-obs-ed-acoes"><button type="button" class="tf-obs-cancelar">Cancelar</button><button type="button" class="tf-obs-salvar">Salvar texto</button></div>
        </div>
        <ul class="tf-obs-lista"></ul>
        <div class="tf-obs-rodape" title="Cópia dos textos prontos e dos motoristas dos PUDOs"><span>Backup:</span><button type="button" class="tf-obs-exp">⬇ Exportar</button><button type="button" class="tf-obs-imp">⬆ Importar</button><span class="tf-obs-bk-msg"></span></div>
      </div>`;
    const q = s => fundo.querySelector(s);
    const lista = q('.tf-obs-lista'), editor = q('.tf-obs-editor'), busca = q('.tf-obs-busca');
    let editando = null;

    function abrirEditor(t) {
      editando = t || null;
      q('.tf-obs-tit').value = t ? t.titulo : '';
      q('.tf-obs-txt').value = t ? t.texto : '';
      editor.hidden = false;
      q('.tf-obs-tit').focus();
    }
    // Ícones em SVG (os símbolos de texto não aparecem em todos os computadores)
    const SVG = {
      arrastar: '<svg viewBox="0 0 16 16" width="16" height="16"><g fill="currentColor"><circle cx="5" cy="3" r="1.5"/><circle cx="11" cy="3" r="1.5"/><circle cx="5" cy="8" r="1.5"/><circle cx="11" cy="8" r="1.5"/><circle cx="5" cy="13" r="1.5"/><circle cx="11" cy="13" r="1.5"/></g></svg>',
      editar: '<svg viewBox="0 0 24 24" width="17" height="17"><path fill="currentColor" d="M3 17.25V21h3.75L17.8 9.94l-3.75-3.75L3 17.25zm17.7-10.2a1 1 0 0 0 0-1.41l-2.34-2.34a1 1 0 0 0-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/></svg>',
      excluir: '<svg viewBox="0 0 24 24" width="17" height="17"><path fill="currentColor" d="M6 19a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>',
      enviar: '<svg viewBox="0 0 24 24" width="19" height="19"><path fill="currentColor" d="M2.01 21 23 12 2.01 3 2 10l15 2-15 2z"/></svg>',
    };

    /* Ordem: arrastando pela alça (⋮⋮) para cima ou para baixo. A ordem fica guardada. */
    function arrastar(ev, li) {
      if (busca.value.trim()) return;   // com pesquisa, a lista está filtrada: não reordena
      ev.preventDefault();
      const itens = () => [...lista.querySelectorAll('li[data-id]')];
      const r0 = li.getBoundingClientRect();
      const dy0 = ev.clientY - r0.top;
      const marca = document.createElement('li'); marca.className = 'tf-obs-lugar'; marca.style.height = r0.height + 'px';
      li.classList.add('tf-obs-arrastando');
      li.style.width = r0.width + 'px'; li.style.left = r0.left + 'px'; li.style.top = r0.top + 'px';
      li.after(marca);
      const caixaLista = lista.getBoundingClientRect();
      const mover = e => {
        li.style.top = (e.clientY - dy0) + 'px';
        const meio = e.clientY;
        const alvo = itens().filter(x => x !== li).find(x => { const r = x.getBoundingClientRect(); return meio < r.top + r.height / 2; });
        if (alvo) alvo.before(marca); else lista.appendChild(marca);
        // rolagem automática perto das bordas
        if (e.clientY < caixaLista.top + 30) lista.scrollTop -= 12; else if (e.clientY > caixaLista.bottom - 30) lista.scrollTop += 12;
      };
      const soltar = () => {
        document.removeEventListener('pointermove', mover); document.removeEventListener('pointerup', soltar);
        marca.replaceWith(li);
        li.classList.remove('tf-obs-arrastando'); li.style.width = li.style.left = li.style.top = '';
        const ordem = itens().map(x => x.dataset.id);
        textos.sort((a, b) => ordem.indexOf(a.id) - ordem.indexOf(b.id));
        gravar();
      };
      document.addEventListener('pointermove', mover); document.addEventListener('pointerup', soltar);
    }

    function desenhar() {
      const f = busca.value.trim().toLowerCase();
      lista.innerHTML = '';
      const vis = textos.filter(t => !f || (t.titulo + ' ' + t.texto).toLowerCase().includes(f));
      if (!vis.length) { const li = document.createElement('li'); li.className = 'tf-obs-vazio'; li.textContent = textos.length ? 'Nenhum texto encontrado.' : 'Nenhum texto ainda. Clique em + para adicionar.'; lista.appendChild(li); return; }
      vis.forEach(t => {
        const li = document.createElement('li');
        li.dataset.id = t.id;
        li.innerHTML = `<span class="tf-obs-alca" title="${f ? 'Limpe a pesquisa para mudar a ordem' : 'Arraste para mudar a ordem'}">${SVG.arrastar}</span><span class="tf-obs-ico">Tt</span><span class="tf-obs-info"><b></b><small></small></span><button type="button" class="tf-obs-ed" title="Editar">${SVG.editar}</button><button type="button" class="tf-obs-del" title="Excluir">${SVG.excluir}</button><button type="button" class="tf-obs-env" title="Enviar: incluir esta observação na remessa">${SVG.enviar}</button>`;
        li.querySelector('.tf-obs-alca').classList.toggle('desligada', !!f);
        li.querySelector('.tf-obs-alca').addEventListener('pointerdown', ev => arrastar(ev, li));
        li.querySelector('b').textContent = t.titulo;
        li.querySelector('small').textContent = t.texto;
        li.title = t.texto;
        li.querySelector('.tf-obs-ed').addEventListener('click', () => abrirEditor(t));
        const del = li.querySelector('.tf-obs-del');
        del.addEventListener('click', () => {
          if (!del.classList.contains('confirma')) { del.classList.add('confirma'); del.textContent = 'Excluir?'; setTimeout(() => { del.classList.remove('confirma'); del.innerHTML = SVG.excluir; }, 3000); return; }
          textos = textos.filter(x => x.id !== t.id); gravar(); desenhar();
        });
        li.querySelector('.tf-obs-env').addEventListener('click', () => enviar(t));
        li.querySelector('.tf-obs-info').addEventListener('dblclick', () => enviar(t));
        lista.appendChild(li);
      });
    }
    q('.tf-obs-mais').addEventListener('click', () => abrirEditor(null));
    q('.tf-obs-x').addEventListener('click', fecharCartao);
    q('.tf-obs-cancelar').addEventListener('click', () => { editor.hidden = true; editando = null; });
    q('.tf-obs-salvar').addEventListener('click', () => {
      const titulo = q('.tf-obs-tit').value.trim(), texto = q('.tf-obs-txt').value.trim();
      if (!texto) { q('.tf-obs-txt').focus(); return; }
      const tit = titulo || texto.slice(0, 30);
      const atual = editando && textos.find(x => x.id === editando.id);
      if (atual) Object.assign(atual, { titulo: tit, texto, status: '' });
      else textos.push({ id: Date.now().toString(36) + Math.random().toString(36).slice(2, 5), titulo: tit, texto, status: '' });
      // a ordem é a que o usuário arrastou; texto novo entra no fim
      gravar(); editor.hidden = true; editando = null; desenhar();
    });
    const bkMsg = (t, erro) => { const m = q('.tf-obs-bk-msg'); m.textContent = t; m.classList.toggle('erro', !!erro); };
    q('.tf-obs-exp').addEventListener('click', async () => { try { bkMsg(await window.TFBackup.exportar()); } catch (e) { bkMsg('Não consegui exportar: ' + e.message, true); } });
    q('.tf-obs-imp').addEventListener('click', async () => {
      try { const r = await window.TFBackup.importar(); if (r) { bkMsg(r); await carregar(); desenhar(); } }
      catch (e) { bkMsg('Não consegui importar: ' + e.message, true); }
    });
    busca.addEventListener('input', desenhar);
    // Enter na busca envia o primeiro da lista.
    busca.addEventListener('keydown', ev => { if (ev.key === 'Enter') { const f = busca.value.trim().toLowerCase(); const t = textos.find(x => !f || (x.titulo + ' ' + x.texto).toLowerCase().includes(f)); if (t) enviar(t); } });
    fundo.addEventListener('mousedown', ev => { if (ev.target === fundo) fecharCartao(); });
    // As teclas digitadas no cartão não vão para a página.
    fundo.addEventListener('keydown', ev => ev.stopPropagation());
    document.addEventListener('keydown', escCartao, true);
    document.body.appendChild(fundo);
    desenhar();
    busca.focus();
  }

  document.addEventListener('keydown', async ev => {
    if (ev.altKey && !ev.ctrlKey && !ev.shiftKey && (ev.code === 'KeyT' || ev.key === 't' || ev.key === 'T')) {
      ev.preventDefault(); ev.stopPropagation();
      await carregar();
      abrirCartao();
    }
  }, true);
  chrome.storage.onChanged.addListener((m, area) => { if (area === 'local' && m[CHAVE]) textos = comId(m[CHAVE].newValue); });

  // Botão "Textos prontos" ao lado do "Incluir Observação" (abre o mesmo cartão do Alt + T).
  function colocarBotao() {
    if (document.getElementById('tf-obs-botao') || formObs()) return;
    const inc = botaoIncluir();
    if (!inc) return;
    const b = document.createElement('button');
    b.type = 'button'; b.id = 'tf-obs-botao';
    b.className = 'ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only';
    b.innerHTML = '<span class="ui-button-text ui-c">📝 Textos prontos</span>';
    b.title = 'Abrir os textos de observação (Alt + T)';
    b.addEventListener('click', async ev => { ev.preventDefault(); ev.stopPropagation(); await carregar(); abrirCartao(); });
    inc.style.display = 'inline-block';
    inc.after(b);
  }
  colocarBotao();
  new MutationObserver(() => colocarBotao()).observe(document.body, { childList: true, subtree: true });

  carregar();
  verPendente();
})();
