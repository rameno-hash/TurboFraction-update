/*
 * TurboFraction — Emissão em sequência (Alt+E).
 * Janela com uma lista de códigos (Pedido / Ordem Coleta / ShipmentID / Danfe / Código DCe, um por linha).
 * Para cada código: coloca no campo do pedido e "tecla TAB" (o Fraction carrega a remessa). Se a lista
 * "Remessas" (ao lado de Pesar Especial) ficou com volume, clica em "Emitir Imprimir" e mostra
 * "Próximo". A encomenda já vem com a etiqueta do cliente: a emissão só a ativa (não há impressão). Se ficou vazia, leva o cursor ao Peso do Pesar Especial para o usuário pesar à mão.
 */
(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const ID = {
    nr: 'form_emissao:nr',
    tabela: 'form_emissao:form-remessa-embalagens:id_lista_peso_data',
    peso: 'form_emissao:form-remessa-embalagens:peso_atual_especial',
    emitir: 'form_emissao:emitir-imprimir',
    confirma: 'form_emissao:confirmDialogCTE',     // "Remessa já emitida. Deseja prosseguir?"
    nao: 'form_emissao:botao_nao_cte',
    cte: 'form_emissao:txt_cte',
  };
  const CHAVE = 'tf_emissao_lote';
  const dorme = ms => new Promise(r => setTimeout(r, ms));
  const txt = el => (el?.textContent || '').replace(/\s+/g, ' ').trim();
  const esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  /** Espera o Fraction terminar as requisições ajax (contador do emissao-ajax.js). */
  async function esperarAjax(min = 400, max = 30000) {
    await dorme(min);
    const ini = Date.now();
    if (document.documentElement.dataset.tfAjax == null) { await dorme(1500); return; }
    while (document.documentElement.dataset.tfAjax !== '0' && Date.now() - ini < max) await dorme(120);
    await dorme(200);
  }
  /** Mensagens novas do Fraction (growl / mensagens) que apareceram durante `fn`. */
  async function comMensagens(fn) {
    const ler = () => [...document.querySelectorAll('.ui-growl-message, .ui-messages-error-detail, .ui-messages-warn-detail, .ui-message-error-detail')].map(e => txt(e)).filter(Boolean);
    const antes = new Set(ler());
    await fn();
    return [...new Set(ler())].filter(m => !antes.has(m));
  }
  const URL_PESQUISAR = location.origin + '/FractionWeb/jad/pesquisar';
  const JA_USADO = /j[aá]\s+(est[aá]\s+sendo\s+)?utilizad|j[aá]\s+emitid|em\s+outro\s+ct-?e/i;
  const visivel = el => el && getComputedStyle(el).display !== 'none' && getComputedStyle(el).visibility !== 'hidden';
  /** "Remessa já emitida. Deseja prosseguir?" aberta: responde Não. */
  async function responderNao() {
    const d = $(ID.confirma);
    if (!visivel(d)) return false;
    $(ID.nao)?.click();
    await esperarAjax(400);
    return true;
  }
  const volumes = () => [...($(ID.tabela)?.rows || [])].filter(tr => !tr.classList.contains('ui-datatable-empty-message') && tr.cells.length > 1).length;

  /* ---------- Estado (só na memória: recarregar a página zera a lista e o histórico) ---------- */
  // itens: [{ cod, st: 'fila' | 'carregando' | 'peso' | 'emitindo' | 'ok' | 'erro' | 'pulado', msg }]
  let est = { itens: [], atual: -1 };
  try { localStorage.removeItem(CHAVE); } catch (e) { /* ok */ }   // apaga o que versões anteriores guardavam
  const gravar = () => {};
  let ocupado = false;

  /* ---------- Janela ---------- */
  let jan = null;
  function montar() {
    if (jan) return jan;
    jan = document.createElement('div');
    jan.id = 'tf-lote';
    jan.hidden = true;
    jan.innerHTML = `
      <div class="tf-lt-topo"><b>⚡ Emissão em sequência</b><span class="tf-lt-cont"></span><button type="button" class="tf-lt-fechar" title="Fechar (Alt+E ou Esc)">✕</button></div>
      <div class="tf-lt-corpo">
        <label class="tf-lt-rot">Pedido / Ordem Coleta / ShipmentID / Danfe / Código DCe — um por linha</label>
        <textarea class="tf-lt-texto" rows="6" spellcheck="false" placeholder="Cole ou digite os códigos aqui"></textarea>
        <ol class="tf-lt-lista"></ol>
        <div class="tf-lt-msg"></div>
      </div>
      <div class="tf-lt-acoes">
        <button type="button" class="tf-lt-limpar" title="Apagar a lista">Limpar</button>
        <span class="tf-lt-esp"></span>
        <button type="button" class="tf-lt-pular" hidden>Pular</button>
        <button type="button" class="tf-lt-principal">▶ Processar</button>
      </div>`;
    document.body.appendChild(jan);
    const ta = jan.querySelector('.tf-lt-texto');
    ta.addEventListener('input', () => {
      // Só a parte ainda não iniciada vem do campo de texto.
      const feitos = est.itens.filter(i => i.st !== 'fila');
      const novos = ta.value.split(/[\r\n]+/).map(s => s.trim()).filter(Boolean).map(cod => ({ cod, st: 'fila' }));
      est.itens = [...feitos, ...novos];
      gravar(); desenhar(true);
    });
    jan.querySelector('.tf-lt-fechar').addEventListener('click', alternar);
    jan.querySelector('.tf-lt-limpar').addEventListener('click', () => { if (ocupado) return; est = { itens: [], atual: -1 }; gravar(); ta.value = ''; desenhar(); ta.focus(); });
    jan.querySelector('.tf-lt-pular').addEventListener('click', () => { if (ocupado) return; const i = est.itens[est.atual]; if (i) { i.st = 'pulado'; i.msg = 'pulado'; } gravar(); proximo(); });
    jan.querySelector('.tf-lt-principal').addEventListener('click', principal);
    return jan;
  }
  function alternar() {
    montar();
    jan.hidden = !jan.hidden;
    if (!jan.hidden) { desenhar(); if (!est.itens.some(i => i.st !== 'fila')) jan.querySelector('.tf-lt-texto').focus(); }
  }
  const ROT = { fila: '', carregando: 'carregando…', peso: '⚖ sem volume — informe o peso', emitindo: 'emitindo…', ok: '✔', erro: '✖', pulado: '↷ pulado', usado: '⚠ Código já utilizado' };
  function desenhar(semTexto) {
    if (!jan) return;
    const ta = jan.querySelector('.tf-lt-texto');
    const fila = est.itens.filter(i => i.st === 'fila');
    const iniciados = est.itens.some(i => i.st !== 'fila');
    if (!semTexto) ta.value = fila.map(i => i.cod).join('\n');
    // Depois de começar, a lista com o andamento substitui o campo (os que faltam continuam editáveis no campo).
    const lista = jan.querySelector('.tf-lt-lista');
    lista.hidden = !iniciados;
    lista.innerHTML = est.itens.filter(i => i.st !== 'fila').map(i => `<li class="st-${i.st}${est.itens.indexOf(i) === est.atual ? ' atual' : ''}">${i.st === 'usado' ? `<a class="c" href="${URL_PESQUISAR}#tf_pesq=${encodeURIComponent(i.cod)}" target="_blank" rel="noopener" title="Pesquisar ${esc(i.cod)} em outra aba">${esc(i.cod)}</a>` : `<span class="c">${esc(i.cod)}</span>`}<span class="m">${esc(ROT[i.st] || '')}${i.msg ? ' ' + esc(i.msg) : ''}</span></li>`).join('');
    const atualEl = lista.querySelector('.atual'); if (atualEl) atualEl.scrollIntoView({ block: 'nearest' });
    ta.classList.toggle('tf-lt-texto-menor', iniciados);
    const feitos = est.itens.filter(i => i.st === 'ok').length;
    jan.querySelector('.tf-lt-cont').textContent = est.itens.length ? `${feitos} de ${est.itens.length} emitido(s)` : '';
    const b = jan.querySelector('.tf-lt-principal'), pular = jan.querySelector('.tf-lt-pular');
    const cur = est.itens[est.atual];
    pular.hidden = !(cur && cur.st === 'peso');
    b.disabled = ocupado;
    if (ocupado) b.textContent = '⏳ Aguarde…';
    else if (cur && cur.st === 'peso') b.textContent = '▶ Emitir com o peso informado';
    else if (cur && (cur.st === 'ok' || cur.st === 'erro' || cur.st === 'pulado' || cur.st === 'usado') && fila.length) b.textContent = '▶ Próximo';
    else if (fila.length) b.textContent = iniciados ? '▶ Próximo' : '▶ Processar';
    else if (iniciados) { b.textContent = '✔ Concluído'; b.disabled = true; }
    else { b.textContent = '▶ Processar'; b.disabled = true; }   // ainda sem códigos
  }
  function aviso(t, tipo) { if (!jan) return; const m = jan.querySelector('.tf-lt-msg'); m.textContent = t || ''; m.className = 'tf-lt-msg' + (tipo ? ' ' + tipo : ''); }

  /* ---------- Fluxo ---------- */
  async function principal() {
    if (ocupado) return;
    const cur = est.itens[est.atual];
    if (cur && cur.st === 'peso') { await emitirAtual(); return; }
    proximo();
  }
  async function proximo() {
    const i = est.itens.findIndex(x => x.st === 'fila');
    if (i < 0) { est.atual = -1; gravar(); desenhar(); aviso('Todos os códigos foram processados.', 'ok'); return; }
    est.atual = i; await carregar(est.itens[i]);
  }
  /** Coloca o código no campo do pedido e "tecla TAB". */
  async function carregar(item) {
    const nr = $(ID.nr);
    if (!nr) { aviso('Não encontrei o campo "Pedido / Ordem Coleta / ShipmentID…" nesta tela.', 'erro'); return; }
    ocupado = true; item.st = 'carregando'; item.msg = ''; gravar(); desenhar(); aviso('');
    const msgs0 = {};
    try {
      await responderNao();   // confirmação esquecida aberta de antes: fecha antes de começar
      const msgs = await comMensagens(async () => {
        nr.focus();
        nr.value = item.cod;
        nr.dispatchEvent(new Event('input', { bubbles: true }));
        nr.dispatchEvent(new KeyboardEvent('keydown', { key: 'Tab', code: 'Tab', keyCode: 9, which: 9, bubbles: true }));
        nr.dispatchEvent(new Event('change', { bubbles: true }));   // o "TAB": o Fraction busca o pedido
        nr.blur();
        await esperarAjax(600);
        if (await responderNao()) msgs0.usado = true;
      });
      if (msgs0.usado || msgs.some(m => JA_USADO.test(m))) { await marcarUsado(item); return; }
      if (volumes() > 0) {
        ocupado = false;
        await emitirAtual(msgs);
        return;
      }
      item.st = 'peso'; item.msg = msgs.length ? '— ' + msgs.join(' · ') : '';
      ocupado = false; gravar(); desenhar();
      aviso('A lista "Remessas" ficou vazia: pese o volume no Pesar Especial (o cursor está no Peso) e clique em "Emitir com o peso informado" — ou "Pular".', 'aviso');
      const peso = $(ID.peso);
      if (peso) { peso.focus(); peso.select?.(); }
    } catch (e) {
      item.st = 'erro'; item.msg = e.message; ocupado = false; gravar(); desenhar();
    }
  }
  /** Código que já tem CT-e ativo: responde Não, marca "Código já utilizado" (link para a Pesquisa) e segue. */
  async function marcarUsado(item) {
    await responderNao();
    item.st = 'usado'; item.msg = '';
    ocupado = false; gravar(); desenhar();
    aviso('Código já utilizado (já existe CT-e ativo para ele). Clique no código para pesquisar ou em "Próximo".', 'aviso');
    jan?.querySelector('.tf-lt-principal')?.focus();
  }
  function fecharPesagem() {
    const d = $('dlg_pesar');
    if (d && getComputedStyle(d).display !== 'none') d.querySelector('.ui-dialog-titlebar-close')?.click();
  }
  /** Clica em "Emitir Imprimir" e lê o número do CT-e gerado. */
  async function emitirAtual(msgsAntes = []) {
    const item = est.itens[est.atual]; if (!item) return;
    const btn = $(ID.emitir);
    if (!btn || btn.disabled) { item.st = 'erro'; item.msg = 'botão "Emitir Imprimir" indisponível'; gravar(); desenhar(); return; }
    if (!volumes()) { aviso('Ainda não há volume na lista "Remessas". Pese no Pesar Especial antes de emitir.', 'aviso'); $(ID.peso)?.focus(); return; }
    ocupado = true; item.st = 'emitindo'; gravar(); desenhar(); aviso('');
    await responderNao();
    const cteAntes = txt($(ID.cte));
    try {
      let dialogo = false;
      const msgs = await comMensagens(async () => { btn.click(); await esperarAjax(800, 60000); dialogo = await responderNao(); });
      if (dialogo || msgs.some(m => JA_USADO.test(m))) { ocupado = false; await marcarUsado(item); return; }
      const cte = txt($(ID.cte));
      // "CTE'10083396092944' gerado com sucesso." é a confirmação da emissão, não erro.
      const sucesso = msgs.find(m => /gerad[oa]\s+com\s+sucesso|emitid[oa]\s+com\s+sucesso/i.test(m));
      const numMsg = sucesso && (/CT-?E\D{0,3}(\d{8,})/i.exec(sucesso) || /(\d{10,})/.exec(sucesso) || [])[1];
      if (cte && cte !== cteAntes) { item.st = 'ok'; item.msg = 'CT-e ' + cte; }
      else if (sucesso) { item.st = 'ok'; item.msg = numMsg ? 'CT-e ' + numMsg : 'emitido'; }
      else if (msgs.length) { item.st = 'erro'; item.msg = msgs.join(' · '); }
      else { item.st = 'ok'; item.msg = 'emitido'; }
    } catch (e) { item.st = 'erro'; item.msg = e.message; }
    ocupado = false; gravar(); desenhar();
    const resta = est.itens.some(x => x.st === 'fila');
    if (item.st === 'ok') {
      // A encomenda já vem com a etiqueta do cliente: a emissão só a ativa. A janelinha "Pesagem" que o
      // Fraction abre depois de emitir não tem o que imprimir — fecha.
      fecharPesagem();
      aviso(resta ? 'Emitido (etiqueta do cliente ativada). Clique em "Próximo".' : 'Emitido (etiqueta do cliente ativada). Era o último código da lista.', 'ok');
    }
    else aviso('A emissão não confirmou. Veja a mensagem do Fraction; você pode emitir manualmente e seguir com "Próximo".', 'erro');
    jan?.querySelector('.tf-lt-principal')?.focus();
  }

  /* ---------- Atalho Alt+E ---------- */
  // O Fraction usa accesskey="E" (Alt+E abre a Pesagem Especial). Nesta tela o Alt+E passa a ser da extensão:
  // tira o accesskey "E" (também depois que o Fraction redesenha a tela).
  function tirarAccesskeyE() {
    document.querySelectorAll('[accesskey="E"], [accesskey="e"]').forEach(el => { el.dataset.tfAccesskey = el.getAttribute('accesskey'); el.removeAttribute('accesskey'); });
  }
  tirarAccesskeyE();
  let tAk = 0;
  new MutationObserver(() => { clearTimeout(tAk); tAk = setTimeout(tirarAccesskeyE, 50); }).observe(document.body, { childList: true, subtree: true });

  document.addEventListener('keydown', ev => {
    if (ev.altKey && !ev.ctrlKey && !ev.shiftKey && (ev.key === 'e' || ev.key === 'E' || ev.code === 'KeyE')) {
      if (!$(ID.nr)) return;
      ev.preventDefault(); ev.stopImmediatePropagation();
      tirarAccesskeyE();
      alternar();
    } else if (ev.key === 'Escape' && jan && !jan.hidden && jan.contains(document.activeElement)) { jan.hidden = true; }
  }, true);
  // Alguns atalhos do site reagem no keyup/keypress: bloqueia o Alt+E neles também.
  ['keyup', 'keypress'].forEach(t => document.addEventListener(t, ev => {
    if (ev.altKey && !ev.ctrlKey && (ev.key === 'e' || ev.key === 'E' || ev.code === 'KeyE') && $(ID.nr)) { ev.preventDefault(); ev.stopImmediatePropagation(); }
  }, true));
})();
