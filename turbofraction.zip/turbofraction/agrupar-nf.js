/*
 * TurboFraction — Consulta (/FractionWeb/jad/consulta): a grade mostra uma linha por nota fiscal,
 * então a remessa com várias NFs aparece repetida. Aqui as linhas da mesma remessa viram uma só,
 * com as NFs (e os pedidos) juntos na mesma célula. As linhas repetidas só ficam escondidas
 * (não são apagadas), para não atrapalhar a paginação e a ordenação do Fraction.
 */
(() => {
  'use strict';
  const ID_DADOS = 'formConsultaData:grdConsultaData_data';
  const txt = el => (el.textContent || '').replace(/\s+/g, ' ').trim();

  function agrupar(corpo) {
    const linhas = [...corpo.rows].filter(tr => tr.cells.length > 2 && !tr.classList.contains('ui-datatable-empty-message'));
    const porCodigo = new Map();
    linhas.forEach(tr => {
      const cod = txt(tr.cells[0]);
      if (!cod) return;
      if (!porCodigo.has(cod)) porCodigo.set(cod, []);
      porCodigo.get(cod).push(tr);
    });
    porCodigo.forEach(grupo => {
      if (grupo.length < 2) return;
      const [primeira, ...repetidas] = grupo;
      for (let c = 1; c < primeira.cells.length; c++) {
        const valores = [];
        grupo.forEach(tr => { const v = tr.cells[c] && txt(tr.cells[c]); if (v && !valores.includes(v)) valores.push(v); });
        if (valores.length > 1) {
          const cel = primeira.cells[c];
          cel.textContent = '';
          valores.forEach((v, i) => { if (i) cel.appendChild(document.createElement('br')); cel.appendChild(document.createTextNode(v)); });
          cel.classList.add('tf-nf-juntas');
        }
      }
      const nfs = grupo.length;
      primeira.title = `${nfs} notas fiscais nesta remessa (agrupadas pelo TurboFraction)`;
      repetidas.forEach(tr => { tr.style.display = 'none'; tr.classList.add('tf-nf-repetida'); });
    });
    // Refaz o zebrado só com as linhas visíveis.
    let i = 0;
    linhas.forEach(tr => {
      if (tr.classList.contains('tf-nf-repetida')) return;
      tr.classList.toggle('ui-datatable-even', i % 2 === 0);
      tr.classList.toggle('ui-datatable-odd', i % 2 === 1);
      i++;
    });
    corpo.dataset.tfAgrupado = String(corpo.rows.length);
  }

  function verificar() {
    const corpo = document.getElementById(ID_DADOS);
    if (corpo && corpo.dataset.tfAgrupado !== String(corpo.rows.length) && !corpo.querySelector('.tf-nf-juntas, .tf-nf-repetida')) agrupar(corpo);
  }

  verificar();
  // A grade é trocada pelo Fraction ao paginar, ordenar ou pesquisar de novo.
  let agendado = 0;
  new MutationObserver(() => { if (!agendado) agendado = requestAnimationFrame(() => { agendado = 0; verificar(); }); })
    .observe(document.body, { childList: true, subtree: true });
})();
