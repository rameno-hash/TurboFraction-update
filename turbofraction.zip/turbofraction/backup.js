/*
 * TurboFraction — cópia de segurança dos dados do usuário (textos prontos de observação e motoristas dos PUDOs)
 * 1) Cópia automática no próprio site do Fraction (localStorage): se a extensão for reinstalada ou carregada
 *    de outra pasta e começar vazia, os dados voltam sozinhos na primeira tela do Fraction aberta.
 * 2) Exportar / Importar arquivo: window.TFBackup.exportar() / importar(), usados no cartão de textos (Alt + T).
 */
(() => {
  'use strict';
  if (window.TFBackup) return;
  const CHAVES = ['tf_obs_textos', 'tf_pudo_motoristas'];
  const LOCAL = 'tf_backup_dados';
  const vazio = v => v == null || (Array.isArray(v) ? !v.length : typeof v === 'object' ? !Object.keys(v).length : !v);

  function lerCopia() { try { return JSON.parse(localStorage.getItem(LOCAL) || 'null'); } catch (e) { return null; } }
  function gravarCopia(dados) {
    try { localStorage.setItem(LOCAL, JSON.stringify({ quando: Date.now(), dados })); } catch (e) { /* sem espaço / bloqueado */ }
  }

  async function sincronizar() {
    let ext = {};
    try { ext = await chrome.storage.local.get(CHAVES); } catch (e) { return; }
    const copia = lerCopia();
    const restaurar = {};
    if (copia && copia.dados) CHAVES.forEach(k => { if (vazio(ext[k]) && !vazio(copia.dados[k])) restaurar[k] = copia.dados[k]; });
    if (Object.keys(restaurar).length) {
      try { await chrome.storage.local.set(restaurar); Object.assign(ext, restaurar); } catch (e) { /* ok */ }
      console.info('[TurboFraction] dados recuperados da cópia no site:', Object.keys(restaurar).join(', '));
    }
    const dados = {};
    CHAVES.forEach(k => { if (!vazio(ext[k])) dados[k] = ext[k]; });
    if (Object.keys(dados).length) gravarCopia(dados);
  }
  // Mudou algo na extensão (em qualquer aba): atualiza a cópia.
  chrome.storage.onChanged.addListener((m, area) => {
    if (area !== 'local' || !CHAVES.some(k => k in m)) return;
    sincronizar();
  });

  async function exportar() {
    const ext = await chrome.storage.local.get(CHAVES);
    const conteudo = { app: 'TurboFraction', versao: chrome.runtime.getManifest().version, quando: new Date().toISOString(), dados: {} };
    CHAVES.forEach(k => { if (!vazio(ext[k])) conteudo.dados[k] = ext[k]; });
    const d = new Date(), p = n => String(n).padStart(2, '0');
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([JSON.stringify(conteudo, null, 2)], { type: 'application/json' }));
    a.download = `TurboFraction_backup_${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}.json`;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 10000);
    const nT = (conteudo.dados.tf_obs_textos || []).length, nM = Object.keys(conteudo.dados.tf_pudo_motoristas || {}).length;
    return `${nT} texto(s) e ${nM} motorista(s) de PUDO exportados.`;
  }

  /** Lê um arquivo de backup e junta com o que já existe (o arquivo vence em caso de mesmo título/PUDO). */
  function importar() {
    return new Promise((ok, falha) => {
      const inp = document.createElement('input');
      inp.type = 'file'; inp.accept = '.json,application/json';
      inp.addEventListener('change', async () => {
        try {
          const f = inp.files[0]; if (!f) return ok(null);
          const j = JSON.parse(await f.text());
          const dados = (j && j.dados) || {};
          if (j.app !== 'TurboFraction' || !CHAVES.some(k => k in dados)) throw new Error('este arquivo não é um backup da TurboFraction');
          const ext = await chrome.storage.local.get(CHAVES);
          const novo = {};
          if (Array.isArray(dados.tf_obs_textos)) {
            const atuais = ext.tf_obs_textos || [];
            const porTit = new Map(atuais.map(t => [String(t.titulo).toUpperCase(), t]));
            dados.tf_obs_textos.forEach(t => { if (t && t.texto) porTit.set(String(t.titulo || t.texto.slice(0, 30)).toUpperCase(), { id: t.id || Date.now().toString(36) + Math.random().toString(36).slice(2, 6), titulo: t.titulo || t.texto.slice(0, 30), texto: t.texto, status: t.status || '' }); });
            novo.tf_obs_textos = [...porTit.values()].sort((a, b) => a.titulo.localeCompare(b.titulo, 'pt-BR', { numeric: true }));
          }
          if (dados.tf_pudo_motoristas && typeof dados.tf_pudo_motoristas === 'object') novo.tf_pudo_motoristas = Object.assign({}, ext.tf_pudo_motoristas || {}, dados.tf_pudo_motoristas);
          await chrome.storage.local.set(novo);
          ok(`Importados: ${(dados.tf_obs_textos || []).length} texto(s) e ${Object.keys(dados.tf_pudo_motoristas || {}).length} motorista(s) de PUDO.`);
        } catch (e) { falha(e); }
      });
      inp.click();
    });
  }

  window.TFBackup = { exportar, importar };
  sincronizar();
})();
