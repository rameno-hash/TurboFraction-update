// TurboFraction — etiqueta com o texto selecionado na consulta da remessa.
(async () => {
  const id = location.hash.slice(1);
  let d = {};
  try {
    if (id) { const v = await chrome.storage.session.get(id); d = v[id] || {}; await chrome.storage.session.remove(id); }
  } catch (e) { /* sem dados */ }
  const caixa = document.getElementById('texto');
  caixa.textContent = String(d.texto || '').trim();
  document.getElementById('rodape').textContent = d.cte ? 'Remessa ' + d.cte : '';
  // Maior fonte que cabe na etiqueta.
  let t = 60;
  caixa.style.fontSize = t + 'px';
  while (t > 8 && (caixa.scrollHeight > caixa.clientHeight + 1 || caixa.scrollWidth > caixa.clientWidth + 1)) { t -= 1; caixa.style.fontSize = t + 'px'; }
  document.title = 'Etiqueta — ' + caixa.textContent.slice(0, 40);
  document.getElementById('imprimir').addEventListener('click', () => window.print());
  setTimeout(() => window.print(), 400);
})();
