/*
 * TurboFraction — tela Pesquisar (/FractionWeb/jad/pesquisar)
 * Vindo do link no CPF/CNPJ da consulta da remessa: escolhe o filtro CPF/CNPJ,
 * preenche o número e clica em Processar. Vindo do Dashboard de Coletas (#tf_coleta=N): filtro Ordem de Coleta.
 */
(() => {
  'use strict';
  // Guarda (nesta aba) o último CPF/CNPJ pesquisado: se a tela do resultado expirar, a pesquisa é refeita.
  document.addEventListener('click', ev => {
    const b = ev.target.closest && ev.target.closest('[id="frmPesquisa:id_enviar"]');
    if (!b) return;
    const campo = document.getElementById('frmPesquisa:cte');
    const marcado = [...document.querySelectorAll('input[id^="frmPesquisa:tipo:"]')].find(r => r.checked);
    const rot = marcado && document.querySelector('label[for="' + CSS.escape(marcado.id) + '"]');
    const v = campo ? campo.value.replace(/\D/g, '') : '';
    try {
      if (rot && /cpf/i.test(rot.textContent) && (v.length === 11 || v.length === 14)) sessionStorage.setItem('tf_ultimo_cpf', v);
      else sessionStorage.removeItem('tf_ultimo_cpf');
    } catch (e) { /* ok */ }
  }, true);

  // Pedido: CPF/CNPJ (link na consulta da remessa, via localStorage) ou Ordem de Coleta (#tf_coleta=N, link do Dashboard de Coletas).
  let pedido = null, filtro = /cpf/i;
  const h = /tf_coleta=(\d{4,})/.exec(location.hash);
  // #tf_pesq=CÓDIGO (Emissão em sequência, "Código já utilizado"): filtro pelo formato do código.
  const g = /tf_pesq=([A-Za-z0-9$-]{4,})/.exec(location.hash);
  if (h) {
    pedido = { v: h[1], t: Date.now() }; filtro = /ordem\s+de\s+coleta/i;
    history.replaceState(null, '', location.pathname + location.search);
  } else if (g) {
    const c = g[1];
    pedido = { v: c, t: Date.now() };
    filtro = /^DPJ/i.test(c) ? /mini\s+etiqueta|dpj/i
      : /^\d{9}$/.test(c) ? /ordem\s+de\s+coleta/i
      : /^\d{44}$/.test(c) ? /dacte/i
      : /^\d{14}$/.test(c) ? /conhecimento/i
      : /^\d{10,13}$/.test(c) ? /shipp?mentid/i
      : /nenhum\s+filtro/i;
    history.replaceState(null, '', location.pathname + location.search);
  } else {
    try {
      pedido = JSON.parse(localStorage.getItem('tf_pesq_cpf') || 'null');
      localStorage.removeItem('tf_pesq_cpf');
    } catch (e) { return; }
  }
  if (!pedido || !pedido.v || Date.now() - pedido.t > 60000) return;

  function definir(el, v) {
    const d = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(el), 'value');
    if (d && d.set) d.set.call(el, v); else el.value = v;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }

  let n = 0;
  const t = setInterval(() => {
    const campo = document.getElementById('frmPesquisa:cte');
    const botao = document.getElementById('frmPesquisa:id_enviar');
    if (!campo || !botao) { if (++n > 40) clearInterval(t); return; }
    clearInterval(t);
    // Filtro "CPF / CNPJ" ou "Ordem de Coleta" (procura pelo texto do rótulo de cada opção).
    for (let i = 0; i < 40; i++) {
      const r = document.getElementById('frmPesquisa:tipo:' + i);
      if (!r) break;
      const rot = document.querySelector('label[for="frmPesquisa:tipo:' + i + '"]');
      if (rot && filtro.test(rot.textContent)) { if (!r.checked) r.click(); break; }
    }
    setTimeout(() => {
      definir(campo, pedido.v);
      setTimeout(() => botao.click(), 300);
    }, 400);
  }, 250);
})();
