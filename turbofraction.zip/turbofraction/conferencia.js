/*
 * TurboFraction — Conferência de manifesto (/FractionWeb/pages/conferenciaManifesto/confere.jad)
 * Botão "Faltantes por Circuit": gera os relatórios de inconsistência do próprio Fraction
 * (o mesmo clique do ícone Excel), recebe o .csv direto (sem ir para Downloads)
 * e abre um painel com as remessas faltantes agrupadas por Circuit.
 * Circuit, peso e bairro/cidade vêm do arquivo da Performance guardado pelo Painel de Pendências.
 */
(() => {
  'use strict';
  const FORM = 'form_conferencia_manifesto';
  const CAB_AJAX = {
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'Faces-Request': 'partial/ajax',
    'X-Requested-With': 'XMLHttpRequest',
  };

  function campos(form) {
    const p = new URLSearchParams();
    form.querySelectorAll('input[name], select[name], textarea[name]').forEach(el => {
      if ((el.type === 'checkbox' || el.type === 'radio') && !el.checked) return;
      if (el.type === 'submit' || el.type === 'button') return;
      if (el.tagName === 'SELECT' && el.multiple) { [...el.selectedOptions].forEach(o => p.append(el.name, o.value)); return; }
      p.append(el.name, el.value);
    });
    return p;
  }

  function atualizarViewState(xml) {
    const m = /<update id="[^"]*javax\.faces\.ViewState[^"]*"><!\[CDATA\[([^\]]*)\]\]>/.exec(xml);
    if (m) document.querySelectorAll('input[name="javax.faces.ViewState"]').forEach(i => { i.value = m[1]; });
  }

  /** Repete o clique no ícone (excel|pdf) e devolve o arquivo gerado pelo Fraction. */
  async function baixar(tipo) {
    const form = document.getElementById(FORM);
    const link = document.getElementById(`${FORM}:id_exportar_${tipo}`);
    const botao = document.getElementById(`${FORM}:id_exportar_${tipo}_button`);
    if (!form || !link || !botao) throw new Error('não encontrei os ícones de exportação na tela');
    const acao = form.getAttribute('action') || location.href;
    const p1 = new URLSearchParams({
      'javax.faces.partial.ajax': 'true',
      'javax.faces.source': link.id,
      'javax.faces.partial.execute': '@all',
      'javax.faces.partial.render': 'form_notificacao:mensagemTmp',
      [link.id]: link.id,
    });
    campos(form).forEach((v, k) => p1.append(k, v));
    const r1 = await fetch(acao, { method: 'POST', credentials: 'same-origin', headers: CAB_AJAX, body: p1.toString() });
    const x1 = await r1.text();
    atualizarViewState(x1);
    const args = /<extension[^>]*type="args"[^>]*>([\s\S]*?)<\/extension>/.exec(x1);
    if (args && /"existeDado"\s*:\s*false/.test(args[1])) throw new Error('não há inconsistências para exportar (adicione os manifestos primeiro)');
    const p2 = campos(form);
    p2.set(FORM, FORM);
    p2.set(botao.name, botao.value || '');
    const r2 = await fetch(acao, {
      method: 'POST', credentials: 'same-origin',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      body: p2.toString(),
    });
    const ct = r2.headers.get('content-type') || '';
    if (/text\/html|xml/i.test(ct)) {
      const corpo = (await r2.text()).replace(/\s+/g, ' ');
      const titulo = (/<title>([^<]*)/i.exec(corpo) || [])[1];
      throw new Error(`o Fraction respondeu com uma página (${ct.split(';')[0]}${titulo ? ', "' + titulo.trim() + '"' : ''}, HTTP ${r2.status}) em vez do arquivo`);
    }
    const nome = (/filename="?([^";]+)/i.exec(r2.headers.get('content-disposition') || '') || [])[1] || `InconsistenciaManifesto.${tipo === 'pdf' ? 'pdf' : 'csv'}`;
    return { buffer: await r2.arrayBuffer(), nome };
  }

  /* ---------- Painel por cima da página (mesmo do Painel de Pendências) ---------- */
  function abrirPainel() {
    document.getElementById('tf-painel')?.remove();
    const fundo = document.createElement('div');
    fundo.id = 'tf-painel';
    fundo.innerHTML = '<div class="tf-painel-caixa"><button type="button" class="tf-painel-fechar" title="Fechar (Esc)">✕</button><iframe class="tf-painel-quadro" allow="clipboard-write"></iframe></div>';
    const quadro = fundo.querySelector('iframe');
    quadro.src = chrome.runtime.getURL('relatorio.html#faltantes');
    const fechar = () => { fundo.remove(); document.removeEventListener('keydown', esc); };
    const esc = ev => { if (ev.key === 'Escape') fechar(); };
    fundo.querySelector('.tf-painel-fechar').addEventListener('click', fechar);
    document.addEventListener('keydown', esc);
    document.body.appendChild(fundo);
    quadro.addEventListener('load', () => { quadro.dataset.pronto = '1'; }, { once: true });
    return quadro;
  }
  function enviar(quadro, msg, transferir) {
    const destino = new URL(chrome.runtime.getURL('')).origin;
    const mandar = () => quadro.contentWindow.postMessage(Object.assign({ origem: location.origin }, msg), destino, transferir || []);
    if (quadro.dataset.pronto) mandar(); else quadro.addEventListener('load', () => { quadro.dataset.pronto = '1'; mandar(); }, { once: true });
  }
  const deBase64 = b64 => { const s = atob(b64), u8 = new Uint8Array(s.length); for (let i = 0; i < s.length; i++) u8[i] = s.charCodeAt(i); return u8.buffer; };

  /** Manifestos/unitizadores adicionados na tela (1ª coluna da tabela). */
  function manifestosDaTela() {
    const corpo = document.getElementById(`${FORM}:dataListaconferenciaManifesto_data`);
    const l = [...(corpo ? corpo.rows : [])].map(tr => (tr.cells[0] ? tr.cells[0].textContent.trim() : '')).filter(v => /^\w{6,}$/.test(v));
    return [...new Set([...l, ...adicionados])];
  }
  // Também guarda o que é digitado no Adicionar (a tabela do Fraction pode estar paginada).
  const adicionados = new Set();
  document.addEventListener('click', ev => {
    if (!(ev.target.closest && ev.target.closest(`[id="${FORM}:addLote"]`))) return;
    const ta = document.getElementById(`${FORM}:txtArea`);
    (ta ? ta.value : '').split(/[\s,;]+/).map(v => v.trim()).filter(v => /^\w{6,}$/.test(v)).forEach(v => adicionados.add(v));
  }, true);

  /* ---------- "PDF original" (aba nova): adiciona os mesmos manifestos e clica no ícone do PDF ---------- */
  const esperar = ms => new Promise(r => setTimeout(r, ms));
  function faixa(msg, erro) {
    let d = document.getElementById('tf-conf-aviso');
    if (!d) { d = document.createElement('div'); d.id = 'tf-conf-aviso'; document.body.appendChild(d); }
    d.style.cssText = 'position:fixed;top:12px;left:50%;transform:translateX(-50%);z-index:99999;padding:10px 18px;border-radius:6px;color:#fff;font:bold 13px Arial,sans-serif;box-shadow:0 3px 12px rgba(0,0,0,.3);background:' + (erro ? '#C8102E' : '#1d7a35');
    d.textContent = msg;
  }
  async function pdfAutomatico() {
    let ped;
    try { ped = (await chrome.storage.local.get('tf_conf_pdf')).tf_conf_pdf; } catch (e) { return; }
    if (!ped || !ped.manifestos || !ped.manifestos.length || Date.now() - ped.t > 120000) return;
    chrome.storage.local.remove('tf_conf_pdf');
    let ta = null;
    for (let i = 0; i < 40 && !ta; i++) { ta = document.getElementById(`${FORM}:txtArea`); if (!ta) await esperar(250); }
    const add = document.getElementById(`${FORM}:addLote`);
    const link = document.getElementById(`${FORM}:id_exportar_pdf`);
    if (!ta || !add || !link) { faixa('Não encontrei a tela da Conferência para gerar o PDF.', true); return; }
    faixa(`Adicionando ${ped.manifestos.length} manifesto(s) para gerar o PDF…`);
    const qtd = () => (document.getElementById(`${FORM}:dataListaconferenciaManifesto_data`)?.querySelectorAll('tr[data-ri]').length || 0);
    ta.value = ped.manifestos.join('\n');
    ta.dispatchEvent(new Event('input', { bubbles: true }));
    add.click();
    for (let i = 0; i < 120 && qtd() === 0; i++) await esperar(250);   // até 30 s
    if (!qtd()) { faixa('O Fraction não adicionou os manifestos. Confira a tela e clique no ícone do PDF.', true); return; }
    await esperar(800);
    // O botão oculto do PDF abre o relatório numa janela pop-up (que o Chrome bloquearia aqui):
    // passa a abrir nesta mesma aba.
    const btn = document.getElementById(`${FORM}:id_exportar_pdf_button`);
    if (btn) btn.setAttribute('onclick', "document.getElementById('" + FORM + "').target='_self';PrimeFaces.onPost();");
    faixa('Gerando o PDF da conferência…');
    document.getElementById(`${FORM}:id_exportar_pdf`).click();
  }
  setTimeout(pdfAutomatico, 300);

  async function gerar(btn) {
    const quadro = abrirPainel();
    btn.disabled = true;
    try {
      enviar(quadro, { tipo: 'tf-status', texto: 'Gerando o relatório de inconsistências no Fraction…' });
      const csv = await baixar('excel');
      // Arquivo da Performance guardado (Circuit, peso, bairro/cidade)
      let perf = null;
      try {
        const c = (await chrome.storage.local.get('tf_cache_performance')).tf_cache_performance;
        if (c && c.b64) perf = { buffer: deBase64(c.b64), nome: c.nome, quando: c.quando };
      } catch (e) { /* sem arquivo guardado */ }
      const transf = [csv.buffer];
      if (perf) transf.push(perf.buffer);
      enviar(quadro, { tipo: 'tf-faltantes', csv, perf, manifestos: manifestosDaTela() }, transf);
    } catch (e) {
      console.warn('[TurboFraction]', e);
      enviar(quadro, { tipo: 'tf-status', erro: true, texto: 'Não consegui gerar o relatório: ' + e.message + '.' });
    } finally {
      btn.disabled = false;
    }
  }

  function colocarBotao() {
    if (document.getElementById('tf-faltantes')) return;
    const excel = document.getElementById(`${FORM}:id_exportar_excel`);
    if (!excel) return;
    const btn = document.createElement('button');
    btn.id = 'tf-faltantes';
    btn.type = 'button';
    btn.className = 'tf-pend-botao';
    btn.textContent = '📦 Faltantes por Circuit';
    btn.title = 'Gera o relatório de inconsistências e mostra as remessas faltantes agrupadas por Circuit';
    btn.addEventListener('click', () => gerar(btn));
    const alvo = excel.closest('table') || excel.parentElement;
    alvo.parentElement.insertBefore(btn, alvo);
  }

  try { chrome.storage.local.set({ tf_origem: location.origin }); } catch (e) { /* ok */ }
  colocarBotao();
  let ag = 0;
  new MutationObserver(() => { if (!ag) ag = requestAnimationFrame(() => { ag = 0; colocarBotao(); }); })
    .observe(document.body, { childList: true, subtree: true });
})();
