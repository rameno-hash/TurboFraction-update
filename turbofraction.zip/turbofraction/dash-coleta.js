// TurboFraction — "DASHBOARD DE COLETAS" (Performance de Coleta dos últimos 30 dias, só Pendentes).
// Mesmo visual do Relatório de Pendências. Linhas: locais BR (Razão Local Coleta, coluna V); as demais coletas
// ficam em "Outras Coletas", abertas por Responsável (coluna P). Colunas: dias desde o último evento (coluna N).
// Mouse na célula: cartão com as coletas (número com link para a consulta; Descrição da coluna Q nos PUDOs BR).
(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const OUTRAS = 'Outras Coletas';
  const URL_TRACKING = 'https://www.jadlog.com.br/FractionWeb/jad/tracking?cte=';
  const sem = t => String(t || '').normalize('NFD').replace(/[̀-ͯ]/g, '').trim().toLowerCase();
  let coletas = [];      // { codigo, br, local, resp, desc, dias }
  let arquivoAtual = null;

  function carregando(t) { $('carregando').hidden = t == null; $('carregando-texto').textContent = t || ''; if (t != null) { $('area').innerHTML = ''; $('erro').hidden = true; } }
  function erro(t, diag) {
    carregando(null); $('area').innerHTML = ''; $('dados').hidden = true;
    const e = $('erro'); e.hidden = false; e.textContent = t;
    if (diag) { const s = document.createElement('small'); s.textContent = 'Caminho: ' + diag; e.appendChild(s); }
  }

  /** Data do evento: "16/10/2026 11:47:43", data ISO, Date ou número de série do Excel. */
  function dataDe(v) {
    if (v == null || v === '') return null;
    if (v instanceof Date) return isNaN(v) ? null : v;
    if (typeof v === 'number' || /^\d+(\.\d+)?$/.test(String(v).trim())) { const n = +v; if (n > 20000 && n < 80000) return new Date(Math.round((n - 25569) * 86400000) + new Date().getTimezoneOffset() * 60000); }
    const s = String(v).trim();
    let m = /^(\d{1,2})\/(\d{1,2})\/(\d{4})/.exec(s);
    if (m) return new Date(+m[3], +m[2] - 1, +m[1]);
    m = /^(\d{4})-(\d{2})-(\d{2})/.exec(s);
    if (m) return new Date(+m[1], +m[2] - 1, +m[3]);
    return null;
  }
  const diasAte = (d, hoje) => Math.round((new Date(hoje.getFullYear(), hoje.getMonth(), hoje.getDate()) - new Date(d.getFullYear(), d.getMonth(), d.getDate())) / 86400000);

  async function processar(buffer) {
    carregando('Lendo o arquivo…');
    const { cabecalho, linhas } = await TFXlsx.lerArquivo(new Blob([buffer]), t => carregando(t));
    const col = (...nomes) => { for (const n of nomes) { const i = cabecalho.findIndex(h => sem(h) === sem(n)); if (i >= 0) return i; } return -1; };
    // Pelo nome; se não achar, pela letra da coluna (A, K, N, P, Q, V).
    const c = {
      codigo: (x => x >= 0 ? x : 0)(col('Código', 'Codigo')),
      status: (x => x >= 0 ? x : 10)(col('Status')),
      evento: (x => x >= 0 ? x : 13)(col('Dt Evento', 'Data Evento')),
      resp: (x => x >= 0 ? x : 15)(col('Responsavel', 'Responsável')),
      desc: (x => x >= 0 ? x : 16)(col('Descrição', 'Descricao')),
      local: (x => x >= 0 ? x : 21)(col('Razao Local Coleta', 'Razão Local Coleta')),
    };
    const hoje = new Date();
    coletas = [];
    linhas.forEach(l => {
      let codigo = String(l[c.codigo] == null ? '' : l[c.codigo]).trim();
      if (/^\d+(\.\d+)?e\+?\d+$/i.test(codigo) || /^\d+\.0+$/.test(codigo)) codigo = String(Math.round(Number(codigo)));   // 6.3282669E8 -> 632826690
      if (!codigo || sem(l[c.status]) !== 'pendente') return;   // só coletas Pendentes
      const local = String(l[c.local] || '').replace(/\s+/g, ' ').trim();
      const d = dataDe(l[c.evento]);
      coletas.push({
        codigo, local, br: /^BR/i.test(local),
        resp: String(l[c.resp] || '').replace(/\s+/g, ' ').trim() || '(sem responsável)',
        desc: String(l[c.desc] || '').replace(/\s+/g, ' ').trim(),
        dias: d ? Math.max(0, diasAte(d, hoje)) : null,
      });
    });
    desenhar();
  }

  /* ---------- Tabela (mesma estrutura do Relatório de Pendências) ---------- */
  const grupos = new Map();   // 'linha|dia' -> [coletas]   (dia '*' = total da linha)
  const rotulos = new Map();
  const chave = (l, d) => l + '|' + d;
  function por(l, x) {
    [x.dias == null ? '?' : x.dias, '*'].forEach(d => { const k = chave(l, d); if (!grupos.has(k)) grupos.set(k, []); grupos.get(k).push(x); });
  }

  function desenhar() {
    grupos.clear(); rotulos.clear();
    const total = l => (grupos.get(chave(l, '*')) || []).length;
    coletas.forEach(x => {
      por('#total', x);
      if (x.br) por('br:' + x.local, x);
      else { por('#outras', x); por('out:' + x.resp, x); }
    });
    const ordem = (a, b) => total(b) - total(a) || a.localeCompare(b, 'pt-BR');
    const ids = pre => [...new Set([...grupos.keys()].map(k => k.slice(0, k.lastIndexOf('|'))))].filter(k => k.startsWith(pre)).sort(ordem);
    const linhas = [];
    ids('br:').forEach(id => { rotulos.set(id, id.slice(3)); linhas.push({ id, rotulo: id.slice(3), cls: '' }); });
    const outras = ids('out:');
    if (outras.length) {
      rotulos.set('#outras', OUTRAS);
      linhas.push({ id: '#outras', rotulo: OUTRAS, cls: 'grupo' });
      outras.forEach(id => { rotulos.set(id, OUTRAS + ' · ' + id.slice(4)); linhas.push({ id, rotulo: id.slice(4), cls: 'sub' }); });
    }
    rotulos.set('#total', 'Total Geral');
    linhas.push({ id: '#total', rotulo: 'Total Geral', cls: 'total-geral' });

    const dias = [...new Set(coletas.map(d => d.dias == null ? '?' : d.dias))].sort((a, b) => (a === '?') - (b === '?') || a - b);
    const t = document.createElement('table');
    t.className = 'pivo';
    const thead = t.createTHead();
    thead.insertRow().innerHTML = `<th class="linha" rowspan="2">Local Coleta \\ Dias parados</th><th class="dias-titulo" colspan="${dias.length}">Dias desde o último evento</th><th class="total" rowspan="2">Total Geral</th>`;
    const c2 = thead.insertRow();
    dias.forEach(d => { const th = document.createElement('th'); th.className = 'dia'; th.textContent = d; c2.appendChild(th); });
    const corpo = t.createTBody();
    linhas.forEach(L => {
      const tr = corpo.insertRow();
      tr.className = L.cls;
      const th = document.createElement('th'); th.className = 'linha'; th.textContent = L.rotulo; th.title = L.rotulo; tr.appendChild(th);
      [...dias, '*'].forEach(dia => {
        const td = tr.insertCell(), q = (grupos.get(chave(L.id, dia)) || []).length;
        td.textContent = q ? q.toLocaleString('pt-BR') : '';
        const cls = [];
        if (dia === '*') cls.push('total');
        if (q) {
          cls.push('n'); td.dataset.l = L.id; td.dataset.d = dia;
          if (dia !== '*' && !/\b(total-geral|grupo)\b/.test(L.cls)) cls.push(dia === '?' ? '' : dia >= 10 ? 'q4' : dia >= 7 ? 'q3' : dia >= 3 ? 'q2' : dia >= 1 ? 'q1' : '');
        }
        td.className = cls.filter(Boolean).join(' ');
      });
    });
    carregando(null);
    $('area').innerHTML = '';
    $('area').appendChild(t);
    const nBr = ids('br:').length;
    $('fonte').textContent = `${coletas.length.toLocaleString('pt-BR')} coletas · ${nBr} PUDO(s)` + (outras.length ? ` + ${total('#outras')} em Outras Coletas` : '');
  }

  /* ---------- Cartão com as coletas da célula ---------- */
  const cartao = $('cartao');
  let celulaAtiva = null, fecharTimer = 0;
  $('area').addEventListener('mouseover', ev => {
    const td = ev.target.closest('td.n');
    if (!td || td === celulaAtiva) return;
    abrirCartao(td);
  });
  $('area').addEventListener('mouseout', ev => { if (ev.target.closest('td.n')) agendarFechar(); });
  $('area').addEventListener('scroll', () => fecharCartao());
  cartao.addEventListener('mouseenter', () => clearTimeout(fecharTimer));
  cartao.addEventListener('mouseleave', agendarFechar);
  cartao.querySelector('.c-fechar').addEventListener('click', fecharCartao);
  document.addEventListener('keydown', ev => { if (ev.key === 'Escape') fecharCartao(); });
  function agendarFechar() { clearTimeout(fecharTimer); fecharTimer = setTimeout(fecharCartao, 350); }
  function fecharCartao() {
    clearTimeout(fecharTimer);
    cartao.hidden = true;
    if (celulaAtiva) celulaAtiva.classList.remove('ativo');
    celulaAtiva = null;
  }
  function abrirCartao(td) {
    clearTimeout(fecharTimer);
    if (celulaAtiva) celulaAtiva.classList.remove('ativo');
    celulaAtiva = td; td.classList.add('ativo');
    const l = td.dataset.l, d = td.dataset.d;
    const lista = (grupos.get(chave(l, d)) || []).slice().sort((a, b) => (b.dias ?? -1) - (a.dias ?? -1) || a.codigo.localeCompare(b.codigo, 'pt-BR', { numeric: true }));
    const quando = d === '*' ? 'todos os dias' : d === '?' ? 'sem data de evento' : `${d} dia(s) parado(s)`;
    cartao.querySelector('.c-titulo').textContent = `${rotulos.get(l) || l} · ${quando} — ${lista.length.toLocaleString('pt-BR')} coleta(s)`;
    const caixa = cartao.querySelector('.c-lista');
    caixa.innerHTML = '';
    lista.forEach(x => {
      const linha = document.createElement('div'); linha.className = 'c-linha';
      const a = document.createElement('a');
      a.href = URL_TRACKING + encodeURIComponent(x.codigo); a.target = '_blank'; a.rel = 'noopener';
      a.textContent = x.codigo; a.title = 'Abrir a consulta da coleta ' + x.codigo + ' em outra aba';
      const info = document.createElement('span');
      // PUDOs (BR…): Descrição da coluna Q. Outras Coletas: PENDENTE.
      const txt = x.br ? (x.desc || 'PENDENTE') : 'PENDENTE';
      info.className = 'c-info' + (txt === 'PENDENTE' ? ' pendente' : '');
      info.textContent = txt; info.title = txt + (x.dias != null && d === '*' ? ` · ${x.dias} dia(s)` : '');
      linha.append(a, info);
      caixa.appendChild(linha);
    });
    cartao.hidden = false;
    const r = td.getBoundingClientRect(), w = cartao.offsetWidth, h = cartao.offsetHeight;
    let left = r.right + 8; if (left + w > innerWidth - 8) left = Math.max(8, r.left - w - 8);
    let top = r.top; if (top + h > innerHeight - 8) top = innerHeight - h - 8;
    cartao.style.left = left + 'px'; cartao.style.top = Math.max(8, top) + 'px';
  }

  /* ---------- De quando são os dados + botões ---------- */
  function mostrarOrigemDados(d) {
    const el = $('dados'); if (!d.quando) return;
    const q = new Date(d.quando);
    const hora = q.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
    const dia = q.toDateString() === new Date().toDateString() ? 'hoje' : q.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
    el.querySelector('.d-txt').textContent = (d.periodo ? `Período: ${d.periodo} · ` : '') + `${d.guardado ? 'Arquivo guardado' : 'Arquivo gerado'} ${dia} às ${hora}` + (d.proxima ? ` · próxima atualização do Fraction: ${d.proxima}` : '');
    el.title = d.guardado ? 'O Fraction ainda não atualizou os dados desde este arquivo, por isso ele foi reaproveitado sem gerar de novo.' : '';
    el.hidden = false;
  }
  $('baixar-arq').addEventListener('click', () => {
    if (!arquivoAtual) return;
    const q = new Date(arquivoAtual.quando || Date.now()), p = n => String(n).padStart(2, '0');
    const m = /^(.*?)(\.[^.]+)?$/.exec(arquivoAtual.nome);
    const a = document.createElement('a');
    a.href = URL.createObjectURL(arquivoAtual.blob);
    a.download = `${m[1]}_${q.getFullYear()}-${p(q.getMonth() + 1)}-${p(q.getDate())}_${p(q.getHours())}h${p(q.getMinutes())}${m[2] || ''}`;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 10000);
  });
  $('regerar').addEventListener('click', () => { $('dados').hidden = true; fecharCartao(); carregando('Gerando o arquivo no Fraction…'); parent.postMessage({ tipo: 'tf-regerar' }, '*'); });

  window.addEventListener('message', async ev => {
    const d = ev.data;
    if (!d || ev.source !== parent) return;
    if (d.tipo === 'tf-status') { if (d.erro) erro(d.texto, d.diag); else { $('dados').hidden = true; carregando(d.texto); } }
    if (d.tipo === 'tf-coletas' && d.buffer) {
      arquivoAtual = { blob: new Blob([d.buffer.slice(0)]), nome: d.nome || 'Performance de Coleta.zip', quando: d.quando };
      try { await processar(d.buffer); mostrarOrigemDados(d); } catch (e) { console.error(e); erro('Não consegui ler o arquivo: ' + e.message); }
    }
  });
})();
