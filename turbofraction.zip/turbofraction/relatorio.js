// TurboFraction — Relatório de Pendências (CUSTÓDIA por ocorrência + demais status + transferências × dias parados).
(() => {
  'use strict';

  const $ = id => document.getElementById(id);
  const VAZIO = '(vazio)';
  const ENTREGUES = /^ENTREGUE( NO PICKUP)?$/;
  const LIMITE_CARTAO = 300;     // linhas mostradas no cartão
  const LIMITE_PESQUISA = 500;   // remessas enviadas para a Consulta de uma vez

  const MODO = location.hash.slice(1);   // '' (arquivo), 'painel' ou 'vencimentos'
  let dados = [];                // [{codigo, status, desc, ponto, uf, cidade, bairro, rota, circuit, previsao, dias, tratativa}]
  let origem = 'https://www.jadlog.com.br';
  let celulaAtiva = null, fecharTimer = null, listaCartao = [];

  /* ---------- Carregar o arquivo ---------- */

  function estado(t) { $('estado').textContent = t || ''; }

  /** Tela de espera com o cubo girando (texto = null esconde). */
  function carregando(texto) {
    $('carregando').hidden = texto == null;
    $('carregando-texto').textContent = texto || '';
    if (texto != null) $('area').innerHTML = '';
  }

  // Status que entram na tabela (além da CUSTÓDIA, que é aberta por ocorrência).
  const DEMAIS = ['ENTRADA', 'EM ROTA', 'EM DEVOLUCAO', 'DISPONIVEL RETIRADA PICKUP', 'TRAVADO', 'EM ROTA PICKUP', 'EMISSAO', 'UNITIZADO'];
  const TRANSFER = ['TRANSFERENCIA', 'TRANSFERIDO PARA UNIDADE'];
  // Ocorrências da CUSTÓDIA que vão para o grupo "Outras Pendências" (pode ser recolhido).
  const normal = t => String(t || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\s+/g, '').toUpperCase();
  const OUTRAS = new Set(['AVARIA / DANO TOTAL', 'FALTA DE ACAREAÇÃO / TOTAL', 'FIM PRAZO DE ARMAZENAGEM / RETIRADA VENCIDA',
    'INDENIZACAO RECUSADA', 'AVARIA / DANO PARCIAL', 'LIBERADO',
    'FALTA DE COMPROVANTE DE ENTREGA / TOTAL', 'PERDA POR PRAZO SLA / TOTAL', 'EXTRAVIO TOTAL', 'RETIRADA EFETUADA PELO MOTORISTA'].map(normal));
  const CHAVE_OUTRAS = 'tf_outras_aberto';
  let outrasAberto = false;
  try { outrasAberto = localStorage.getItem(CHAVE_OUTRAS) === '1'; } catch (e) { /* ok */ }

  /** Data "dd/mm/aaaa hh:mm:ss" ou número de série do Excel -> Date (meia-noite). */
  function dataDe(txt) {
    if (!txt) return null;
    let m = /^(\d{2})\/(\d{2})\/(\d{4})/.exec(txt);
    if (m) return new Date(+m[3], +m[2] - 1, +m[1]);
    m = /^(\d{4})-(\d{2})-(\d{2})/.exec(txt);
    if (m) return new Date(+m[1], +m[2] - 1, +m[3]);
    const n = parseFloat(txt.replace(',', '.'));
    if (!isNaN(n) && n > 20000 && n < 80000) { const d = new Date(Date.UTC(1899, 11, 30) + Math.floor(n) * 864e5); return new Date(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()); }
    return null;
  }
  const HOJE = (() => { const d = new Date(); return new Date(d.getFullYear(), d.getMonth(), d.getDate()); })();
  /** Aging = dias desde o último evento (igual à coluna HOJE() − Dt da planilha). */
  const aging = txt => { const d = dataDe(txt); return d ? Math.round((HOJE - d) / 864e5) : null; };

  async function carregar(arquivo) {
    try {
      carregando('Lendo o arquivo…');
      estado('Lendo ' + arquivo.name + '…');
      const t0 = Date.now();
      const { cabecalho, linhas } = await TFXlsx.lerArquivo(arquivo, t => { estado(t); carregando(t); });
      const col = (...nomes) => { for (const n of nomes) { const i = cabecalho.findIndex(h => h.toLowerCase() === n.toLowerCase()); if (i >= 0) return i; } return -1; };
      const c = {
        codigo: col('Codigo'), status: col('Status'), desc: col('Descricao'), ponto: col('Hist. ultimo ponto'), uf: col('Hist. ultima uf'),
        cidade: col('Cidade'), bairro: col('Bairro'), rota: col('Rota'), circuit: col('Circuit'),
        previsao: col('Previsao'), evento: col('Dt Evento', 'Dt'), tratativa: col('Tratativa'),
      };
      if (c.codigo < 0 || c.status < 0 || c.desc < 0) throw new Error('A planilha não tem as colunas Codigo / Status / Descricao');
      const v = (l, i) => (i >= 0 && l[i] != null ? String(l[i]).trim() : '');
      dados = linhas.map(l => ({
        codigo: v(l, c.codigo), status: v(l, c.status) || VAZIO, desc: v(l, c.desc) || VAZIO, ponto: v(l, c.ponto) || VAZIO, uf: v(l, c.uf),
        cidade: v(l, c.cidade), bairro: v(l, c.bairro), rota: v(l, c.rota), circuit: v(l, c.circuit),
        previsao: v(l, c.previsao), dias: aging(v(l, c.evento)), tratativa: v(l, c.tratativa),
      })).filter(d => d.codigo);
      estado(`Pronto (${((Date.now() - t0) / 1000).toFixed(1)} s)`);
      definirUnidade();
      carregando(null);
      if (MODO === 'vencimentos') desenharVencimentos(); else if (ehOrigem()) desenharOrigem(); else desenhar();
    } catch (e) {
      console.error(e);
      carregando(null);
      estado('Erro: ' + e.message);
      $('area').innerHTML = '';
      const p = document.createElement('p'); p.className = 'resumo-topo'; p.textContent = 'Erro: ' + e.message;
      $('area').before(p);
    }
  }

  $('arquivo').addEventListener('change', ev => { const f = ev.target.files[0]; if (f) carregar(f); });
  document.addEventListener('dragover', ev => { ev.preventDefault(); document.body.classList.add('arrastando'); });
  document.addEventListener('dragleave', ev => { if (!ev.relatedTarget) document.body.classList.remove('arrastando'); });
  document.addEventListener('drop', ev => {
    ev.preventDefault(); document.body.classList.remove('arrastando');
    const f = ev.dataTransfer.files[0]; if (f) carregar(f);
  });

  /* ---------- Unidade e filial ---------- */

  let unidade = '', filial = '';
  function maisFrequente(lista) {
    const cont = new Map();
    lista.forEach(x => { if (x && x !== VAZIO) cont.set(x, (cont.get(x) || 0) + 1); });
    return [...cont.entries()].sort((a, b) => b[1] - a[1])[0]?.[0] || '';
  }
  function definirUnidade() {
    // Nossa unidade: o último ponto com mais remessas no arquivo.
    unidade = maisFrequente(dados.map(d => d.ponto));
    // Filial que abastece a unidade: a "FL ..." do mesmo estado com mais transferências.
    const ufUnid = maisFrequente(dados.filter(d => d.ponto === unidade).map(d => d.uf));
    const transf = dados.filter(d => TRANSFER.includes(d.status));
    filial = maisFrequente(transf.filter(d => /^FL\b/i.test(d.ponto) && (!ufUnid || d.uf === ufUnid)).map(d => d.ponto))
      || maisFrequente(transf.filter(d => /^FL\b/i.test(d.ponto)).map(d => d.ponto));
    $('unidade').textContent = unidade ? '📍 ' + unidade : '';
  }

  /* ---------- Tabela: linhas por status/ocorrência × dias parados ---------- */

  const chave = (linha, dia) => linha + '\u0001' + dia;
  let grupos = new Map();   // "linha␁dia" -> registros ("*" = total)
  let rotulos = new Map();  // linha -> título do cartão

  function desenhar() {
    fecharCartao();
    grupos = new Map(); rotulos = new Map();
    const add = (linha, d) => {
      for (const k of [chave(linha, d.dias == null ? '?' : d.dias), chave(linha, '*')]) { let g = grupos.get(k); if (!g) grupos.set(k, g = []); g.push(d); }
    };
    const custodia = [], outras = [], demais = [], transf = [];
    dados.forEach(d => {
      if (d.ponto === unidade && d.status === 'CUSTODIA' && OUTRAS.has(normal(d.desc))) { outras.push(d); add('O:' + d.desc, d); add('G:OUTRAS', d); add('TOTAL', d); }
      else if (d.ponto === unidade && d.status === 'CUSTODIA') { custodia.push(d); add('C:' + d.desc, d); add('G:CUSTODIA', d); add('TOTAL', d); }
      else if (d.ponto === unidade && DEMAIS.includes(d.status)) { demais.push(d); add('S:' + d.status, d); add('TOTAL', d); }
      else if (filial && d.ponto === filial && TRANSFER.includes(d.status)) { transf.push(d); add('T:' + d.status, d); add('G:TRANSF', d); add('TOTAL', d); }
    });
    const total = linha => (grupos.get(chave(linha, '*')) || []).length;
    const porTotal = (a, b) => total(b) - total(a) || a.localeCompare(b, 'pt-BR');

    // Linhas da tabela
    const linhas = [];
    if (custodia.length) {
      linhas.push({ id: 'G:CUSTODIA', rotulo: 'CUSTODIA', cls: 'grupo' });
      rotulos.set('G:CUSTODIA', 'CUSTODIA');
      [...new Set(custodia.map(d => 'C:' + d.desc))].sort(porTotal).forEach(id => {
        const desc = id.slice(2); linhas.push({ id, rotulo: desc === VAZIO ? '(sem ocorrência)' : desc, cls: 'sub' });
        rotulos.set(id, 'CUSTODIA · ' + (desc === VAZIO ? 'sem ocorrência' : desc));
      });
    }
    [...new Set(demais.map(d => 'S:' + d.status))].sort(porTotal).forEach(id => { linhas.push({ id, rotulo: id.slice(2), cls: 'status' }); rotulos.set(id, id.slice(2)); });
    if (outras.length) {
      linhas.push({ id: 'G:OUTRAS', rotulo: 'Outras Pendências', cls: 'grupo outras', dobra: true });
      rotulos.set('G:OUTRAS', 'Outras Pendências');
      [...new Set(outras.map(d => 'O:' + d.desc))].sort(porTotal).forEach(id => {
        linhas.push({ id, rotulo: id.slice(2), cls: 'sub sub-outras' });
        rotulos.set(id, 'CUSTODIA · ' + id.slice(2));
      });
    }
    if (transf.length) {
      linhas.push({ id: 'G:TRANSF', rotulo: 'TRANSFERÊNCIAS — ' + filial, cls: 'grupo' });
      rotulos.set('G:TRANSF', 'Transferências em ' + filial);
      TRANSFER.filter(s => total('T:' + s)).forEach(s => { linhas.push({ id: 'T:' + s, rotulo: s, cls: 'sub' }); rotulos.set('T:' + s, s + ' · ' + filial); });
    }
    linhas.push({ id: 'TOTAL', rotulo: 'Total Geral', cls: 'total-geral' });
    rotulos.set('TOTAL', 'Todas as pendências');

    montarTabela(linhas, [...custodia, ...outras, ...demais, ...transf]);
  }

  /* ---------- Origem: as remessas da unidade de origem estão em vários últimos pontos ---------- */
  const FINALIZADO = /^(ENTREGUE|DEVOLVIDO|CANCELAD)/;
  let tipoArq = '';            // 'ORIGEM' | 'DESTINO' (vem da tela da Performance; vazio = DESTINO)
  const pontosAbertos = new Set();
  // Só vira ORIGEM quando a tela da Performance avisa que a consulta foi por Origem.
  function ehOrigem() { return tipoArq === 'ORIGEM'; }
  function desenharOrigem() {
    fecharCartao();
    grupos = new Map(); rotulos = new Map();
    const add = (linha, d) => {
      for (const k of [chave(linha, d.dias == null ? '?' : d.dias), chave(linha, '*')]) { let g = grupos.get(k); if (!g) grupos.set(k, g = []); g.push(d); }
    };
    const base = dados.filter(d => !FINALIZADO.test(d.status));
    const descDe = d => (d.desc && d.desc !== VAZIO ? d.desc : '(sem ocorrência)');
    base.forEach(d => {
      const pt = d.ponto || VAZIO; add('P:' + pt, d); add('PS:' + pt + '\u0003' + d.status, d); add('TOTAL', d);
      if (d.status === 'CUSTODIA') add('PD:' + pt + '\u0003' + descDe(d), d);   // custódia aberta pela Descrição
    });
    const total = linha => (grupos.get(chave(linha, '*')) || []).length;
    const pontos = [...new Set(base.map(d => d.ponto || VAZIO))].sort((a, b) => total('P:' + b) - total('P:' + a) || a.localeCompare(b, 'pt-BR'));
    const linhas = [];
    pontos.forEach(pt => {
      const id = 'P:' + pt, nome = pt === VAZIO ? '(sem unidade atual)' : pt;
      linhas.push({ id, rotulo: nome, cls: 'grupo ponto', ponto: id });
      rotulos.set(id, 'Unidade atual: ' + nome);
      [...new Set(base.filter(d => (d.ponto || VAZIO) === pt).map(d => d.status))].sort((a, b) => total('PS:' + pt + '\u0003' + b) - total('PS:' + pt + '\u0003' + a) || a.localeCompare(b, 'pt-BR'))
        .forEach(st => {
          const sid = 'PS:' + pt + '\u0003' + st; linhas.push({ id: sid, rotulo: st, cls: 'sub sub-ponto', de: id }); rotulos.set(sid, st + ' · ' + nome);
          if (st !== 'CUSTODIA') return;
          [...new Set(base.filter(d => (d.ponto || VAZIO) === pt && d.status === 'CUSTODIA').map(descDe))]
            .sort((a, b) => total('PD:' + pt + '\u0003' + b) - total('PD:' + pt + '\u0003' + a) || a.localeCompare(b, 'pt-BR'))
            .forEach(ds => { const did = 'PD:' + pt + '\u0003' + ds; linhas.push({ id: did, rotulo: ds, cls: 'sub sub-ponto sub-desc', de: id }); rotulos.set(did, 'CUSTODIA · ' + ds + ' · ' + nome); });
        });
    });
    linhas.push({ id: 'TOTAL', rotulo: 'Total Geral', cls: 'total-geral' });
    rotulos.set('TOTAL', 'Todas as pendências (origem)');
    $('unidade').textContent = `📍 Origem · ${pontos.length} unidade(s) atual(is)`;
    montarTabela(linhas, base, 'Unidade Atual \\ Dias parados');
  }

  function montarTabela(linhas, base, tituloLinha) {
    // Colunas: dias parados presentes
    const dias = [...new Set(base.map(d => d.dias == null ? '?' : d.dias))].sort((a, b) => (a === '?') - (b === '?') || a - b);

    const t = document.createElement('table');
    t.className = 'pivo';
    const thead = t.createTHead();
    const c1 = thead.insertRow();
    c1.innerHTML = `<th class="linha" rowspan="2">${tituloLinha || 'Pendências \\ Dias parados'}</th><th class="dias-titulo" colspan="${dias.length}">Dias desde o último evento</th><th class="total" rowspan="2">Total Geral</th>`;
    const c2 = thead.insertRow();
    dias.forEach(d => { const th = document.createElement('th'); th.className = 'dia'; th.textContent = d; c2.appendChild(th); });

    const corpo = t.createTBody();
    linhas.forEach(L => {
      const tr = corpo.insertRow();
      tr.className = L.cls;
      const th = document.createElement('th'); th.className = 'linha'; th.textContent = L.rotulo; th.title = L.rotulo; tr.appendChild(th);
      if (L.dobra) {
        const b = document.createElement('button');
        b.type = 'button'; b.className = 'dobra';
        const marcar = () => { b.textContent = outrasAberto ? '−' : '+'; b.title = outrasAberto ? 'Ocultar estas pendências' : 'Mostrar estas pendências'; t.classList.toggle('outras-fechado', !outrasAberto); };
        b.addEventListener('click', ev => { ev.stopPropagation(); outrasAberto = !outrasAberto; try { localStorage.setItem(CHAVE_OUTRAS, outrasAberto ? '1' : '0'); } catch (e) { /* ok */ } marcar(); });
        th.prepend(b); th.title = 'Outras Pendências (clique em −/+ para ocultar ou mostrar)';
        marcar();
      }
      if (L.ponto) {
        const b = document.createElement('button');
        b.type = 'button'; b.className = 'dobra';
        const marcar = () => { const ab = pontosAbertos.has(L.id); b.textContent = ab ? '−' : '+'; b.title = ab ? 'Recolher' : 'Mostrar os status deste ponto'; corpo.querySelectorAll('tr[data-de="' + CSS.escape(L.id) + '"]').forEach(x => { x.hidden = !ab; }); };
        b.addEventListener('click', ev => { ev.stopPropagation(); if (pontosAbertos.has(L.id)) pontosAbertos.delete(L.id); else pontosAbertos.add(L.id); marcar(); });
        b.textContent = pontosAbertos.has(L.id) ? '−' : '+'; b.title = pontosAbertos.has(L.id) ? 'Recolher' : 'Mostrar os status deste ponto';
        th.prepend(b);
      }
      if (L.de) { tr.dataset.de = L.de; tr.hidden = !pontosAbertos.has(L.de); }
      [...dias, '*'].forEach(dia => {
        const td = tr.insertCell(), q = (grupos.get(chave(L.id, dia)) || []).length;
        td.textContent = q ? q.toLocaleString('pt-BR') : '';
        const cls = [];
        if (dia === '*') cls.push('total');
        if (q) {
          cls.push('n'); td.dataset.l = L.id; td.dataset.d = dia;
          if (dia !== '*' && !/\b(total-geral|grupo)\b/.test(L.cls)) cls.push(dia === '?' ? '' : dia >= 10 ? 'q4' : dia >= 7 ? 'q3' : dia >= 3 ? 'q2' : dia >= 1 ? 'q1' : '');
        }
        td.className = cls.filter(Boolean).join(' ');
      });
    });

    $('area').innerHTML = '';
    $('area').appendChild(t);
    $('fonte').textContent = `${base.length.toLocaleString('pt-BR')} pendências`;
  }

  /* ---------- Cartão com as remessas da célula ---------- */

  const cartao = $('cartao');
  $('area').addEventListener('mouseover', ev => {
    const td = ev.target.closest('td.n');
    if (!td || td === celulaAtiva) return;
    abrirCartao(td);
  });
  $('area').addEventListener('mouseout', ev => { if (ev.target.closest('td.n')) agendarFechar(); });
  cartao.addEventListener('mouseenter', () => clearTimeout(fecharTimer));
  cartao.addEventListener('mouseleave', agendarFechar);
  cartao.querySelector('.c-fechar').addEventListener('click', fecharCartao);
  document.addEventListener('keydown', ev => { if (ev.key === 'Escape') fecharCartao(); });

  function agendarFechar() { clearTimeout(fecharTimer); fecharTimer = setTimeout(fecharCartao, 350); }
  function fecharCartao() {
    clearTimeout(fecharTimer);
    cartao.hidden = true;
    if (celulaAtiva) celulaAtiva.classList.remove('ativo');
    celulaAtiva = null;
  }

  function abrirCartao(td) {
    clearTimeout(fecharTimer);
    if (celulaAtiva) celulaAtiva.classList.remove('ativo');
    celulaAtiva = td; td.classList.add('ativo');
    const l = td.dataset.l, dia = td.dataset.d;
    listaCartao = (grupos.get(chave(l, dia)) || []).slice().sort((a, b) => (b.dias ?? -1) - (a.dias ?? -1));
    const quando = dia === '*' ? 'todos os dias' : dia === '?' ? 'sem data' : `${dia} dia(s) parado(s)`;
    cartao.querySelector('.c-titulo').textContent = `${rotulos.get(l) || l} · ${quando} — ${listaCartao.length.toLocaleString('pt-BR')} remessa(s)`;
    cartao.querySelector('.c-msg').textContent = listaCartao.length > LIMITE_PESQUISA ? `A pesquisa leva as ${LIMITE_PESQUISA} primeiras.` : '';
    const lista = cartao.querySelector('.c-lista');
    lista.innerHTML = '';
    const frag = document.createDocumentFragment();
    const mostraStatus = l.startsWith('G:') || l === 'TOTAL';
    listaCartao.slice(0, LIMITE_CARTAO).forEach(d => {
      const div = document.createElement('div'); div.className = 'c-linha';
      const a = document.createElement('a');
      a.href = origem + '/FractionWeb/jad/tracking?cte=' + encodeURIComponent(d.codigo);
      a.target = '_blank'; a.rel = 'noopener'; a.textContent = d.codigo;
      const info = document.createElement('span'); info.className = 'c-info';
      info.textContent = [
        d.rota && 'Rota ' + d.rota, d.circuit && 'Circuit ' + d.circuit,
        d.previsao && 'Prev. ' + d.previsao, dia === '*' && d.dias != null && d.dias + 'd parado',
      ].filter(Boolean).join(' · ');
      const sub = document.createElement('span'); sub.className = 'c-sub';
      sub.textContent = [
        mostraStatus ? d.status + (d.status === 'CUSTODIA' && d.desc !== VAZIO ? ' / ' + d.desc : '') : '',
        [d.bairro, d.cidade].filter(Boolean).join(' - '), d.tratativa,
      ].filter(Boolean).join(' · ');
      div.append(a, info);
      if (sub.textContent) div.append(sub);
      frag.appendChild(div);
    });
    lista.appendChild(frag);
    if (listaCartao.length > LIMITE_CARTAO) {
      const mais = document.createElement('div'); mais.className = 'c-mais';
      mais.textContent = `… e mais ${(listaCartao.length - LIMITE_CARTAO).toLocaleString('pt-BR')} remessa(s).`;
      lista.appendChild(mais);
    }
    // Posição: ao lado da célula, sem sair da tela.
    cartao.hidden = false;
    const r = td.getBoundingClientRect(), w = cartao.offsetWidth, h = cartao.offsetHeight;
    let left = r.right + 8; if (left + w > innerWidth - 8) left = Math.max(8, r.left - w - 8);
    let top = Math.min(r.top - 10, innerHeight - h - 8);
    cartao.style.left = left + 'px'; cartao.style.top = Math.max(8, top) + 'px';
  }

  cartao.querySelector('.c-copiar').addEventListener('click', async () => {
    const txt = listaCartao.map(d => d.codigo).join('\n');
    cartao.querySelector('.c-msg').textContent = await copiar(txt) ? `${listaCartao.length} código(s) copiados.` : 'Não consegui copiar.';
  });

  cartao.querySelector('.c-pesquisar').addEventListener('click', async () => {
    const codigos = [...new Set(listaCartao.map(d => d.codigo))].slice(0, LIMITE_PESQUISA);
    await chrome.storage.local.set({ tf_pesq_lote: { v: codigos, t: Date.now() } });
    chrome.tabs.create({ url: origem + '/FractionWeb/jad/consulta' });
  });


  /* ---------- Vencimentos do dia (previsão = hoje, ainda não entregues) ---------- */

  const FINAIS = /^(ENTREGUE( NO PICKUP)?|DEVOLVIDO|SINISTRO|FINALIZADO|CANCELADO)$/;
  const ORDEM_STATUS = ['ENTRADA', 'EM ROTA', 'CUSTODIA', 'DISPONIVEL RETIRADA PICKUP', 'EM ROTA PICKUP', 'TRAVADO', 'EM DEVOLUCAO', 'UNITIZADO', 'EMISSAO', 'TRANSFERIDO PARA UNIDADE', 'TRANSFERENCIA'];
  const CHAVE_AGRUPAR = 'tf_venc_agrupar';
  let agrupar = 'circuit', vencHoje = [], DIA = HOJE;
  const recolhidos = new Set();   // grupos minimizados (agrupamento␁nome)
  const isoDe = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  const diaTxt = () => DIA.getTime() === HOJE.getTime() ? 'hoje' : 'em ' + DIA.toLocaleDateString('pt-BR');
  function montarSeletorData() {
    const h1 = document.querySelector('.topo h1');
    h1.textContent = 'Vencimentos do Dia — ';
    const inp = document.createElement('input');
    inp.type = 'date'; inp.id = 'v-data'; inp.value = isoDe(HOJE); inp.title = 'Escolha outra data para ver as remessas que vencem nesse dia';
    inp.addEventListener('change', () => {
      const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(inp.value);
      DIA = m ? new Date(+m[1], +m[2] - 1, +m[3]) : HOJE;
      if (!m) inp.value = isoDe(HOJE);
      if (dados.length) desenharVencimentos();
    });
    h1.appendChild(inp);
  }
  try { agrupar = localStorage.getItem(CHAVE_AGRUPAR) || 'circuit'; } catch (e) { /* padrão */ }
  // Filtro ORIGEM: agrupa pelo último ponto da etiqueta (em vez do Circuit).
  let agruparOrigem = 'ponto', ORIG = false;
  try { agruparOrigem = localStorage.getItem(CHAVE_AGRUPAR + '_origem') || 'ponto'; } catch (e) { /* padrão */ }
  const ag = () => (ORIG ? agruparOrigem : agrupar);
  const pontoDe = d => (d.ponto && d.ponto !== VAZIO ? d.ponto : '(sem unidade atual)');
  const ehHoje = txt => { const d = dataDe(txt); return !!d && d.getTime() === DIA.getTime(); };
  const FORA = 'AINDA EM OUTRA UNIDADE';
  const fora = d => !ORIG && d.ponto && d.ponto !== VAZIO && unidade && d.ponto !== unidade;
  const statusDe = d => fora(d) ? FORA : d.status;
  const onde = d => statusCompleto(d) + (fora(d) ? ' — ' + d.ponto : '');
  const circuitDe = d => { const c = (d.circuit || '').trim(); return /^\d+$/.test(c) ? String(+c) : c; };
  const statusCompleto = d => d.status + (d.status === 'CUSTODIA' && d.desc !== VAZIO ? ' / ' + d.desc : '');
  const posStatus = st => { const i = ORDEM_STATUS.indexOf(st); return i < 0 ? 50 : i; };

  function gruposVencimento() {
    const A = ag();
    const mapa = new Map();
    vencHoje.forEach(d => {
      const k = A === 'ponto' ? pontoDe(d) : A === 'circuit' ? (circuitDe(d) || '(sem circuit)') : statusDe(d);
      if (!mapa.has(k)) mapa.set(k, []);
      mapa.get(k).push(d);
    });
    const num = k => { const n = parseInt(k, 10); return isNaN(n) ? Infinity : n; };
    const ordem = A === 'ponto'
      ? (a, b) => b[1].length - a[1].length || a[0].localeCompare(b[0], 'pt-BR')
      : A === 'circuit'
        ? (a, b) => num(a[0]) - num(b[0]) || a[0].localeCompare(b[0], 'pt-BR')
        : (a, b) => (a[0] === FORA) - (b[0] === FORA) || posStatus(a[0]) - posStatus(b[0]) || a[0].localeCompare(b[0], 'pt-BR');
    const porItem = A === 'ponto'
      ? (a, b) => posStatus(a.status) - posStatus(b.status) || a.codigo.localeCompare(b.codigo)
      : A === 'circuit'
        ? (a, b) => fora(a) - fora(b) || posStatus(a.status) - posStatus(b.status) || a.codigo.localeCompare(b.codigo)
        : ORIG
          ? (a, b) => pontoDe(a).localeCompare(pontoDe(b), 'pt-BR') || a.codigo.localeCompare(b.codigo)
          : (a, b) => (parseInt(a.circuit, 10) || 1e9) - (parseInt(b.circuit, 10) || 1e9) || a.desc.localeCompare(b.desc) || a.codigo.localeCompare(b.codigo);
    return [...mapa.entries()].sort(ordem).map(([k, l]) => [k, l.sort(porItem)]);
  }

  function desenharVencimentos() {
    fecharCartao();
    ORIG = ehOrigem();
    vencHoje = dados.filter(d => !FINAIS.test(d.status) && ehHoje(d.previsao));
    const area = $('area');
    area.innerHTML = '';
    $('fonte').textContent = `${vencHoje.length.toLocaleString('pt-BR')} remessa(s) ${DIA < HOJE ? 'venceram' : 'vencem'} ${diaTxt()}`;

    const barra = document.createElement('div');
    barra.className = 'v-barra';
    barra.innerHTML = '<span class="v-rot">Agrupar por:</span>' + (ORIG ? '<button type="button" data-a="ponto">Unidade Atual</button>' : '<button type="button" data-a="circuit">Circuit</button>') + '<button type="button" data-a="status">Status</button>' +
      '<button type="button" class="v-todos" data-t="-" title="Minimizar todos os grupos">− Recolher todos</button><button type="button" class="v-todos" data-t="+" title="Abrir todos os grupos">+ Expandir todos</button>' +
      '<span class="v-esp"></span><button type="button" class="v-whats" title="Copia os códigos de todas as remessas da tela, um por linha">📋 Copiar códigos</button><span class="v-msg"></span>';
    barra.querySelectorAll('[data-a]').forEach(b => {
      b.classList.toggle('on', b.dataset.a === ag());
      b.addEventListener('click', () => {
        if (ORIG) { agruparOrigem = b.dataset.a; try { localStorage.setItem(CHAVE_AGRUPAR + '_origem', agruparOrigem); } catch (e) { /* ok */ } }
        else { agrupar = b.dataset.a; try { localStorage.setItem(CHAVE_AGRUPAR, agrupar); } catch (e) { /* ok */ } }
        desenharVencimentos();
      });
    });
    barra.querySelector('.v-whats').addEventListener('click', async () => {
      const n = vencHoje.length;
      barra.querySelector('.v-msg').textContent = await copiar(vencHoje.map(d => d.codigo).join('\n')) ? `${n} código(s) copiados.` : 'Não consegui copiar.';
    });
    barra.querySelectorAll('.v-todos').forEach(b => b.addEventListener('click', () => area.querySelectorAll('.v-grupo').forEach(g => g._alternar(b.dataset.t === '-'))));
    area.appendChild(barra);

    if (!vencHoje.length) {
      const p = document.createElement('p'); p.className = 'v-vazio';
      p.textContent = `Nenhuma remessa pendente com previsão para ${diaTxt() === 'hoje' ? 'hoje' : DIA.toLocaleDateString('pt-BR')}. 🎉`;
      area.appendChild(p);
      return;
    }

    gruposVencimento().forEach(([nome, lista]) => {
      const sec = document.createElement('section'); sec.className = 'v-grupo';
      const idGrupo = ag() + '\u0001' + nome;
      sec.dataset.g = idGrupo;
      if (recolhidos.has(idGrupo)) sec.classList.add('fechado');
      const topo = document.createElement('div'); topo.className = 'v-topo';
      const sinal = document.createElement('button'); sinal.type = 'button'; sinal.className = 'v-sinal';
      const atualizarSinal = () => { const f = sec.classList.contains('fechado'); sinal.textContent = f ? '+' : '−'; sinal.title = f ? 'Expandir o grupo' : 'Minimizar o grupo'; };
      atualizarSinal();
      const alternar = () => { sec.classList.toggle('fechado'); if (sec.classList.contains('fechado')) recolhidos.add(idGrupo); else recolhidos.delete(idGrupo); atualizarSinal(); };
      sec._alternar = (fechar) => { if (sec.classList.contains('fechado') !== fechar) alternar(); };
      sinal.addEventListener('click', alternar);
      topo.addEventListener('click', ev => { if (ev.target === topo || ev.target.closest('.v-titulo, .v-qtd')) alternar(); });
      const titulo = document.createElement('span'); titulo.className = 'v-titulo';
      titulo.textContent = (ag() === 'circuit' && nome !== '(sem circuit)' ? 'Circuit ' : '') + nome;
      const qtd = document.createElement('span'); qtd.className = 'v-qtd'; qtd.textContent = lista.length;
      const pesq = document.createElement('button'); pesq.type = 'button'; pesq.textContent = '🔍 Pesquisar'; pesq.title = 'Abre a Consulta com estas remessas';
      pesq.addEventListener('click', () => pesquisarLote(lista));
      const cop = document.createElement('button'); cop.type = 'button'; cop.textContent = '📋 Copiar códigos';
      cop.addEventListener('click', async () => { cop.textContent = await copiar(lista.map(d => d.codigo).join('\n')) ? '✔ Copiado' : '✖ Não copiou'; setTimeout(() => { cop.textContent = '📋 Copiar códigos'; }, 1500); });
      topo.append(sinal, titulo, qtd, pesq, cop);
      const t = document.createElement('table'); t.className = 'v-tab';
      t.innerHTML = `<colgroup><col class="k-rem">${ag() === 'status' ? '<col class="k-circ">' : ''}<col class="k-st"><col class="k-rota"><col class="k-bairro"><col class="k-dias"><col class="k-trat"></colgroup><thead><tr><th>Remessa</th>${ag() === 'status' ? (ORIG ? '<th>Unidade Atual</th>' : '<th>Circuit</th>') : ''}<th>Status</th><th>Rota</th><th>Bairro / Cidade</th><th>Parado há</th><th>Tratativa</th></tr></thead>`;
      const corpo = t.createTBody();
      lista.forEach(d => {
        const tr = corpo.insertRow();
        const a = document.createElement('a');
        a.href = origem + '/FractionWeb/jad/tracking?cte=' + encodeURIComponent(d.codigo);
        a.target = '_blank'; a.rel = 'noopener'; a.textContent = d.codigo;
        tr.insertCell().appendChild(a);
        if (ag() === 'status') tr.insertCell().textContent = ORIG ? pontoDe(d) : circuitDe(d);
        const c2 = tr.insertCell();
        c2.textContent = onde(d);
        c2.className = 'v-st v-st-' + (fora(d) ? 'fora' : d.status.replace(/\W+/g, '-').toLowerCase());
        tr.insertCell().textContent = d.rota;
        tr.insertCell().textContent = [d.bairro, d.cidade].filter(Boolean).join(' - ');
        tr.insertCell().textContent = d.dias == null ? '' : d.dias === 0 ? 'hoje' : d.dias + ' dia(s)';
        const ct = tr.insertCell(); ct.className = 'v-trat'; ct.textContent = d.tratativa; if (d.tratativa) ct.title = d.tratativa;
      });
      sec.append(topo, t);
      area.appendChild(sec);
    });
  }

  /** Copia texto; dentro do painel (iframe) usa o método antigo se a área de transferência for negada. */
  async function copiar(txt) {
    try { await navigator.clipboard.writeText(txt); return true; } catch (e) { /* tenta o outro jeito */ }
    const ta = document.createElement('textarea');
    ta.value = txt; ta.setAttribute('readonly', ''); ta.style.cssText = 'position:fixed;left:-9999px;top:0';
    document.body.appendChild(ta); ta.select();
    let ok = false; try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
    ta.remove();
    return ok;
  }

  async function pesquisarLote(lista) {
    const codigos = [...new Set(lista.map(d => d.codigo))].slice(0, LIMITE_PESQUISA);
    await chrome.storage.local.set({ tf_pesq_lote: { v: codigos, t: Date.now() } });
    chrome.tabs.create({ url: origem + '/FractionWeb/jad/consulta' });
  }


  /* ---------- Remessas faltantes da conferência de manifesto ---------- */

  async function faltantes(msg) {
    try {
      document.querySelectorAll('p.resumo-topo').forEach(p => p.remove());
      carregando('Lendo o relatório de inconsistências…');
      // CSV: CONHECIMENTO,VOLUME,MANIFESTO — "VOLUME AUSENTE NO MANIFESTO" (sobra) é ignorado.
      const txt = new TextDecoder('latin1').decode(msg.csv.buffer);
      const mapa = new Map();
      txt.split(/\r?\n/).slice(1).forEach(l => {
        const [cod, vol, man] = l.split(/[;,]/).map(x => (x || '').trim());
        if (!/^\d{6,}$/.test(cod || '') || !man || /AUSENTE/i.test(man)) return;
        const [n, total] = (vol || '').split('/').map(x => parseInt(x, 10));
        let r = mapa.get(cod);
        if (!r) mapa.set(cod, r = { codigo: cod, faltam: 0, total: total || 0, volumes: [], manifestos: new Set() });
        r.faltam++; if (n) r.volumes.push(n); if (total) r.total = total; r.manifestos.add(man);
      });
      const lista = [...mapa.values()];
      // Circuit, peso e bairro/cidade: arquivo da Performance guardado pelo Painel de Pendências.
      let infoPerf = null;
      if (msg.perf && msg.perf.buffer) {
        carregando('Cruzando com o arquivo da Performance (Circuit, peso, bairro)…');
        try {
          const { cabecalho, linhas } = await TFXlsx.lerArquivo(new File([msg.perf.buffer], msg.perf.nome || 'Performance.zip'), t => carregando(t));
          const col = n => cabecalho.findIndex(h => h.toLowerCase() === n.toLowerCase());
          const c = { cod: col('Codigo'), circuit: col('Circuit'), peso: col('Peso'), bairro: col('Bairro'), cidade: col('Cidade'), rota: col('Rota'), nf: col('Nota Fiscal') };
          const pm = new Map();
          linhas.forEach(l => { const k = String(l[c.cod] || '').trim(); if (k) pm.set(k, l); });
          let achadas = 0;
          lista.forEach(r => {
            const l = pm.get(r.codigo); if (!l) return;
            achadas++;
            const v = i => (i >= 0 && l[i] != null ? String(l[i]).trim() : '');
            r.circuit = v(c.circuit); r.peso = parseFloat(v(c.peso).replace(',', '.')) || 0;
            r.bairro = v(c.bairro); r.cidade = v(c.cidade); r.rota = v(c.rota);
            // Sem NF (o Fraction mostra 0 ou DECLARACAO): não há o que consultar na Receita.
            if (c.nf >= 0) r.semNf = !/[1-9]/.test(v(c.nf)) || /DECLARA/i.test(v(c.nf));
          });
          infoPerf = { quando: msg.perf.quando, achadas };
        } catch (e) { console.warn('Performance', e); }
      }
      carregando(null);
      desenharFaltantes(lista, msg, infoPerf);
    } catch (e) {
      console.error(e);
      carregando(null);
      const p = document.createElement('p'); p.className = 'resumo-topo'; p.textContent = 'Erro: ' + e.message; $('area').before(p);
    }
  }

  function desenharFaltantes(lista, msg, infoPerf) {
    const area = $('area');
    area.innerHTML = '';
    const vols = lista.reduce((s, r) => s + r.faltam, 0);
    $('fonte').textContent = `${lista.length} remessa(s) · ${vols} volume(s) faltando`;
    const num = k => { const n = parseInt(k, 10); return isNaN(n) ? Infinity : n; };
    const circ = r => { const c = (r.circuit || '').trim(); return /^\d+$/.test(c) ? String(+c) : c; };

    const barra = document.createElement('div');
    barra.className = 'v-barra';
    barra.innerHTML = '<button type="button" class="f-pdf">⬇ Salvar PDF original</button><button type="button" class="v-todos" data-t="-">− Recolher todos</button><button type="button" class="v-todos" data-t="+">+ Expandir todos</button><span class="v-esp"></span><button type="button" class="f-copiar">📋 Copiar códigos</button><span class="v-msg"></span>';
    const pdfBtn = barra.querySelector('.f-pdf');
    if (msg.pdf && msg.pdf.buffer) {
      const url = URL.createObjectURL(new Blob([msg.pdf.buffer], { type: 'application/pdf' }));
      pdfBtn.addEventListener('click', () => { const a = document.createElement('a'); a.href = url; a.download = msg.pdf.nome || 'InconsistenciaManifesto.pdf'; document.body.appendChild(a); a.click(); a.remove(); });
    } else { pdfBtn.disabled = true; pdfBtn.title = 'O Fraction não devolveu o PDF' + (msg.pdfErro ? ': ' + msg.pdfErro : ''); }
    barra.querySelector('.f-copiar').addEventListener('click', async () => { barra.querySelector('.v-msg').textContent = await copiar(lista.map(r => r.codigo).join('\n')) ? `${lista.length} código(s) copiados.` : 'Não consegui copiar.'; });
    barra.querySelectorAll('.v-todos').forEach(b => b.addEventListener('click', () => area.querySelectorAll('.v-grupo').forEach(g => g.classList.toggle('fechado', b.dataset.t === '-'))));
    area.appendChild(barra);

    const nota = document.createElement('p'); nota.className = 'f-nota';
    if (infoPerf) {
      const q = new Date(infoPerf.quando);
      nota.textContent = `Circuit, peso e bairro vêm do arquivo da Performance de ${q.toLocaleDateString('pt-BR')} às ${q.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })} (${infoPerf.achadas} de ${lista.length} remessas encontradas).`;
    } else {
      nota.textContent = 'Para ver Circuit, peso e bairro, gere antes o 📊 Painel de Pendências na Performance de Entrega (o arquivo fica guardado e é usado aqui).';
      nota.classList.add('f-aviso');
    }
    area.appendChild(nota);

    if (!lista.length) { const p = document.createElement('p'); p.className = 'v-vazio'; p.textContent = 'Nenhuma remessa faltante. 🎉'; area.appendChild(p); return; }

    const grupos = new Map();
    lista.forEach(r => { const k = circ(r) || '(sem circuit)'; if (!grupos.has(k)) grupos.set(k, []); grupos.get(k).push(r); });
    [...grupos.entries()].sort((a, b) => (a[0] === '(sem circuit)') - (b[0] === '(sem circuit)') || num(a[0]) - num(b[0]) || a[0].localeCompare(b[0], 'pt-BR')).forEach(([nome, itens]) => {
      itens.sort((a, b) => a.codigo.localeCompare(b.codigo));
      const sec = document.createElement('section'); sec.className = 'v-grupo';
      const topo = document.createElement('div'); topo.className = 'v-topo';
      const sinal = document.createElement('button'); sinal.type = 'button'; sinal.className = 'v-sinal'; sinal.textContent = '−';
      const alternar = () => { sec.classList.toggle('fechado'); sinal.textContent = sec.classList.contains('fechado') ? '+' : '−'; };
      sinal.addEventListener('click', alternar);
      topo.addEventListener('click', ev => { if (ev.target === topo || ev.target.closest('.v-titulo, .v-qtd')) alternar(); });
      const titulo = document.createElement('span'); titulo.className = 'v-titulo'; titulo.textContent = (nome !== '(sem circuit)' ? 'Circuit ' : '') + nome;
      const qtd = document.createElement('span'); qtd.className = 'v-qtd';
      const pesoG = itens.reduce((s, r) => s + (r.peso || 0), 0);
      qtd.textContent = itens.length;
      const resumo = document.createElement('span'); resumo.className = 'f-resumo';
      resumo.textContent = `${itens.reduce((s, r) => s + r.faltam, 0)} vol.` + (pesoG ? ` · ${pesoG.toLocaleString('pt-BR', { maximumFractionDigits: 2 })} kg` : '');
      const pesq = document.createElement('button'); pesq.type = 'button'; pesq.textContent = '🔍 Pesquisar'; pesq.addEventListener('click', () => pesquisarLote(itens));
      const cop = document.createElement('button'); cop.type = 'button'; cop.textContent = '📋 Copiar códigos';
      cop.addEventListener('click', async () => { cop.textContent = await copiar(itens.map(r => r.codigo).join('\n')) ? '✔ Copiado' : '✖ Não copiou'; setTimeout(() => { cop.textContent = '📋 Copiar códigos'; }, 1500); });
      topo.append(sinal, titulo, qtd, resumo, pesq, cop);
      const t = document.createElement('table'); t.className = 'v-tab';
      t.innerHTML = '<colgroup><col style="width:130px"><col style="width:110px"><col style="width:80px"><col><col style="width:150px"><col style="width:90px"></colgroup><thead><tr><th>Remessa</th><th>Volumes faltando</th><th>Peso</th><th>Bairro / Cidade</th><th>Manifesto</th><th></th></tr></thead>';
      const corpo = t.createTBody();
      itens.forEach(r => {
        const tr = corpo.insertRow();
        const a = document.createElement('a'); a.href = origem + '/FractionWeb/jad/tracking?cte=' + r.codigo; a.target = '_blank'; a.rel = 'noopener'; a.textContent = r.codigo;
        tr.insertCell().appendChild(a);
        const cv = tr.insertCell();
        cv.textContent = r.total ? `${r.faltam} de ${r.total}` : String(r.faltam);
        if (r.total && r.faltam < r.total) cv.title = 'Volumes faltando: ' + r.volumes.sort((x, y) => x - y).map(n => String(n).padStart(3, '0')).join(', ');
        if (r.total && r.faltam === r.total) cv.className = 'f-todos';
        tr.insertCell().textContent = r.peso ? r.peso.toLocaleString('pt-BR', { maximumFractionDigits: 2 }) + ' kg' : '';
        tr.insertCell().textContent = [r.bairro, r.cidade].filter(Boolean).join(' - ');
        tr.insertCell().textContent = [...r.manifestos].join(', ');
        const cp = tr.insertCell();
        if (r.semNf) { cp.textContent = 'SEM NF-e'; cp.className = 'f-semnf'; return; }
        const prod = document.createElement('a'); prod.href = '#'; prod.className = 'f-produtos'; prod.textContent = 'Produtos';
        prod.title = 'Abre a NF-e desta remessa no site da Receita (a extensão pega a chave na consulta da remessa)';
        prod.addEventListener('click', async ev => {
          ev.preventDefault();
          await chrome.storage.local.set({ tf_produtos: { cte: r.codigo, t: Date.now() } });
          chrome.tabs.create({ url: origem + '/FractionWeb/jad/tracking?cte=' + r.codigo });
        });
        cp.appendChild(prod);
      });
      sec.append(topo, t);
      area.appendChild(sec);
    });
  }

  /* ---------- De quando são os dados + "Gerar de novo" ---------- */
  function mostrarOrigemDados(d) {
    const el = $('dados'); if (!el || !d.quando) return;
    const q = new Date(d.quando);
    const hora = q.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
    const dia = q.toDateString() === new Date().toDateString() ? 'hoje' : q.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
    el.querySelector('.d-txt').textContent = `${d.guardado ? 'Arquivo guardado' : 'Arquivo gerado'} ${dia} às ${hora}` + (d.proxima ? ` · próxima atualização do Fraction: ${d.proxima}` : '');
    el.title = d.guardado ? 'O Fraction ainda não atualizou os dados desde este arquivo, por isso ele foi reaproveitado sem gerar de novo.' : '';
    el.hidden = false;
  }
  if ($('regerar')) $('regerar').addEventListener('click', () => {
    $('dados').hidden = true;
    $('area').innerHTML = '';
    carregando('Gerando o arquivo no Fraction…');
    window.parent.postMessage({ tipo: 'tf-regerar' }, '*');
  });

  /* ---------- Origem (servidor do Fraction) e arquivo vindo da extensão ---------- */

  (async () => {
    try {
      const v = await chrome.storage.local.get('tf_origem');
      if (v.tf_origem) origem = v.tf_origem;
    } catch (e) { /* usa o padrão */ }
    // Aberto como painel dentro da tela Performance de Entrega: o arquivo chega por mensagem.
    if (MODO === 'painel' || MODO === 'vencimentos' || MODO === 'faltantes') {
      document.body.classList.add('modo-painel');
      if (MODO === 'vencimentos') { document.body.classList.add('modo-venc'); montarSeletorData(); document.title = 'Vencimentos do Dia — TurboFraction'; }
      if (MODO === 'faltantes') { document.body.classList.add('modo-venc'); document.querySelector('.topo h1').textContent = 'Remessas Faltantes — Conferência de Manifesto'; document.title = 'Remessas Faltantes — TurboFraction'; }
      carregando('Gerando o arquivo no Fraction…');
      window.addEventListener('message', ev => {
        let ok = false;
        try { ok = /(^|\.)jadlog\.com(\.br)?$/.test(new URL(ev.origin).hostname); } catch (e) { /* origem inválida */ }
        if (!ok || !ev.data || typeof ev.data !== 'object') return;
        if (ev.data.origem) { origem = ev.data.origem; try { chrome.storage.local.set({ tf_origem: origem }); } catch (e) { /* ok */ } }
        if (ev.data.tipo === 'tf-status') { estado(ev.data.texto); carregando(ev.data.erro ? null : ev.data.texto); if (ev.data.erro) { const p = document.createElement('p'); p.className = 'resumo-topo'; p.textContent = ev.data.texto; $('area').before(p); } }
        if (ev.data.tipo === 'tf-faltantes' && ev.data.csv) faltantes(ev.data);
        if (ev.data.tipo === 'tf-arquivo' && ev.data.buffer) {
          tipoArq = ev.data.tipoConsulta || '';
          document.querySelectorAll('p.resumo-topo').forEach(p => p.remove());
          carregar(new File([ev.data.buffer], ev.data.nome || 'Performance.zip')).then(() => mostrarOrigemDados(ev.data));
        }
      });
    }
  })();
})();
