// Janela do ícone: verifica na hora se há versão nova no GitHub.
(async () => {
  const $ = id => document.getElementById(id);
  // Páginas chrome:// não abrem por link comum: a extensão abre a aba (já no cartão da TurboFraction).
  $('abrirExt').addEventListener('click', ev => {
    ev.preventDefault();
    chrome.tabs.create({ url: 'chrome://extensions/?id=' + chrome.runtime.id });
  });
  const versao = chrome.runtime.getManifest().version;
  $('atual').textContent = 'versão ' + versao;
  // Reportar erro: conversa no WhatsApp com o responsável pela extensão.
  $('whats').href = 'https://web.whatsapp.com/send?phone=5524999487331&text=' + encodeURIComponent(`TurboFraction ${versao} — erro: `);
  // Links do popup abrem numa aba nova (o popup fecha sozinho).
  document.addEventListener('click', ev => {
    const a = ev.target.closest('a[target="_blank"]');
    if (!a || !a.href || a.href.endsWith('#')) return;
    ev.preventDefault();
    chrome.tabs.create({ url: a.href });
  });
  const mostrar = id => ['verificando', 'ok', 'nova', 'erro'].forEach(x => { $(x).hidden = x !== id; });
  try {
    const r = await chrome.runtime.sendMessage({ tipo: 'verificarAgora' });
    if (r && r.loja) { $('ok').querySelector('.msg').textContent = 'Atualizações automáticas pela Chrome Web Store.'; return mostrar('ok'); }
    if (!r || r.erro) return mostrar('erro');
    if (!r.nova) return mostrar('ok');
    $('versaoNova').textContent = r.nova.versao;
    $('baixar').href = r.nova.download;
    $('linkDownload').href = r.nova.download;
    $('linkDownload').textContent = r.nova.download;
    (r.nova.notas || []).forEach(n => { const li = document.createElement('li'); li.textContent = n; $('notas').appendChild(li); });
    mostrar('nova');
  } catch (e) {
    mostrar('erro');
  }
})();
