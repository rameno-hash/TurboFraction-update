/*
 * TurboFraction — Performance de Coleta (/FractionWeb/jad/performance_coleta)
 * Botão "📦 Coletas Pickup" ao lado do quadro de horários: gera a Performance de Coleta dos últimos
 * 30 dias (o mesmo "Processar" da tela), recebe o arquivo direto (sem ir para Downloads) e abre o
 * relatório "COLETAS PICKUP": remessas Pendente + "DEPOSITADO NO PUDO" contadas por PUDO, com o
 * motorista anotado na tela Consultas Pudo - Unidades Atendidas.
 */
(() => {
  'use strict';
  const FORM = 'formPerfColFiltro';
  const CAB_AJAX = {
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'Faces-Request': 'partial/ajax',
    'X-Requested-With': 'XMLHttpRequest',
  };
  const https = (u, base) => { const x = new URL(u, base || location.href); if (x.protocol === 'http:' && location.protocol === 'https:') x.protocol = 'https:'; return x.href; };
  const dma = d => `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}/${d.getFullYear()}`;
  const passos = [];   // diagnóstico do caminho seguido

  function campos(form) {
    const p = new URLSearchParams();
    form.querySelectorAll('input[name], select[name], textarea[name]').forEach(el => {
      if ((el.type === 'checkbox' || el.type === 'radio') && !el.checked) return;
      if (el.type === 'submit' || el.type === 'button' || el.type === 'image') return;
      p.append(el.name, el.value);
    });
    return p;
  }
  const ehArquivo = r => !/text\/html|xml|json/i.test(r.headers.get('content-type') || '');
  const nomeDe = (r, padrao) => (/filename="?([^";]+)/i.exec(r.headers.get('content-disposition') || '') || [])[1] || padrao;
  const cdata = (xml, re) => { const m = re.exec(xml); return m ? m[1] : null; };

  /** Link do total (commandLink com o botão oculto de download ao lado), como na Performance de Entrega. */
  function linkDoTotal(raiz) {
    const cands = [...raiz.querySelectorAll('a.ui-commandlink')].filter(a => a.parentElement && a.parentElement.querySelector('button[name]'));
    if (!cands.length) return null;
    const num = a => parseInt((a.textContent || '').replace(/\D/g, ''), 10) || 0;
    const comTotal = cands.filter(a => /total/i.test(a.closest('[id]')?.id || ''));
    const lista = comTotal.length ? comTotal : cands;
    return lista.reduce((m, a) => (num(a) > num(m) ? a : m), lista[0]);
  }

  /** Repete o clique no total e devolve o arquivo (dois passos: ajax e depois o envio do botão oculto). */
  async function baixarPeloTotal(doc, link, urlBase) {
    const form = link.closest('form') || doc.querySelector('form');
    const acao = https(form.getAttribute('action') || urlBase, urlBase);
    const botao = link.parentElement.querySelector('button[name]');
    passos.push('total: ' + (link.textContent || '').trim());
    const p1 = new URLSearchParams({ 'javax.faces.partial.ajax': 'true', 'javax.faces.source': link.id, 'javax.faces.partial.execute': '@all', 'javax.faces.partial.render': 'form_notificacao:mensagemTmp', [link.id]: link.id });
    campos(form).forEach((v, k) => p1.set(k, v));
    const r1 = await fetch(acao, { method: 'POST', credentials: 'same-origin', headers: CAB_AJAX, body: p1.toString() });
    const x1 = await r1.text();
    const vs = cdata(x1, /<update id="[^"]*javax\.faces\.ViewState[^"]*"><!\[CDATA\[([^\]]*)\]\]>/);
    const p2 = campos(form);
    if (vs) p2.set('javax.faces.ViewState', vs);
    p2.set(form.id, form.id);
    p2.set(botao.name, botao.value || '');
    const r2 = await fetch(acao, { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' }, body: p2.toString() });
    if (!ehArquivo(r2)) throw new Error('o clique no total respondeu com uma página em vez do arquivo');
    return { buffer: await r2.arrayBuffer(), nome: nomeDe(r2, 'Performance.zip') };
  }

  /** Abre uma página (redirecionamento do Fraction) e procura o arquivo ou o link do total nela. */
  async function seguirPagina(url) {
    passos.push('página: ' + url.replace(/^https?:\/\/[^/]+/, ''));
    const r = await fetch(https(url), { credentials: 'same-origin' });
    if (ehArquivo(r)) return { buffer: await r.arrayBuffer(), nome: nomeDe(r, 'Performance.zip') };
    const html = await r.text();
    const doc = new DOMParser().parseFromString(html, 'text/html');
    const link = linkDoTotal(doc);
    if (link) return baixarPeloTotal(doc, link, r.url);
    throw new Error('a página do resultado não tem o total para baixar o arquivo');
  }

  /** O mesmo "Processar" da tela, com o período dos últimos 30 dias. */
  async function gerarArquivo() {
    passos.length = 0;
    const form = document.getElementById(FORM);
    const btn = document.getElementById(FORM + ':id_botao_total');
    if (!form || !btn) throw new Error('não encontrei o formulário da Performance de Coleta');
    const acao = https(form.getAttribute('action') || location.href);
    const hoje = new Date(), ini = new Date(hoje.getFullYear(), hoje.getMonth(), hoje.getDate() - 30);
    const p = new URLSearchParams({ 'javax.faces.partial.ajax': 'true', 'javax.faces.source': btn.id, 'javax.faces.partial.execute': '@all', [btn.id]: btn.id });
    campos(form).forEach((v, k) => p.set(k, v));
    p.set(FORM + ':dtini_input', dma(ini));
    p.set(FORM + ':dtfim_input', dma(hoje));
    p.set(FORM, FORM);
    passos.push(`processar ${dma(ini)} a ${dma(hoje)}`);
    const r = await fetch(acao, { method: 'POST', credentials: 'same-origin', headers: CAB_AJAX, body: p.toString() });
    if (ehArquivo(r)) { passos.push('arquivo direto'); return { buffer: await r.arrayBuffer(), nome: nomeDe(r, 'Performance.zip') }; }
    const xml = await r.text();
    // Mensagem de erro do próprio Fraction (ex.: período inválido)
    const erro = cdata(xml, /<error-message>(?:<!\[CDATA\[)?([\s\S]*?)(?:\]\]>)?<\/error-message>/);
    if (erro) throw new Error('o Fraction respondeu: ' + erro);
    // 1) Redirecionamento para a página do resultado
    const red = /<redirect\s+url="([^"]+)"/.exec(xml);
    if (red) return seguirPagina(red[1].replace(/&amp;/g, '&'));
    // 2) Script que abre o arquivo (window.open / location)
    const ev = /(?:window\.open|location(?:\.href)?\s*=)\s*\(?\s*['"]([^'"]+)['"]/.exec(xml);
    if (ev) return seguirPagina(ev[1]);
    // 3) Atualização da própria tela com o total (resultado na mesma página)
    const frag = document.createElement('div');
    xml.replace(/<update id="([^"]+)"><!\[CDATA\[([\s\S]*?)\]\]><\/update>/g, (_, id, html) => { if (!/ViewState/.test(id)) frag.insertAdjacentHTML('beforeend', html); return ''; });
    const link = linkDoTotal(frag);
    if (link) {
      // O total aparece na própria página: usa o formulário dela (com o ViewState novo).
      const vs = cdata(xml, /<update id="[^"]*javax\.faces\.ViewState[^"]*"><!\[CDATA\[([^\]]*)\]\]>/);
      if (vs) document.querySelectorAll('input[name="javax.faces.ViewState"]').forEach(i => { i.value = vs; });
      passos.push('total na mesma página');
      const doc = document.implementation.createHTMLDocument('');
      const f = document.createElement('form'); f.id = (document.getElementById(link.id)?.closest('form') || form).id;
      f.setAttribute('action', acao);
      const formReal = document.getElementById(f.id) || form;
      formReal.querySelectorAll('input[name], select[name], textarea[name]').forEach(el => f.appendChild(el.cloneNode(true)));
      f.appendChild(link.parentElement.cloneNode(true));
      doc.body.appendChild(f);
      return baixarPeloTotal(doc, f.querySelector('a.ui-commandlink'), acao);
    }
    const msgs = (xml.match(/detail"?\s*:\s*"([^"]*)"/g) || []).map(m => m.replace(/^.*:\s*"/, '').replace(/"$/, ''));
    const amostra = xml.replace(/<!\[CDATA\[[\s\S]*?\]\]>/g, '[…]').replace(/\s+/g, ' ').slice(0, 400);
    throw new Error('não reconheci a resposta do Processar' + (msgs.length ? ' (mensagem: ' + msgs.join(' · ') + ')' : '') + ' — ' + amostra);
  }

  /* ---------- Painel ---------- */
  function abrirPainel() {
    document.getElementById('tf-painel')?.remove();
    const fundo = document.createElement('div');
    fundo.id = 'tf-painel';
    fundo.innerHTML = '<div class="tf-painel-caixa"><button type="button" class="tf-painel-fechar" title="Fechar (Esc)">✕</button><iframe class="tf-painel-quadro" allow="clipboard-write"></iframe></div>';
    const quadro = fundo.querySelector('iframe');
    quadro.src = chrome.runtime.getURL('coletas.html');
    const fechar = () => { fundo.remove(); document.removeEventListener('keydown', esc); };
    const esc = e => { if (e.key === 'Escape') fechar(); };
    fundo.querySelector('.tf-painel-fechar').addEventListener('click', fechar);
    document.addEventListener('keydown', esc);
    document.body.appendChild(fundo);
    quadro.addEventListener('load', () => { quadro.dataset.pronto = '1'; }, { once: true });
    return quadro;
  }
  function enviar(quadro, msg, transf) {
    const destino = new URL(chrome.runtime.getURL('')).origin;
    const mandar = () => quadro.contentWindow.postMessage(msg, destino, transf || []);
    if (quadro.dataset.pronto) mandar(); else quadro.addEventListener('load', () => { quadro.dataset.pronto = '1'; mandar(); }, { once: true });
  }

  /* ---------- Arquivo guardado até a próxima atualização do Fraction ---------- */
  const ATUALIZACOES = ['06:24', '08:24', '10:24', '12:24', '14:24', '15:24', '16:24', '19:24', '20:24', '23:24'];
  const CHAVE_CACHE = 'tf_cache_coletas';
  function ultimaAtualizacao(agora = new Date()) {
    for (let dia = 0; dia < 2; dia++) for (let i = ATUALIZACOES.length - 1; i >= 0; i--) {
      const [h, m] = ATUALIZACOES[i].split(':').map(Number);
      const t = new Date(agora.getFullYear(), agora.getMonth(), agora.getDate() - dia, h, m);
      if (t <= agora) return t;
    }
    return new Date(0);
  }
  const proxima = () => { const i = ATUALIZACOES.indexOf(ultimaAtualizacao().toTimeString().slice(0, 5)); return ATUALIZACOES[(i + 1) % ATUALIZACOES.length].replace(':', 'h'); };
  const paraBase64 = buf => { const u8 = new Uint8Array(buf); let s = ''; for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000)); return btoa(s); };
  const deBase64 = b64 => { const s = atob(b64), u8 = new Uint8Array(s.length); for (let i = 0; i < s.length; i++) u8[i] = s.charCodeAt(i); return u8.buffer; };
  async function lerGuardado() {
    try {
      const c = (await chrome.storage.local.get(CHAVE_CACHE))[CHAVE_CACHE];
      if (c && c.b64 && c.host === location.host && c.quando >= ultimaAtualizacao().getTime()) return { buffer: deBase64(c.b64), nome: c.nome, quando: c.quando };
    } catch (e) { /* ilegível: gera de novo */ }
    return null;
  }
  async function guardar(buffer, nome, quando) {
    try { await chrome.storage.local.set({ [CHAVE_CACHE]: { host: location.host, quando, nome, b64: paraBase64(buffer) } }); } catch (e) { console.warn('[TurboFraction] não consegui guardar o arquivo', e); }
  }

  async function gerar(btn, forcar) {
    const quadro = abrirPainel();
    btn.disabled = true;
    try {
      const g = !forcar && await lerGuardado();
      if (g) { enviar(quadro, { tipo: 'tf-coletas', buffer: g.buffer, nome: g.nome, quando: g.quando, guardado: true, proxima: proxima() }, [g.buffer]); return; }
      enviar(quadro, { tipo: 'tf-status', texto: 'Gerando a Performance de Coleta dos últimos 30 dias no Fraction… isso pode levar alguns segundos.' });
      const arq = await gerarArquivo();
      const quando = Date.now();
      const copia = arq.buffer.slice(0);
      await guardar(copia, arq.nome, quando);
      enviar(quadro, { tipo: 'tf-coletas', buffer: arq.buffer, nome: arq.nome, quando, guardado: false, proxima: proxima() }, [arq.buffer]);
    } catch (e) {
      console.warn('[TurboFraction] Coletas Pickup', e, passos);
      enviar(quadro, { tipo: 'tf-status', erro: true, texto: 'Não consegui gerar o arquivo: ' + e.message, diag: passos.join(' → ') });
    } finally { btn.disabled = false; }
  }

  // "Gerar de novo" dentro do painel
  window.addEventListener('message', ev => {
    const quadro = document.querySelector('#tf-painel iframe');
    if (!quadro || ev.source !== quadro.contentWindow || !ev.data || ev.data.tipo !== 'tf-regerar') return;
    const btn = document.getElementById('tf-coletas');
    if (btn && !btn.disabled) gerar(btn, true);
  });

  function colocarBotao() {
    if (document.getElementById('tf-coletas')) return;
    const quadro = [...document.querySelectorAll('fieldset')].find(f => /^\s*Hor/i.test(f.querySelector('legend')?.textContent || '') && /\d{2}h\d{2}/.test(f.textContent));
    if (!quadro) return;
    const btn = document.createElement('button');
    btn.id = 'tf-coletas'; btn.type = 'button'; btn.className = 'tf-pend-botao';
    btn.textContent = '📦 Coletas Pickup';
    btn.title = 'Mostra (gera a Performance de Coleta dos últimos 30 dias só depois de cada atualização do Fraction) as coletas "Depositado no PUDO" por PUDO, com o motorista de cada um';
    btn.addEventListener('click', () => gerar(btn));
    const caixa = document.createElement('div'); caixa.className = 'tf-coletas-lugar';
    caixa.appendChild(btn);
    const conteudo = quadro.querySelector('.ui-fieldset-content') || quadro;
    conteudo.classList.add('tf-coletas-ao-lado');
    conteudo.appendChild(caixa);
  }

  colocarBotao();
  let ag = 0;
  new MutationObserver(() => { if (!ag) ag = requestAnimationFrame(() => { ag = 0; colocarBotao(); }); })
    .observe(document.body, { childList: true, subtree: true });
})();
