/*
 * TurboFraction — Performance de Coleta (/FractionWeb/jad/performance_coleta)
 * Botão "📦 Coletas Pickup" ao lado do quadro de horários: gera a Performance de Coleta dos últimos
 * 30 dias (o mesmo "Processar" da tela), recebe o arquivo direto (sem ir para Downloads) e abre o
 * relatório "COLETAS PICKUP": remessas Pendente + "DEPOSITADO NO PUDO" contadas por PUDO, com o
 * motorista anotado na tela Consultas Pudo - Unidades Atendidas.
 */
(() => {
  'use strict';
  const FORM = 'formPerfColFiltro';
  const CAB_AJAX = {
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'Faces-Request': 'partial/ajax',
    'X-Requested-With': 'XMLHttpRequest',
  };
  const https = (u, base) => { const x = new URL(u, base || location.href); if (x.protocol === 'http:' && location.protocol === 'https:') x.protocol = 'https:'; return x.href; };
  const dma = d => `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}/${d.getFullYear()}`;
  const passos = [];   // diagnóstico do caminho seguido

  function campos(form) {
    const p = new URLSearchParams();
    form.querySelectorAll('input[name], select[name], textarea[name]').forEach(el => {
      if ((el.type === 'checkbox' || el.type === 'radio') && !el.checked) return;
      if (el.type === 'submit' || el.type === 'button' || el.type === 'image') return;
      p.append(el.name, el.value);
    });
    return p;
  }
  const ehArquivo = r => !/text\/html|xml|json/i.test(r.headers.get('content-type') || '');
  const nomeDe = (r, padrao) => (/filename="?([^";]+)/i.exec(r.headers.get('content-disposition') || '') || [])[1] || padrao;
  const cdata = (xml, re) => { const m = re.exec(xml); return m ? m[1] : null; };

  /* ---------- Painel ---------- */
  function abrirPainel(pagina) {
    document.getElementById('tf-painel')?.remove();
    const fundo = document.createElement('div');
    fundo.id = 'tf-painel';
    fundo.innerHTML = '<div class="tf-painel-caixa"><button type="button" class="tf-painel-fechar" title="Fechar (Esc)">✕</button><iframe class="tf-painel-quadro" allow="clipboard-write"></iframe></div>';
    const quadro = fundo.querySelector('iframe');
    quadro.src = chrome.runtime.getURL(pagina);
    quadro.dataset.pagina = pagina;
    const fechar = () => { fundo.remove(); document.removeEventListener('keydown', esc); };
    const esc = e => { if (e.key === 'Escape') fechar(); };
    fundo.querySelector('.tf-painel-fechar').addEventListener('click', fechar);
    document.addEventListener('keydown', esc);
    document.body.appendChild(fundo);
    quadro.addEventListener('load', () => { quadro.dataset.pronto = '1'; }, { once: true });
    return quadro;
  }
  function enviar(quadro, msg, transf) {
    const destino = new URL(chrome.runtime.getURL('')).origin;
    const mandar = () => quadro.contentWindow.postMessage(msg, destino, transf || []);
    if (quadro.dataset.pronto) mandar(); else quadro.addEventListener('load', () => { quadro.dataset.pronto = '1'; mandar(); }, { once: true });
  }

  /* ---------- Arquivo guardado até a próxima atualização do Fraction ---------- */
  const ATUALIZACOES = ['06:24', '08:24', '10:24', '12:24', '14:24', '15:24', '16:24', '19:24', '20:24', '23:24'];
  const CHAVE_CACHE = 'tf_cache_coletas';
  function ultimaAtualizacao(agora = new Date()) {
    for (let dia = 0; dia < 2; dia++) for (let i = ATUALIZACOES.length - 1; i >= 0; i--) {
      const [h, m] = ATUALIZACOES[i].split(':').map(Number);
      const t = new Date(agora.getFullYear(), agora.getMonth(), agora.getDate() - dia, h, m);
      if (t <= agora) return t;
    }
    return new Date(0);
  }
  const proxima = () => { const i = ATUALIZACOES.indexOf(ultimaAtualizacao().toTimeString().slice(0, 5)); return ATUALIZACOES[(i + 1) % ATUALIZACOES.length].replace(':', 'h'); };
  const paraBase64 = buf => { const u8 = new Uint8Array(buf); let s = ''; for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000)); return btoa(s); };
  const deBase64 = b64 => { const s = atob(b64), u8 = new Uint8Array(s.length); for (let i = 0; i < s.length; i++) u8[i] = s.charCodeAt(i); return u8.buffer; };
  let chaveAtual = '';   // filtro + período do arquivo pedido (outro período = outro arquivo)
  async function lerGuardado() {
    try {
      const c = (await chrome.storage.local.get(CHAVE_CACHE))[CHAVE_CACHE];
      if (c && c.b64 && c.host === location.host && c.chave === chaveAtual && c.quando >= ultimaAtualizacao().getTime()) return { buffer: deBase64(c.b64), nome: c.nome, quando: c.quando };
    } catch (e) { /* ilegível: gera de novo */ }
    return null;
  }
  async function guardar(buffer, nome, quando) {
    try { await chrome.storage.local.set({ [CHAVE_CACHE]: { host: location.host, chave: chaveAtual, quando, nome, b64: paraBase64(buffer) } }); } catch (e) { console.warn('[TurboFraction] não consegui guardar o arquivo', e); }
  }

  async function gerar(btn, forcar, pagina = 'coletas.html') {
    const quadro = abrirPainel(pagina);
    document.querySelectorAll('#tf-coletas, #tf-dash-coleta').forEach(b => { b.disabled = true; });
    btn.disabled = true;
    try {
      // Período: o que estiver nos campos Data Inicial/Final; vazio = últimos 30 dias.
      const f = TFPerfGerar.filtroDaTela();
      if (!f) throw new Error('não encontrei o formulário da Performance de Coleta');
      const per = TFPerfGerar.periodo(f);
      const perTxt = per.escolhido ? `${per.ini} a ${per.fim}` : `últimos 30 dias (${per.ini} a ${per.fim})`;
      chaveAtual = TFPerfGerar.chaveFiltro(f, per);
      const g = !forcar && await lerGuardado();
      if (g) { enviar(quadro, { tipo: 'tf-coletas', buffer: g.buffer, nome: g.nome, quando: g.quando, guardado: true, proxima: proxima(), periodo: perTxt }, [g.buffer]); return; }
      enviar(quadro, { tipo: 'tf-status', texto: `Gerando a Performance de Coleta de ${perTxt} no Fraction… isso pode levar alguns segundos.` });
      passos.length = 0;
      const arq = await TFPerfGerar.gerar(f, per, passos);
      const quando = Date.now();
      const copia = arq.buffer.slice(0);
      await guardar(copia, arq.nome, quando);
      enviar(quadro, { tipo: 'tf-coletas', buffer: arq.buffer, nome: arq.nome, quando, guardado: false, proxima: proxima(), periodo: perTxt }, [arq.buffer]);
    } catch (e) {
      console.warn('[TurboFraction] Coletas Pickup', e, passos);
      enviar(quadro, { tipo: 'tf-status', erro: true, texto: 'Não consegui gerar o arquivo: ' + e.message, diag: passos.join(' → ') });
    } finally { document.querySelectorAll('#tf-coletas, #tf-dash-coleta').forEach(b => { b.disabled = false; }); }
  }

  // "Gerar de novo" dentro do painel
  window.addEventListener('message', ev => {
    const quadro = document.querySelector('#tf-painel iframe');
    if (!quadro || ev.source !== quadro.contentWindow || !ev.data || ev.data.tipo !== 'tf-regerar') return;
    const btn = document.getElementById('tf-coletas');
    if (btn && !btn.disabled) gerar(btn, true, quadro.dataset.pagina || 'coletas.html');
  });

  function colocarBotao() {
    if (document.getElementById('tf-coletas')) return;
    const quadro = [...document.querySelectorAll('fieldset')].find(f => /^\s*Hor/i.test(f.querySelector('legend')?.textContent || '') && /\d{2}h\d{2}/.test(f.textContent));
    if (!quadro) return;
    const btn = document.createElement('button');
    btn.id = 'tf-coletas'; btn.type = 'button'; btn.className = 'tf-pend-botao';
    btn.textContent = '📦 Coletas Pickup';
    btn.title = 'Coletas "Depositado no PUDO" por PUDO, com o motorista de cada um. Período: Data Inicial/Final da tela; vazio = últimos 30 dias';
    btn.addEventListener('click', () => gerar(btn));
    const dash = document.createElement('button');
    dash.id = 'tf-dash-coleta'; dash.type = 'button'; dash.className = 'tf-pend-botao';
    dash.textContent = '📊 Dashboard';
    dash.title = 'Coletas pendentes por local × dias desde o último evento. Período: Data Inicial/Final da tela; vazio = últimos 30 dias';
    dash.addEventListener('click', () => gerar(dash, false, 'dash-coleta.html'));
    const caixa = document.createElement('div'); caixa.className = 'tf-coletas-lugar';
    caixa.append(dash, btn);
    const conteudo = quadro.querySelector('.ui-fieldset-content') || quadro;
    conteudo.classList.add('tf-coletas-ao-lado');
    conteudo.appendChild(caixa);
  }

  colocarBotao();
  let ag = 0;
  new MutationObserver(() => { if (!ag) ag = requestAnimationFrame(() => { ag = 0; colocarBotao(); }); })
    .observe(document.body, { childList: true, subtree: true });
})();
