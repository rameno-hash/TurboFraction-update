/*
 * TurboFraction — Consulta Geral (/FractionWeb/jad/consulta)
 * Vindo do link no CPF/CNPJ do remetente: preenche "CNPJ Cliente", põe o período
 * dos últimos 30 dias e clica em Processar (lista tudo o que o remetente embarcou).
 */
(() => {
  'use strict';
  let pedido = null;
  try {
    pedido = JSON.parse(localStorage.getItem('tf_cons_cnpj') || 'null');
    if (pedido) localStorage.removeItem('tf_cons_cnpj');
  } catch (e) { return; }
  if (!pedido || !pedido.v || Date.now() - pedido.t > 60000) return;

  const dma = d => [d.getDate(), d.getMonth() + 1, d.getFullYear()].map((n, i) => String(n).padStart(i < 2 ? 2 : 4, '0')).join('/');
  const hoje = new Date();
  const inicio = new Date(hoje); inicio.setDate(hoje.getDate() - 30);

  function definir(el, v) {
    const d = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(el), 'value');
    if (d && d.set) d.set.call(el, v); else el.value = v;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new Event('blur', { bubbles: true }));
  }

  let n = 0;
  const t = setInterval(() => {
    const cnpj = document.getElementById('frmConsulta:cnpjCliente');
    const ini = document.getElementById('frmConsulta:dtini_input');
    const fim = document.getElementById('frmConsulta:dtfim_input');
    const botao = document.getElementById('frmConsulta:id_enviar');
    if (!cnpj || !ini || !fim || !botao) { if (++n > 40) clearInterval(t); return; }
    clearInterval(t);
    const cte = document.getElementById('frmConsulta:cte');
    if (cte) definir(cte, '');
    definir(ini, dma(inicio));
    definir(fim, dma(hoje));
    definir(cnpj, pedido.v);
    // Fecha o calendário, se ele tiver aberto ao mexer nas datas.
    document.getElementById('ui-datepicker-div')?.style.setProperty('display', 'none');
    setTimeout(() => botao.click(), 400);
  }, 250);
})();

/*
 * Pesquisa em lote vinda do Relatório de Pendências (botão "Pesquisar na Consulta"):
 * cola todas as remessas no campo CTE e clica em Processar.
 */
(() => {
  'use strict';
  if (!chrome?.storage?.local) return;
  chrome.storage.local.get('tf_pesq_lote').then(v => {
    const p = v.tf_pesq_lote;
    if (!p || !Array.isArray(p.v) || !p.v.length || Date.now() - p.t > 120000) return;
    chrome.storage.local.remove('tf_pesq_lote');
    let n = 0;
    const t = setInterval(() => {
      const cte = document.getElementById('frmConsulta:cte');
      const botao = document.getElementById('frmConsulta:id_enviar');
      if (!cte || !botao) { if (++n > 40) clearInterval(t); return; }
      clearInterval(t);
      const d = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(cte), 'value');
      if (d && d.set) d.set.call(cte, p.v.join('\n')); else cte.value = p.v.join('\n');
      cte.dispatchEvent(new Event('input', { bubbles: true }));
      cte.dispatchEvent(new Event('change', { bubbles: true }));
      setTimeout(() => botao.click(), 400);
    }, 250);
  }).catch(() => {});
})();

/*
 * Nota Fiscal vinda da Entrada On Time (código lido no formato de chave de NF-e):
 * preenche "Nota Fiscal", põe o período dos últimos 30 dias e clica em Processar.
 */
(() => {
  'use strict';
  let pedido = null;
  try {
    pedido = JSON.parse(localStorage.getItem('tf_cons_nf') || 'null');
    if (pedido) localStorage.removeItem('tf_cons_nf');
  } catch (e) { return; }
  if (!pedido || !pedido.v || Date.now() - pedido.t > 60000) return;
  const dma = d => [d.getDate(), d.getMonth() + 1, d.getFullYear()].map((n, i) => String(n).padStart(i < 2 ? 2 : 4, '0')).join('/');
  const hoje = new Date();
  const inicio = new Date(hoje); inicio.setDate(hoje.getDate() - 30);
  function definir(el, v) {
    const d = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(el), 'value');
    if (d && d.set) d.set.call(el, v); else el.value = v;
    ['input', 'change', 'blur'].forEach(t => el.dispatchEvent(new Event(t, { bubbles: true })));
  }
  let n = 0;
  const t = setInterval(() => {
    const nf = document.getElementById('frmConsulta:notafiscal');
    const ini = document.getElementById('frmConsulta:dtini_input');
    const fim = document.getElementById('frmConsulta:dtfim_input');
    const botao = document.getElementById('frmConsulta:id_enviar');
    if (!nf || !ini || !fim || !botao) { if (++n > 40) clearInterval(t); return; }
    clearInterval(t);
    const cte = document.getElementById('frmConsulta:cte');
    if (cte) definir(cte, '');
    definir(ini, dma(inicio));
    definir(fim, dma(hoje));
    definir(nf, pedido.v);
    document.getElementById('ui-datepicker-div')?.style.setProperty('display', 'none');
    setTimeout(() => botao.click(), 400);
  }, 250);
})();
