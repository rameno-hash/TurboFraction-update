/*
 * TurboFraction — Portais da NF-e e do CT-e (consulta resumida)
 * 1) Preenche a chave de acesso vinda dos links "NF-e ↗", "CT-e ↗" e do botão "Consultar NF-e" da Emissão.
 *    O captcha é sempre do usuário.
 * 2) Na página de resultado da NF-e, se a consulta foi pedida pela Emissão do Fraction, lê os dados
 *    (número, série, valor, emitente, destinatário, volumes) e devolve para a Emissão.
 */
(() => {
  'use strict';
  const PEDIDO = 'tf_nfe_pedido', RESULTADO = 'tf_nfe_resultado';

  // ---------- 1) preencher a chave ----------
  const m = /tf_chave=([0-9A-Za-z]{44})/.exec(location.hash);
  if (m) {
    const chave = m[1];
    let n = 0;
    const t = setInterval(() => {
      const campo = document.getElementById('ctl00_ContentPlaceHolder1_txtChaveAcessoResumo');
      if (campo) {
        if (campo.value !== chave) {
          campo.value = chave;
          campo.dispatchEvent(new Event('input', { bubbles: true }));
          campo.dispatchEvent(new Event('change', { bubbles: true }));
        }
        clearInterval(t);
      } else if (++n > 40) {
        clearInterval(t);
      }
    }, 300);
  }

  // ---------- 2) ler o resultado ----------
  if (!/nfe\.fazenda\.gov\.br/.test(location.host)) return;
  const norm = s => String(s || '').replace(/ /g, ' ').normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/\s+/g, ' ').trim().toLowerCase();
  const limpa = s => String(s || '').replace(/ /g, ' ').replace(/\s+/g, ' ').trim();

  /** Valor do campo cujo <label> é `rotulo` dentro de `caixa` (estrutura <td><label>X</label><span>valor</span></td>). */
  function campo(caixa, ...rotulos) {
    if (!caixa) return '';
    const alvo = rotulos.map(norm);
    for (const l of caixa.querySelectorAll('label')) {
      if (!alvo.includes(norm(l.textContent))) continue;
      const s = l.nextElementSibling;
      if (s && s.tagName === 'SPAN') return limpa(s.textContent);
    }
    return '';
  }
  const numero = s => { const v = parseFloat(String(s || '').replace(/\./g, '').replace(',', '.')); return isNaN(v) ? null : v; };
  const semCodigo = s => limpa(s).replace(/^\d+\s*-\s*/, '');

  /** "RUA X, , 438438" / "RUA Y, , 11850, BLOCO B311850 BLOCO B3" -> { logradouro, numero, complemento } */
  function endereco(txt) {
    const t = limpa(txt);
    const i = t.indexOf(',');
    if (i < 0) return { logradouro: t, numero: '', complemento: '' };
    const logradouro = t.slice(0, i).trim();
    const resto = t.slice(i + 1).replace(/^\s*,\s*/, '').trim();
    let nro = resto, compl = '';
    const v = resto.indexOf(', ');
    if (v >= 0) {
      nro = resto.slice(0, v).trim();
      const cauda = resto.slice(v + 2);
      const r = nro ? cauda.lastIndexOf(nro) : -1;
      compl = (r > 0 ? cauda.slice(0, r) : cauda).trim();
    } else if (resto.length % 2 === 0 && resto.slice(0, resto.length / 2) === resto.slice(resto.length / 2)) {
      nro = resto.slice(0, resto.length / 2);
    }
    return { logradouro, numero: nro.trim(), complemento: compl };
  }

  function pessoa(caixa) {
    if (!caixa) return null;
    const cnpj = campo(caixa, 'CNPJ'), cpf = campo(caixa, 'CPF');
    const e = endereco(campo(caixa, 'Endereço'));
    return {
      nome: campo(caixa, 'Nome / Razão Social'),
      fantasia: campo(caixa, 'Nome Fantasia'),
      documento: cnpj || cpf,
      ie: campo(caixa, 'Inscrição Estadual'),
      logradouro: e.logradouro, numero: e.numero, complemento: e.complemento,
      bairro: campo(caixa, 'Bairro / Distrito'),
      cep: campo(caixa, 'CEP'),
      cidade: semCodigo(campo(caixa, 'Município')),
      uf: campo(caixa, 'UF'),
      telefone: campo(caixa, 'Telefone'),
      email: campo(caixa, 'E-mail'),
    };
  }

  /**
   * Consulta resumida (layout "XSLTNFeResumida"): só número, série, emissão, emitente (CNPJ, IE, nome,
   * município/UF), destinatário mascarado e o total dos produtos. Sem endereço, volumes e peso.
   */
  function lerResumida() {
    const raiz = document.querySelector('.XSLTNFeResumida');
    if (!raiz) return null;
    const secoes = {}; let atual = 'nfe';
    raiz.querySelectorAll('.THead_NFe, label').forEach(el => {
      if (el.classList.contains('THead_NFe')) {
        const t = norm(el.textContent);
        atual = /emitente/.test(t) ? 'emitente' : /destinat/.test(t) ? 'destinatario' : /produto/.test(t) ? 'produtos' : /dados da nf/.test(t) ? 'nfe' : 'outros';
        return;
      }
      const p = el.nextElementSibling;
      if (!p || p.tagName !== 'P') return;
      (secoes[atual] = secoes[atual] || {})[norm(el.textContent)] = limpa(p.textContent);
    });
    const n = secoes.nfe || {};
    const chave = (n['chave de acesso'] || '').replace(/\D/g, '');
    if (chave.length !== 44) return null;
    let valor = null;
    raiz.querySelectorAll('td').forEach(td => { if (norm(td.textContent) === 'valor total' && td.nextElementSibling) valor = numero(td.nextElementSibling.textContent); });
    const pes = s => {
      if (!s) return null;
      const doc = s['cnpj'] || s['cpf'] || '';
      const nome = s['nome/razao social'] || '';
      const oculto = /\*/.test(doc + nome);
      return {
        nome: oculto ? '' : nome, documento: /\*/.test(doc) ? '' : doc, ie: /\*/.test(s['ie'] || '') ? '' : (s['ie'] || ''),
        logradouro: '', numero: '', complemento: '', bairro: '', cep: '', telefone: '', email: '',
        cidade: s['municipio'] || '', uf: s['uf'] || '',
        oculto, mascara: oculto ? [nome, doc].filter(Boolean).join(' · ') : '',
      };
    };
    return {
      chave, resumida: true,
      numero: n['numero'] || '', serie: n['serie'] || '',
      emissao: n['data/hora da emissao'] || '',
      valor, valorProdutos: true,
      emitente: pes(secoes.emitente), destinatario: pes(secoes.destinatario),
      volumes: 0, peso: 0,
    };
  }

  function lerResultado() {
    const nfe = document.getElementById('NFe');
    if (!nfe) return lerResumida();
    const leg = nfe.querySelector('legend');
    const chave = ((leg && leg.textContent) || '').replace(/\D/g, '').slice(-44);
    if (chave.length !== 44) return null;
    const transp = document.getElementById('Transporte');
    let volumes = 0, peso = 0;
    if (transp) transp.querySelectorAll('label').forEach(l => {
      const s = l.nextElementSibling; if (!s || s.tagName !== 'SPAN') return;
      const r = norm(l.textContent);
      if (r === 'quantidade') volumes += numero(s.textContent) || 0;
      if (r === 'peso bruto') peso += numero(s.textContent) || 0;
    });
    return {
      chave,
      numero: campo(nfe, 'Número'),
      serie: campo(nfe, 'Série'),
      emissao: campo(nfe, 'Data de Emissão'),
      valor: numero(campo(nfe, 'Valor Total da Nota Fiscal')),
      emitente: pessoa(document.getElementById('Emitente')),
      destinatario: pessoa(document.getElementById('DestRem')),
      volumes, peso,
    };
  }

  function aviso(texto, ok) {
    const d = document.createElement('div');
    d.textContent = texto;
    d.style.cssText = 'position:fixed;top:12px;left:50%;transform:translateX(-50%);z-index:2147483647;padding:12px 20px;border-radius:8px;font:600 15px/1.3 Arial,sans-serif;box-shadow:0 4px 18px rgba(0,0,0,.3);color:#fff;background:' + (ok ? '#2e7d32' : '#c62828');
    document.body.appendChild(d);
  }

  let tentativas = 0;
  const t2 = setInterval(async () => {
    const r = lerResultado();
    if (!r) { if (++tentativas > 20) clearInterval(t2); return; }
    clearInterval(t2);
    let ped;
    try { ped = (await chrome.storage.local.get(PEDIDO))[PEDIDO]; } catch (e) { return; }
    if (!ped || ped.chave !== r.chave || Date.now() - (ped.quando || 0) > 60 * 60 * 1000) return;  // consulta não veio da Emissão
    r.quando = Date.now();
    try {
      await chrome.storage.local.set({ [RESULTADO]: r });
      await chrome.storage.local.remove(PEDIDO);
    } catch (e) { aviso('TurboFraction: não consegui enviar os dados para o Fraction.', false); return; }
    aviso('✔ Dados da NF-e ' + r.numero + ' enviados para a Emissão do Fraction', true);
    if (window.opener || ped.popup) setTimeout(() => window.close(), 1500);
  }, 400);
})();
