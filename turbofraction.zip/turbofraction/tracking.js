/*
 * TurboFraction — tela de consulta da remessa (/FractionWeb/jad/tracking)
 *   • Ícone de mapa ao lado do endereço do destinatário (Google Maps).
 *   • Link do WhatsApp Web nos telefones do remetente e do destinatário.
 *   • CPF/CNPJ do destinatário: Pesquisar com filtro CPF/CNPJ.
 *   • CPF/CNPJ do remetente: Consulta Geral pelo CNPJ Cliente, últimos 30 dias.
 *   • Link ao lado de cada chave: "NF-e ↗" (modelo 55) ou "CT-e ↗" (CT-e, modelo 57).
 *   • Botão "Protocolo de Acareação": formulário A4 para imprimir/PDF com os dados do destinatário.
 *   • Botão "Gerar ocorrência": cartão com a tela de Ocorrência, remessa preenchida e ENTREGA escolhida.
 * Mesma lógica do Jadlog Scan (trk.js / MainActivity.kt).
 */
(() => {
  'use strict';

  // Portais oficiais da Receita (consulta resumida); o modelo da chave (posições 21–22) diz qual: 55 = NF-e, 57 = CT-e.
  const PORTAIS = {
    '55': { rotulo: 'NF-e ↗', nome: 'NF-e', url: 'https://www.nfe.fazenda.gov.br/portal/consultaRecaptcha.aspx?tipoConsulta=resumo&tipoConteudo=7PhJ+gAVw2g=' },
    '57': { rotulo: 'CT-e ↗', nome: 'CT-e', url: 'https://www.cte.fazenda.gov.br/portal/consultaRecaptcha.aspx?tipoConsulta=resumo' },
  };
  const URL_OCORRENCIA = location.origin + '/FractionWeb/pages/ocorrencia/ocorrencia.jad';
  const URL_TDE = location.origin + '/FractionWeb/pages/taxaDificuldadeEntrega/taxaDificEntregaEmissao/taxaDificEntregaEmissao.jad';

  const SVG_MAPA = '<svg width="20" height="20" viewBox="0 0 24 24" aria-hidden="true"><path fill="#C8102E" d="M12 2a7 7 0 0 0-7 7c0 5.2 7 13 7 13s7-7.8 7-13a7 7 0 0 0-7-7zm0 9.5A2.5 2.5 0 1 1 12 6.5a2.5 2.5 0 0 1 0 5z"/></svg>';

  /* ---------- Quem é o destinatário (os blocos Remetente / Destinatário usam os mesmos rótulos) ---------- */

  const MARCA = /^(Remetente|Destinat[aá]rio|Local de Coleta|Dest\.?:?|Rem\.?:?)s?\s*$/i;
  function marcadores() {
    return [...document.querySelectorAll('label,span,td,th,div,b')]
      .filter(el => { const t = (el.textContent || '').trim(); return t.length <= 20 && MARCA.test(t); });
  }
  function ehDestinatario(el, mk) {
    let melhor = null;
    for (const m of mk) {
      const pos = m.compareDocumentPosition(el);
      if ((pos & Node.DOCUMENT_POSITION_FOLLOWING) && !(pos & Node.DOCUMENT_POSITION_CONTAINED_BY)) melhor = m;
    }
    return !!melhor && /^Dest/i.test((melhor.textContent || '').trim());
  }
  function valorDoRotulo(tbl, re) {
    for (const l of tbl.querySelectorAll('label.labelTracking')) {
      if (re.test((l.textContent || '').trim())) {
        const v = l.closest('td')?.nextElementSibling?.querySelector('label');
        return v ? v.textContent.replace(/\s+/g, ' ').trim() : '';
      }
    }
    return '';
  }

  /** Tabela do bloco Destinatário (a que tem o "End.:" depois do marcador "Destinatário"). */
  function tabelaDestinatario() {
    const mk = marcadores();
    for (const l of document.querySelectorAll('label.labelTracking')) {
      if (!/^End\.?\s*:?$/i.test((l.textContent || '').trim())) continue;
      if (ehDestinatario(l, mk)) return l.closest('table');
    }
    return null;
  }

  function dadosDestinatario() {
    const tbl = tabelaDestinatario();
    if (!tbl) return { cliente: '', endereco: '' };
    const end = valorDoRotulo(tbl, /^End\.?\s*:?$/i);
    const bairro = valorDoRotulo(tbl, /^Bairro/i);
    const cidade = valorDoRotulo(tbl, /^Cidade/i).replace(/-BR$/i, '');
    const cep = valorDoRotulo(tbl, /^Cep/i).replace(/^(\d{5})(\d{3})$/, '$1-$2');
    return {
      cliente: valorDoRotulo(tbl, /^(Dest|Nome)\.?\s*:?$/i),
      endereco: [end, bairro, cidade, cep ? 'CEP ' + cep : ''].filter(Boolean).join(' - '),
    };
  }

  /* ---------- Dados para a reimpressão da etiqueta ---------- */

  /** Tabela do bloco cujo marcador casa com `re` (ex.: /^Rem/ ou /^Dest/). */
  function tabelaDoBloco(re) {
    const mk = marcadores();
    for (const l of document.querySelectorAll('label.labelTracking')) {
      if (!/^End\.?\s*:?$/i.test((l.textContent || '').trim())) continue;
      let bloco = null;
      for (const m of mk) {
        const pos = m.compareDocumentPosition(l);
        if ((pos & Node.DOCUMENT_POSITION_FOLLOWING) && !(pos & Node.DOCUMENT_POSITION_CONTAINED_BY)) bloco = m;
      }
      if (bloco && re.test(bloco.textContent.trim())) return l.closest('table');
    }
    return null;
  }

  /** Campo de "Informações da Remessa": <label class="labelTracking">Rótulo: </label><label>valor</label>. */
  function info(re) {
    for (const l of document.querySelectorAll('label.labelTracking')) {
      if (!re.test((l.textContent || '').trim())) continue;
      const v = l.nextElementSibling;
      if (v && v.tagName === 'LABEL') return v.textContent.replace(/\s+/g, ' ').trim();
    }
    return '';
  }

  /** Linhas da tabela "Histórico" (DOC/AWB, Data, Hora, Unidade, Operação, Ponto Destino). */
  function historico() {
    for (const tb of document.querySelectorAll('table')) {
      const cab = [...tb.querySelectorAll('thead th')].map(th => th.textContent.trim().toLowerCase());
      if (!cab.some(c => c.startsWith('opera')) || !cab.some(c => c.startsWith('ponto'))) continue;
      return [...tb.querySelectorAll('tbody tr')].map(tr => [...tr.querySelectorAll('td')].map(td => td.textContent.replace(/\s+/g, ' ').trim()))
        .filter(c => c.length >= 6);
    }
    return [];
  }

  function dadosEtiqueta(cte) {
    const dest = tabelaDoBloco(/^Dest/i), rem = tabelaDoBloco(/^Rem/i);
    const v = (tbl, re) => tbl ? valorDoRotulo(tbl, re) : '';
    const docs = [...document.querySelectorAll('div[title*="Danfe"]')].map(dv => dv.textContent.replace(/\s+/g, ' ').trim());
    const nf = docs.map(t => (/^NF:\s*(\d+)/.exec(t) || [])[1]).find(Boolean) || '';
    const pedido = docs.filter(t => !/^NF:/i.test(t)).map(t => t.replace(/\s*Copiar.*$/i, '').trim()).find(Boolean) || '';
    const hist = historico();
    const emis = hist.find(c => /^EMISSAO$/i.test(c[4]));
    const ultimo = hist[hist.length - 1];
    return {
      cte,
      destNome: v(dest, /^(Dest|Nome)\.?\s*:?$/i),
      destEnd: v(dest, /^End\.?\s*:?$/i),
      destBairro: v(dest, /^Bairro/i),
      destCidade: v(dest, /^Cidade/i).replace(/\s*\/\s*/, ' ').replace(/-BR$/i, ''),
      destCep: v(dest, /^Cep/i),
      destFone: v(dest, /^Telefone/i).replace(/\s*WhatsApp.*$/i, ''),
      remNome: v(rem, /^Nome\.?\s*:?$/i),
      remDoc: v(rem, /^(CPF|CNPJ)/i),
      nf, pedido,
      modalidade: info(/^Modalidade/i),
      previsao: info(/^Previs/i),
      shipmentId: info(/^Shipment ID/i),
      codSorter: info(/^Cod\.?\s*Sorter/i),
      circuit: info(/^Circuit/i),
      peso: info(/^Peso:?$/i).replace(',', '.'),
      volumes: info(/^Volumes/i),
      emissao: emis ? emis[1] + ' ' + emis[2] : info(/^Emiss/i),
      unidadeEmissao: emis ? emis[3] : '',
      unidade: ultimo ? ultimo[5] : '',
    };
  }

  /* ---------- Google Maps ---------- */

  function iconesMapa() {
    let mk = null;
    for (const l of document.querySelectorAll('label.labelTracking')) {
      if (l.dataset.tfMapa || !/^End\.?\s*:?$/i.test((l.textContent || '').trim())) continue;
      const v = l.closest('td')?.nextElementSibling?.querySelector('label');
      if (!v) continue;
      l.dataset.tfMapa = '1';
      mk = mk || marcadores();
      if (!ehDestinatario(l, mk)) continue;
      const tbl = l.closest('table');
      if (!tbl) continue;
      const endereco = [
        v.textContent.replace(/\s+/g, ' ').trim(),
        valorDoRotulo(tbl, /^Bairro/i),
        valorDoRotulo(tbl, /^Cidade/i).replace(/\s*\/\s*/, ' - ').replace(/-BR$/i, ''),
        valorDoRotulo(tbl, /^Cep/i),
      ].filter(Boolean).join(', ');
      if (!endereco) continue;
      const a = document.createElement('a');
      a.className = 'tf-mapa';
      a.href = 'https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent(endereco);
      a.target = '_blank';
      a.rel = 'noopener';
      a.title = 'Abrir no Google Maps: ' + endereco;
      a.innerHTML = SVG_MAPA;
      v.parentNode.appendChild(a);
    }
  }

  /* ---------- WhatsApp Web nos telefones do remetente e do destinatário ---------- */

  const SVG_WHATS = '<svg width="16" height="16" viewBox="0 0 24 24" aria-hidden="true"><path fill="#25D366" d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2z"/><path fill="#fff" d="M17.3 14.6c-.3-.1-1.7-.8-1.9-.9-.3-.1-.5-.1-.7.1l-.9 1.1c-.2.2-.3.2-.6.1a7.6 7.6 0 0 1-3.8-3.3c-.3-.5.3-.5.8-1.6.1-.2 0-.4 0-.5l-.9-2.1c-.2-.5-.5-.5-.7-.5h-.6a1.1 1.1 0 0 0-.8.4 3.4 3.4 0 0 0-1 2.5 5.9 5.9 0 0 0 1.2 3.1 13.5 13.5 0 0 0 5.2 4.6c1.9.8 2.7.9 3.6.7a3 3 0 0 0 2-1.4 2.4 2.4 0 0 0 .2-1.4c-.1-.1-.3-.2-.6-.3z"/></svg>';

  /** Separa os números de um campo de telefone e devolve só os que dá para chamar (com DDD), já com o 55. */
  function numerosWhats(texto) {
    return [...new Set(
      texto.replace(/\u260E/g, ' ').split(/[\/,;]|\se\s/)
        .map(t => t.replace(/\D/g, ''))
        .map(n => (n.startsWith('55') && n.length >= 12) ? n : n.replace(/^0+/, ''))
        .map(n => (n.startsWith('55') && n.length >= 12) ? n : (n.length === 10 || n.length === 11 ? '55' + n : ''))
        .filter(n => n.length >= 12 && n.length <= 13)
    )];
  }

  function linksWhats() {
    let mk = null;
    for (const l of document.querySelectorAll('label.labelTracking')) {
      if (l.dataset.tfFone || !/^\s*(Telefone|Fone|Celular)/i.test(l.textContent || '')) continue;
      const v = l.nextElementSibling || l.closest('td')?.nextElementSibling?.querySelector('label');
      if (!v) continue;
      l.dataset.tfFone = '1';
      mk = mk || marcadores();
      // Só nos blocos Remetente e Destinatário.
      let bloco = null;
      for (const m of mk) {
        const pos = m.compareDocumentPosition(l);
        if ((pos & Node.DOCUMENT_POSITION_FOLLOWING) && !(pos & Node.DOCUMENT_POSITION_CONTAINED_BY)) bloco = m;
      }
      if (!bloco || !/^(Rem|Dest)/i.test(bloco.textContent.trim())) continue;
      for (const n of numerosWhats(v.textContent || '')) {
        const a = document.createElement('a');
        a.className = 'tf-whats';
        a.href = 'https://web.whatsapp.com/send?phone=' + n;
        a.target = 'tf-whatsapp'; // reaproveita a mesma aba do WhatsApp Web
        a.rel = 'noopener';
        a.title = 'Chamar +' + n + ' no WhatsApp Web';
        a.innerHTML = SVG_WHATS + '<span>WhatsApp</span>';
        v.parentNode.appendChild(a);
      }
    }
  }

  /* ---------- CPF/CNPJ do remetente e do destinatário: pesquisa por CPF/CNPJ ---------- */

  const URL_PESQUISAR = location.origin + '/FractionWeb/jad/pesquisar';
  const URL_CONSULTA_GERAL = location.origin + '/FractionWeb/jad/consulta';

  // A tela de destino lê este pedido e faz a busca sozinha (vale por 1 minuto).
  function guardar(chave, doc) {
    try { localStorage.setItem(chave, JSON.stringify({ v: doc, t: Date.now() })); } catch (e) { /* sem armazenamento */ }
  }

  function blocoDe(el, mk) {
    let bloco = null;
    for (const m of mk) {
      const pos = m.compareDocumentPosition(el);
      if ((pos & Node.DOCUMENT_POSITION_FOLLOWING) && !(pos & Node.DOCUMENT_POSITION_CONTAINED_BY)) bloco = m;
    }
    return bloco ? bloco.textContent.trim() : '';
  }

  function linksCpf() {
    let mk = null;
    for (const l of document.querySelectorAll('label.labelTracking')) {
      if (l.dataset.tfCpf || !/^\s*(CPF|CNPJ|CPF\s*\/\s*CNPJ)\s*:?\s*$/i.test(l.textContent || '')) continue;
      const v = l.nextElementSibling || l.closest('td')?.nextElementSibling?.querySelector('label');
      if (!v) continue;
      const doc = (v.textContent || '').replace(/\D/g, '');
      if (doc.length !== 11 && doc.length !== 14) continue;
      l.dataset.tfCpf = '1';
      mk = mk || marcadores();
      const bloco = blocoDe(l, mk);
      const remetente = /^Rem/i.test(bloco);
      if (!remetente && !/^Dest/i.test(bloco)) continue;
      const tipo = doc.length === 11 ? 'CPF' : 'CNPJ';
      const a = document.createElement('a');
      a.className = 'tf-cpf';
      a.target = '_blank';
      a.rel = 'noopener';
      a.textContent = v.textContent.trim();
      if (remetente) {
        // Remetente: Consulta Geral pelo campo "CNPJ Cliente", últimos 30 dias (tudo o que ele embarcou).
        a.href = URL_CONSULTA_GERAL;
        a.title = 'Consulta Geral: remessas embarcadas por este ' + tipo + ' nos últimos 30 dias';
        a.addEventListener('click', () => guardar('tf_cons_cnpj', doc));
      } else {
        // Destinatário: Pesquisar com o filtro CPF / CNPJ (outras entregas para a mesma pessoa).
        a.href = URL_PESQUISAR;
        a.title = 'Pesquisar outras entregas para este ' + tipo;
        a.addEventListener('click', () => guardar('tf_pesq_cpf', doc));
      }
      v.textContent = '';
      v.appendChild(a);
    }
  }

  /* ---------- NF-e na Receita ---------- */

  function linksReceita() {
    for (const d of document.querySelectorAll('div[title*="Danfe"]')) {
      if (d.dataset.tfNfe) continue;
      const m = /NFe:\s*([0-9A-Za-z]{44})/.exec(d.textContent || '');
      if (!m) continue;
      d.dataset.tfNfe = '1';
      const chave = m[1];
      // Modelo da chave (posições 21-22): 55 = NF-e, 57 = CT-e, cada um no seu portal da Receita.
      const modelo = chave.slice(20, 22);
      // Outros modelos (ex.: 99, declaração de conteúdo) não são consultados na Receita: ficam sem link.
      if (!PORTAIS[modelo]) {
        const tag = document.createElement('span');
        tag.className = 'tf-sem-nfe';
        tag.textContent = 'sem NF-e (modelo ' + modelo + ')';
        tag.title = 'Chave de modelo ' + modelo + ': não é NF-e nem CT-e, a Receita não consulta.';
        d.appendChild(tag);
        continue;
      }
      const portal = PORTAIS[modelo];
      const a = document.createElement('a');
      a.className = 'tf-receita';
      a.dataset.modelo = modelo;
      a.textContent = portal.rotulo;
      a.href = portal.url + '#tf_chave=' + chave;
      a.target = '_blank';
      a.rel = 'noopener';
      a.title = 'Copia a chave e abre a consulta do ' + portal.nome + ' no portal da Receita (o captcha é com você)';
      a.addEventListener('click', ev => {
        ev.stopPropagation();
        try { navigator.clipboard.writeText(chave); } catch (e) { /* sem área de transferência */ }
      }, true);
      d.appendChild(a);
    }
  }

  /* ---------- Gerar ocorrência ---------- */

  function numeroRemessa() {
    const m = /Conhecimento:\s*(\d{10,})/.exec(document.body.innerText || '');
    return m ? m[1] : '';
  }
  /** Consulta de uma coleta: tem "Ordem Coleta: N" mas não tem número de Conhecimento. */
  function numeroColeta() {
    const m = /Ordem\s+(?:de\s+)?Coleta:\s*(\d{6,})/i.exec(document.body.innerText || '');
    return m ? m[1] : '';
  }

  /** Cartão por cima da consulta com a tela de Ocorrência do próprio site. */
  function abrirCartaoOcorrencia(cte, tela) {
    fecharCartaoOcorrencia();
    const tde = tela === 'tde', coleta = tela === 'coleta';
    const fundo = document.createElement('div');
    fundo.id = 'tf-oc-fundo';
    fundo.innerHTML =
      '<div class="tf-oc-cartao" role="dialog" aria-label="' + (tde ? 'Solicitar TDE' : 'Gerar ocorrência') + '">' +
        '<div class="tf-oc-topo">' +
          '<span class="tf-oc-titulo"></span>' +
          '<a class="tf-oc-aba" target="_blank" rel="noopener">Abrir em nova aba ↗</a>' +
          '<button type="button" class="tf-oc-fechar" title="Fechar (Esc)">✕</button>' +
        '</div>' +
        '<iframe class="tf-oc-quadro"></iframe>' +
      '</div>';
    fundo.querySelector('.tf-oc-titulo').textContent = (tde ? '🚚 Solicitar TDE — remessa ' : coleta ? '⚠ Ocorrência — coleta ' : '⚠ Ocorrência — remessa ') + cte;
    const url = (tde ? URL_TDE : URL_OCORRENCIA) + '#tf_remessa=' + cte + (coleta ? '&tf_oc=COLETA' : '');
    fundo.querySelector('.tf-oc-aba').href = url;
    fundo.querySelector('.tf-oc-aba').addEventListener('click', fecharCartaoOcorrencia);
    fundo.querySelector('.tf-oc-quadro').src = url + '&tf_cartao=1';
    fundo.querySelector('.tf-oc-fechar').addEventListener('click', fecharCartaoOcorrencia);
    fundo.addEventListener('mousedown', ev => { if (ev.target === fundo) fecharCartaoOcorrencia(); });
    document.addEventListener('keydown', escFecha);
    document.body.appendChild(fundo);
  }
  function escFecha(ev) { if (ev.key === 'Escape') fecharCartaoOcorrencia(); }

  // O cartão avisa quando o Fraction confirmou a ocorrência: fecha e recarrega a consulta da remessa
  // (abre de novo pelo endereço da remessa, para o Fraction buscar o histórico atualizado).
  window.addEventListener('message', ev => {
    const quadro = document.querySelector('#tf-oc-fundo .tf-oc-quadro');
    if (!quadro || ev.source !== quadro.contentWindow || ev.origin !== location.origin) return;
    if (!ev.data || ev.data.tipo !== 'tf-ocorrencia-ok') return;
    const cteOk = String(ev.data.remessa || '').replace(/\D/g, '');
    if (ev.data.devolver) {
      // Devolver: o Fraction ainda vai imprimir a etiqueta de devolução dentro do cartão. O cartão fica aberto
      // e a consulta só se atualiza quando o usuário fechar.
      const topo = document.querySelector('#tf-oc-fundo .tf-oc-topo');
      if (topo && !topo.querySelector('.tf-oc-ok')) {
        const ok = document.createElement('span'); ok.className = 'tf-oc-ok';
        ok.textContent = '✔ ' + (ev.data.msg || 'Ocorrência incluída') + ' — aguarde a etiqueta de devolução e feche quando terminar';
        topo.querySelector('.tf-oc-titulo').after(ok);
      }
      atualizarAoFechar = cteOk || '*';
      return;
    }
    fecharCartaoOcorrencia();
    const aviso = document.createElement('div');
    aviso.id = 'tf-oc-aviso';
    aviso.textContent = '✔ ' + (ev.data.msg || 'Ocorrência incluída') + ' — atualizando a consulta…';
    document.body.appendChild(aviso);
    const cte = String(ev.data.remessa || '').replace(/\D/g, '');
    setTimeout(() => { location.href = cte ? location.origin + '/FractionWeb/jad/tracking?cte=' + cte : location.href; }, 900);
  });
  let atualizarAoFechar = '';
  function fecharCartaoOcorrencia() {
    document.getElementById('tf-oc-fundo')?.remove();
    document.removeEventListener('keydown', escFecha);
    if (atualizarAoFechar) {
      const cte = atualizarAoFechar === '*' ? '' : atualizarAoFechar;
      atualizarAoFechar = '';
      location.href = cte ? location.origin + '/FractionWeb/jad/tracking?cte=' + cte : location.href;
    }
  }

  /** Coleta aberta na consulta: botão "Gerar ocorrência" com a ocorrência COLETA já escolhida. */
  function botaoOcorrenciaColeta(col) {
    const btn = document.createElement('a');
    btn.id = 'tf-ocorrencia';
    btn.className = 'tf-botao';
    btn.href = URL_OCORRENCIA + '#tf_remessa=' + col + '&tf_oc=COLETA';
    btn.innerHTML = '<span aria-hidden="true">⚠</span> Gerar ocorrência';
    btn.title = 'Abre a tela de Ocorrência com a coleta ' + col + ' e "COLETA" já escolhida';
    btn.addEventListener('click', ev => {
      if (ev.ctrlKey || ev.shiftKey || ev.metaKey || ev.button !== 0) return;
      ev.preventDefault();
      abrirCartaoOcorrencia(col, 'coleta');
    });
    // O rótulo "Ordem Coleta:" da consulta (não o item "Ordem de coleta" do menu do site).
    const rotulo = [...document.querySelectorAll('label,span,td,b')]
      .find(el => el.children.length === 0 && !el.closest('.ui-menu, .ui-menubar, nav, ul') && /^\s*Ordem\s+(de\s+)?Coleta:\s*$/i.test(el.textContent || ''));
    const linha = rotulo && (rotulo.closest('tr') || rotulo.parentElement);
    const barra = document.createElement('div');
    barra.className = linha && linha.parentElement ? 'tf-barra' : 'tf-flutuante';
    barra.append(btn);
    if (linha && linha.parentElement) (linha.closest('table') || linha).after(barra); else document.body.appendChild(barra);
  }

  function botaoOcorrencia() {
    if (document.getElementById('tf-ocorrencia')) return;
    const cte = numeroRemessa();
    if (!cte) { const col = numeroColeta(); if (col) botaoOcorrenciaColeta(col); return; }
    const btn = document.createElement('a');
    btn.id = 'tf-ocorrencia';
    btn.className = 'tf-botao';
    btn.href = URL_OCORRENCIA + '#tf_remessa=' + cte;
    btn.innerHTML = '<span aria-hidden="true">⚠</span> Gerar ocorrência';
    btn.title = 'Abre a tela de Ocorrência com a remessa ' + cte + ' e "ENTREGA" já escolhida';
    btn.addEventListener('click', ev => {
      // Ctrl/Shift/botão do meio continuam abrindo em nova aba.
      if (ev.ctrlKey || ev.shiftKey || ev.metaKey || ev.button !== 0) return;
      ev.preventDefault();
      abrirCartaoOcorrencia(cte);
    });

    // Coloca o botão na linha "Ordem Coleta / Conhecimento / Tomador"; se não achar, fica flutuando.
    const rotulo = [...document.querySelectorAll('label,span,td,b')]
      .find(el => el.children.length === 0 && /^\s*Conhecimento:?\s*$/i.test(el.textContent || ''));
    const linha = rotulo && (rotulo.closest('tr') || rotulo.parentElement);
    const acar = document.createElement('a');
    acar.id = 'tf-acareacao';
    acar.className = 'tf-botao tf-botao-claro';
    acar.href = '#';
    acar.innerHTML = '<span aria-hidden="true">🖨</span> Protocolo de Acareação';
    acar.title = 'Imprime (ou salva em PDF) o Protocolo de Acareação com CT-e, cliente e endereço do destinatário';
    acar.addEventListener('click', ev => {
      ev.preventDefault();
      chrome.runtime.sendMessage({ tipo: 'abrirAcareacao', dados: { cte, ...dadosDestinatario() } });
    });

    // Solicitar TDE (Taxa de Dificuldade de Entrega): cartão com a tela de solicitação, remessa pesquisada.
    const tde = document.createElement('a');
    tde.id = 'tf-tde';
    tde.className = 'tf-botao tf-botao-claro';
    tde.href = URL_TDE + '#tf_remessa=' + cte;
    tde.innerHTML = '<span aria-hidden="true">🚚</span> Solicitar TDE';
    tde.title = 'Abre a Solicitação de TDE com a remessa ' + cte + ' já pesquisada';
    tde.addEventListener('click', ev => {
      if (ev.ctrlKey || ev.shiftKey || ev.metaKey || ev.button !== 0) return;
      ev.preventDefault();
      abrirCartaoOcorrencia(cte, 'tde');
    });

    if (linha && linha.parentElement) {
      const barra = document.createElement('div');
      barra.className = 'tf-barra';
      barra.append(acar, tde, btn);
      (linha.closest('table') || linha).after(barra);
    } else {
      const barra = document.createElement('div');
      barra.className = 'tf-flutuante';
      barra.append(acar, tde, btn);
      document.body.appendChild(barra);
    }
  }

  /* ---------- Foto do comprovante: GPS gravado no arquivo (EXIF) → Google Maps ---------- */

  /** Lê latitude/longitude do EXIF de um JPEG. Devolve {lat, lng} ou null (sem GPS no arquivo). */
  function gpsDoJpeg(buf) {
    const v = new DataView(buf);
    if (v.byteLength < 4 || v.getUint16(0) !== 0xFFD8) return null;
    let p = 2;
    while (p + 4 < v.byteLength) {
      const marca = v.getUint16(p), tam = v.getUint16(p + 2);
      if (marca === 0xFFE1 && v.getUint32(p + 4) === 0x45786966) return gpsDoTiff(v, p + 10); // "Exif"
      if ((marca & 0xFF00) !== 0xFF00 || marca === 0xFFDA) break;
      p += 2 + tam;
    }
    return null;
  }
  function gpsDoTiff(v, t) {
    const le = v.getUint16(t) === 0x4949;
    const u16 = o => v.getUint16(t + o, le), u32 = o => v.getUint32(t + o, le);
    const tags = ifd => { const n = u16(ifd), m = {}; for (let i = 0; i < n; i++) { const e = ifd + 2 + i * 12; m[u16(e)] = e; } return m; };
    const ifd0 = tags(u32(4));
    if (!ifd0[0x8825]) return null;
    const g = tags(u32(ifd0[0x8825] + 8));
    const racionais = e => { const o = u32(e + 8); return [0, 1, 2].map(i => u32(o + i * 8) / (u32(o + i * 8 + 4) || 1)); };
    const ref = e => e ? String.fromCharCode(v.getUint8(t + e + 8)) : '';
    if (!g[2] || !g[4]) return null;
    const grau = ([d, m, s]) => d + m / 60 + s / 3600;
    let lat = grau(racionais(g[2])), lng = grau(racionais(g[4]));
    if (ref(g[1]) === 'S') lat = -lat;
    if (ref(g[3]) === 'W') lng = -lng;
    if (!isFinite(lat) || !isFinite(lng) || (lat === 0 && lng === 0)) return null;
    return { lat, lng };
  }

  async function mapaDasFotos() {
    const fotos = [...document.querySelectorAll('.ui-panel-content img')].filter(img =>
      !img.dataset.tfGps && (img.width >= 300 || img.getAttribute('width') >= 300) && /^https?:/.test(img.src));
    for (const img of fotos) {
      img.dataset.tfGps = '1';
      try {
        const r = await fetch(img.src, { credentials: 'same-origin' });
        const gps = gpsDoJpeg(await r.arrayBuffer());
        if (!gps) continue; // sem GPS no arquivo: nada a mostrar
        const coord = gps.lat.toFixed(7) + ',' + gps.lng.toFixed(7);
        const a = document.createElement('a');
        a.className = 'tf-botao tf-foto-mapa';
        a.href = 'https://www.google.com/maps/search/?api=1&query=' + coord;
        a.target = '_blank'; a.rel = 'noopener';
        a.textContent = '📍 Ver local da foto no Google Maps';
        a.title = 'Coordenada gravada na foto: ' + coord.replace(',', ', ');
        const div = document.createElement('div'); div.className = 'tf-foto-mapa-linha'; div.appendChild(a);
        (img.closest('table') || img).after(div);
      } catch (e) { /* foto inacessível: ignora */ }
    }
  }

  /* ---------- "Produtos" (remessas faltantes): abre a NF-e direto na Receita ---------- */
  let produtosFeito = false;
  async function abrirProdutos() {
    if (produtosFeito) return;
    const cte = numeroRemessa();
    if (!cte) return;
    let ped;
    try { ped = (await chrome.storage.local.get('tf_produtos')).tf_produtos; } catch (e) { return; }
    if (!ped || ped.cte !== cte || Date.now() - ped.t > 120000) return;
    const links = [...document.querySelectorAll('a.tf-receita')].filter(a => a.dataset.modelo === '55');
    if (!links.length) {
      // Página montada (chaves já processadas) e nenhuma NF-e: avisa em vez de ficar esperando.
      if (document.querySelector('[data-tf-nfe]') || Date.now() - ped.t > 15000) {
        produtosFeito = true;
        chrome.storage.local.remove('tf_produtos');
        const av = document.createElement('div'); av.id = 'tf-oc-aviso'; av.style.background = '#8a5a00';
        av.textContent = 'Esta remessa não tem NF-e (só declaração de conteúdo / CT-e).';
        document.body.appendChild(av); setTimeout(() => av.remove(), 6000);
      }
      return; // ainda montando a página (tenta de novo na próxima mudança)
    }
    produtosFeito = true;
    chrome.storage.local.remove('tf_produtos');
    if (links.length === 1) {
      const chave = (/#tf_chave=(\w{44})/.exec(links[0].href) || [])[1];
      try { if (chave) navigator.clipboard.writeText(chave).catch(() => {}); } catch (e) { /* ok */ }
      location.replace(links[0].href);
    } else {
      // Várias NFs: mostra os links da Receita em destaque para escolher.
      links.forEach(a => a.classList.add('tf-receita-destaque'));
      links[0].scrollIntoView({ block: 'center' });
    }
  }

  /* ---------- "Lista: N" vira link para imprimir a lista de entrega ---------- */
  /** Data do último evento "EM ROTA" do histórico (null = não há; undefined = histórico não encontrado). */
  function ultimoEmRota() {
    const tabela = document.querySelector('[id$=":trackHistorico"] table');
    if (!tabela) return undefined;
    const cab = [...tabela.querySelectorAll('thead th')].map(c => c.textContent.trim());
    let iData = cab.indexOf('Data'), iOp = cab.findIndex(c => /^Opera/i.test(c));
    if (iData < 0) iData = 1;
    if (iOp < 0) iOp = 4;
    let ultima = null;
    tabela.querySelectorAll('tbody tr').forEach(tr => {
      const c = tr.cells;
      if (!c[iOp] || !/^EM ROTA$/i.test(c[iOp].textContent.trim())) return;
      const m = /(\d{2})\/(\d{2})\/(\d{4})/.exec(c[iData]?.textContent || '');
      if (!m) return;
      const d = new Date(+m[3], +m[2] - 1, +m[1]);
      if (!ultima || d > ultima) ultima = d;
    });
    return ultima;
  }

  function linkLista() {
    const rot = [...document.querySelectorAll('label.labelTracking')].find(l => /^Lista:\s*$/.test(l.textContent));
    const val = rot && rot.nextElementSibling;
    if (!val || val.dataset.tfLista) return;
    const n = (val.textContent || '').trim();
    if (!/^\d+$/.test(n)) return;
    // A tela Lista de Entrega só mostra os últimos 30 dias: só vira link se o último "EM ROTA" estiver nesse prazo.
    const emRota = ultimoEmRota();
    if (emRota === undefined) return; // histórico ainda não carregou
    val.dataset.tfLista = '1';
    const dias = emRota ? Math.floor((Date.now() - emRota.getTime()) / 864e5) : null;
    if (dias === null || dias > 30) {
      val.title = dias === null
        ? 'Sem evento EM ROTA no histórico: a lista não aparece na tela Lista de Entrega.'
        : `O último EM ROTA foi há ${dias} dias: a tela Lista de Entrega só mostra os últimos 30 dias.`;
      return;
    }
    const a = document.createElement('a');
    a.href = location.origin + '/FractionWeb/pages/listaEntrega/listaEntrega.jad';
    a.target = '_blank'; a.rel = 'noopener';
    a.className = 'tf-lista-link';
    a.textContent = n;
    a.title = 'Imprimir a lista de entrega ' + n + ' (abre numa aba nova)';
    a.addEventListener('click', () => {
      try { chrome.storage.local.set({ tf_imprimir_lista: { n, cte: numeroRemessa(), t: Date.now() } }); } catch (e) { /* ok */ }
    });
    val.textContent = '';
    val.appendChild(a);
  }

  /* ---------- Histórico: manifesto (DOC/AWB das transferências e dos TRAVADO) vira link para reimpressão ---------- */
  function linksManifesto() {
    const tabela = document.querySelector('[id$=":trackHistorico"] table');
    if (!tabela) return;
    const cab = [...tabela.querySelectorAll('thead th')].map(c => c.textContent.trim().toUpperCase());
    const iDoc = cab.findIndex(t => /^DOC/.test(t)), iOp = cab.findIndex(t => /OPERA/.test(t));
    if (iDoc < 0 || iOp < 0) return;
    tabela.querySelectorAll('tbody tr').forEach(tr => {
      const cDoc = tr.cells[iDoc], cOp = tr.cells[iOp];
      if (!cDoc || !cOp || cDoc.dataset.tfMan) return;
      const n = cDoc.textContent.trim();
      if (!/^\d{6,}$/.test(n) || !/^TRANSFER(ENCIA|IDO PARA UNIDADE)$|TRAVADO/i.test(cOp.textContent.trim())) return;
      cDoc.dataset.tfMan = '1';
      const a = document.createElement('a');
      a.href = location.origin + '/FractionWeb/pages/envioRemessa/envio.jad';
      a.target = '_blank'; a.rel = 'noopener';
      a.className = 'tf-lista-link';
      a.textContent = n;
      a.title = 'Reimprimir o manifesto ' + n + ' (abre aqui mesmo; Ctrl + clique abre numa aba nova)';
      a.addEventListener('click', ev => {
        ev.stopPropagation();
        if (ev.ctrlKey || ev.metaKey || ev.shiftKey) {   // jeito antigo: aba nova com a tela Envio de Remessa
          try { chrome.storage.local.set({ tf_imprimir_manifesto: { n, t: Date.now() } }); } catch (e) { /* ok */ }
          return;
        }
        ev.preventDefault();
        manifestoAqui(n);
      });
      cDoc.textContent = '';
      cDoc.appendChild(a);
    });
  }

  /* ---------- Reimpressão do manifesto sem sair da consulta ---------- */
  // Faz por trás o mesmo da tela Envio de Remessa › Imprimir e mostra o arquivo num cartão por cima da consulta.
  const URL_ENVIO = () => location.origin + '/FractionWeb/pages/envioRemessa/envio.jad';
  const CAB_AJAX = { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8', 'Faces-Request': 'partial/ajax', 'X-Requested-With': 'XMLHttpRequest' };
  const httpsDe = u => { const x = new URL(u, location.href); if (x.protocol === 'http:' && location.protocol === 'https:') x.protocol = 'https:'; return x.href; };
  function cartaoManifesto(n) {
    document.getElementById('tf-man-fundo')?.remove();
    const fundo = document.createElement('div');
    fundo.id = 'tf-man-fundo';
    fundo.innerHTML = '<div class="tf-man-cartao"><div class="tf-man-topo"><b></b><span class="tf-man-acoes"></span><button type="button" class="tf-man-x" title="Fechar (Esc)">✕</button></div><div class="tf-man-corpo"><p class="tf-man-msg"></p></div></div>';
    fundo.querySelector('b').textContent = '🖨 Manifesto ' + n;
    const fechar = () => { const f = fundo.querySelector('iframe'); if (f && f.dataset.url) setTimeout(() => URL.revokeObjectURL(f.dataset.url), 1000); fundo.remove(); document.removeEventListener('keydown', esc, true); };
    const esc = ev => { if (ev.key === 'Escape') { ev.stopPropagation(); fechar(); } };
    fundo.querySelector('.tf-man-x').addEventListener('click', fechar);
    fundo.addEventListener('mousedown', ev => { if (ev.target === fundo) fechar(); });
    document.addEventListener('keydown', esc, true);
    document.body.appendChild(fundo);
    return {
      fundo,
      msg: (t, erro) => { const p = fundo.querySelector('.tf-man-msg'); p.textContent = t; p.classList.toggle('erro', !!erro); },
      acoes: fundo.querySelector('.tf-man-acoes'),
      corpo: fundo.querySelector('.tf-man-corpo'),
    };
  }
  async function abasDeEnvioAbertas() {
    try { const r = await chrome.runtime.sendMessage({ tipo: 'abasEnvio' }); return (r && r.n) || 0; } catch (e) { return 0; }
  }
  async function manifestoAqui(n, confirmado) {
    const c = cartaoManifesto(n);
    if (!confirmado && await abasDeEnvioAbertas()) {
      c.msg('Há uma aba de Envio de Remessa aberta. Imprimir por aqui usa a mesma tela no Fraction e pode mexer na lista que está sendo montada lá.', true);
      const ok = document.createElement('button'); ok.type = 'button'; ok.textContent = 'Imprimir mesmo assim';
      const aba = document.createElement('button'); aba.type = 'button'; aba.textContent = 'Abrir numa aba nova';
      ok.addEventListener('click', () => manifestoAqui(n, true));
      aba.addEventListener('click', () => { try { chrome.storage.local.set({ tf_imprimir_manifesto: { n, t: Date.now() } }); } catch (e) { /* ok */ } window.open(URL_ENVIO(), '_blank'); c.fundo.remove(); });
      c.acoes.append(ok, aba);
      return;
    }
    c.msg('Gerando o manifesto no Fraction…');
    try {
      // 1) Tela Envio de Remessa (para pegar o formulário de impressão e o ViewState)
      const r0 = await fetch(URL_ENVIO(), { credentials: 'same-origin' });
      const doc = new DOMParser().parseFromString(await r0.text(), 'text/html');
      const form = doc.getElementById('form_imp_env_rem');
      if (!form) throw new Error('não encontrei a janela Imprimir da tela Envio de Remessa (sessão expirada?)');
      const acao = httpsDe(form.getAttribute('action') || URL_ENVIO());
      let vs = (form.querySelector('input[name="javax.faces.ViewState"]') || doc.querySelector('input[name="javax.faces.ViewState"]') || {}).value || '';
      const campo = 'form_imp_env_rem:id_manifesto';
      // 2) O mesmo "change" do campo (validação do Fraction)
      const p1 = new URLSearchParams({ 'javax.faces.partial.ajax': 'true', 'javax.faces.source': campo, 'javax.faces.partial.execute': campo, 'javax.faces.partial.render': 'form_notificacao:mensagemTmp', 'javax.faces.behavior.event': 'change', 'javax.faces.partial.event': 'change', form_imp_env_rem: 'form_imp_env_rem', [campo]: n, 'javax.faces.ViewState': vs });
      const x1 = await (await fetch(acao, { method: 'POST', credentials: 'same-origin', headers: CAB_AJAX, body: p1.toString() })).text();
      const novoVs = /<update id="[^"]*javax\.faces\.ViewState[^"]*"><!\[CDATA\[([^\]]*)\]\]>/.exec(x1);
      if (novoVs) vs = novoVs[1];
      const erroMsg = /"severity"\s*:\s*"(?:error|fatal)"[^}]*"(?:summary|detail)"\s*:\s*"([^"]+)"/i.exec(x1) || /"(?:summary|detail)"\s*:\s*"([^"]+)"[^}]*"severity"\s*:\s*"(?:error|fatal)"/i.exec(x1);
      if (erroMsg) throw new Error('o Fraction respondeu: ' + erroMsg[1]);
      // 3) Enviar (o relatório)
      const p2 = new URLSearchParams({ form_imp_env_rem: 'form_imp_env_rem', [campo]: n, 'form_imp_env_rem:botao_imp_env_rem': '', 'javax.faces.ViewState': vs });
      const r2 = await fetch(acao, { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' }, body: p2.toString() });
      const tipo = (r2.headers.get('content-type') || '').split(';')[0] || 'application/pdf';
      const blob = await r2.blob();
      if (/html/i.test(tipo)) {
        const txt = await blob.text();
        if (/form_imp_env_rem|Envio de Remessa/i.test(txt) && !/manifesto/i.test(txt.replace(/form_imp_env_rem:id_manifesto/g, ''))) throw new Error('o Fraction devolveu a própria tela em vez do manifesto');
      }
      const url = URL.createObjectURL(new Blob([blob], { type: tipo }));
      c.msg('');
      c.corpo.innerHTML = '';
      const f = document.createElement('iframe'); f.src = url; f.dataset.url = url; f.className = 'tf-man-quadro';
      c.corpo.appendChild(f);
      const imp = document.createElement('button'); imp.type = 'button'; imp.textContent = '🖨 Imprimir';
      imp.addEventListener('click', () => { try { f.contentWindow.focus(); f.contentWindow.print(); } catch (e) { window.open(url, '_blank'); } });
      const bx = document.createElement('a'); bx.textContent = '💾 Baixar'; bx.href = url; bx.download = 'Manifesto_' + n + (/pdf/i.test(tipo) ? '.pdf' : /html/i.test(tipo) ? '.html' : '');
      const nv = document.createElement('a'); nv.textContent = '↗ Nova aba'; nv.href = url; nv.target = '_blank';
      c.acoes.append(imp, bx, nv);
    } catch (e) {
      console.warn('[TurboFraction] manifesto', e);
      c.msg('Não consegui gerar o manifesto: ' + e.message, true);
      const aba = document.createElement('button'); aba.type = 'button'; aba.textContent = 'Tentar numa aba nova';
      aba.addEventListener('click', () => { try { chrome.storage.local.set({ tf_imprimir_manifesto: { n, t: Date.now() } }); } catch (e2) { /* ok */ } window.open(URL_ENVIO(), '_blank'); c.fundo.remove(); });
      c.acoes.append(aba);
    }
  }

  /* ---------- Texto selecionado → botão vermelho "Imprimir" (etiqueta com o texto) ---------- */
  function textoSelecionado() {
    const sel = window.getSelection();
    if (!sel || sel.isCollapsed) return '';
    const no = sel.anchorNode && (sel.anchorNode.nodeType === 1 ? sel.anchorNode : sel.anchorNode.parentElement);
    if (no && no.closest('input, textarea')) return '';
    return sel.toString().replace(/[ \t]+/g, ' ').replace(/\s*\n\s*/g, '\n').trim();
  }
  // O próprio botão "Imprimir" da consulta: com texto selecionado fica vermelho e imprime uma etiqueta
  // com esse texto; sem seleção, volta à cor e à função originais.
  const botaoImprimir = () => [...document.querySelectorAll('button')].find(b => /^Imprimir$/i.test(b.textContent.trim()) && /jqprint/.test(b.getAttribute('onclick') || ''));
  function marcarImprimir() {
    const b = botaoImprimir();
    if (!b) return;
    const t = textoSelecionado();
    b.classList.toggle('tf-imp-sel', !!t);
    b.dataset.tfTexto = t;
    if (t) b.title = 'Imprimir uma etiqueta com o texto selecionado: "' + (t.length > 60 ? t.slice(0, 60) + '…' : t) + '"';
    else b.removeAttribute('title');
  }
  document.addEventListener('selectionchange', marcarImprimir);
  // Captura no documento: passa na frente do onclick original só quando há texto selecionado.
  document.addEventListener('mousedown', ev => {
    const b = ev.target.closest && ev.target.closest('button.tf-imp-sel');
    if (b) ev.preventDefault();   // o clique não desfaz a seleção
  }, true);
  document.addEventListener('click', ev => {
    const b = ev.target.closest && ev.target.closest('button.tf-imp-sel');
    if (!b) return;
    const texto = b.dataset.tfTexto || textoSelecionado();
    if (!texto) return;
    ev.preventDefault(); ev.stopImmediatePropagation(); ev.stopPropagation();
    try { chrome.runtime.sendMessage({ tipo: 'abrirEtiquetaTexto', dados: { texto, cte: numeroRemessa() } }); } catch (e) { console.warn('[TurboFraction]', e); }
  }, true);

  /* ---------- Consulta expirada: tela de erro do Fraction (findCte sem remessa) ---------- */
  // Guarda (por aba) a última remessa aberta; se a tela cair no erro, reabre essa remessa.
  const CHAVE_ULTIMA = 'tf_ultima_cte', CHAVE_TENTOU = 'tf_reabriu';
  function ehTelaDeErro() {
    const txt = document.body ? document.body.textContent || '' : '';   // textContent inclui o texto do quadro (textarea) do erro
    return /Erro apresentado/i.test(txt) && /findCte|tracking/i.test(txt) && !document.querySelector('label.labelTracking');
  }
  function tratarErro() {
    if (!ehTelaDeErro()) return false;
    let cte = '', tentou = 0;
    try { cte = sessionStorage.getItem(CHAVE_ULTIMA) || ''; tentou = +sessionStorage.getItem(CHAVE_TENTOU) || 0; } catch (e) { /* ok */ }
    const aviso = document.createElement('div');
    aviso.id = 'tf-expirou';
    const caixa = document.querySelector('textarea') ? document.querySelector('textarea').closest('div, td, form') : null;
    if (cte && Date.now() - tentou > 15000) {
      // Evita repetir sem parar: só tenta reabrir uma vez a cada 15 s.
      try { sessionStorage.setItem(CHAVE_TENTOU, String(Date.now())); } catch (e) { /* ok */ }
      aviso.innerHTML = '<b>A consulta expirou.</b> Reabrindo a remessa <span></span>…';
      aviso.querySelector('span').textContent = cte;
      document.body.prepend(aviso);
      setTimeout(() => location.replace(location.origin + '/FractionWeb/jad/tracking?cte=' + encodeURIComponent(cte)), 600);
    } else {
      aviso.innerHTML = '<b>A consulta expirou.</b> O Fraction descartou esta tela (aba antiga ou sessão expirada). <a>Abrir a Consulta</a>';
      const a = aviso.querySelector('a'); a.href = location.origin + '/FractionWeb/jad/consulta';
      document.body.prepend(aviso);
    }
    if (caixa) caixa.style.opacity = '.35';
    return true;
  }
  function lembrarRemessa() {
    const cte = numeroRemessa();
    if (cte) try { sessionStorage.setItem(CHAVE_ULTIMA, cte); sessionStorage.removeItem(CHAVE_TENTOU); } catch (e) { /* ok */ }
  }

  // Cada melhoria roda separada: se uma falhar numa tela diferente (ex.: consulta de coleta), as outras continuam.
  const PASSOS = [lembrarRemessa, linksManifesto, iconesMapa, linksWhats, linksCpf, linksReceita, botaoOcorrencia, mapaDasFotos, abrirProdutos, linkLista];
  const falhou = new Set();
  function aplicar() {
    PASSOS.forEach(f => {
      try { f(); } catch (e) { if (!falhou.has(f.name)) { falhou.add(f.name); console.warn('[TurboFraction] ' + f.name + ':', e); } }
    });
  }
  if (tratarErro()) return;
  aplicar();
  // Os painéis do PrimeFaces podem ser redesenhados: reaplica de tempos em tempos.
  setInterval(aplicar, 1000);
})();
