/*
 * TurboFraction — Pickup › Consultas Pudo - Unidades Atendidas
 * Coluna "Motorista" na tabela: um campo por PUDO para anotar quem faz a coleta.
 * Os nomes ficam guardados na extensão (por código do PUDO, ex.: BR10727) e voltam sempre que a tela abre.
 */
(() => {
  'use strict';
  const TABELA = 'dados-data-table';
  const CHAVE = 'tf_pudo_motoristas';
  let nomes = {};
  let pronto = false;

  const codigoPudo = tr => {
    const td = [...tr.cells].find(c => /^\s*BR\d+\s*-/.test(c.textContent));
    return td ? td.textContent.trim().split(/\s*-\s*/)[0] : '';
  };

  let tGravar = 0;
  function gravar() {
    clearTimeout(tGravar);
    tGravar = setTimeout(() => { try { chrome.storage.local.set({ [CHAVE]: nomes }); } catch (e) { /* ok */ } }, 300);
  }

  function listaSugestoes() {
    let dl = document.getElementById('tf-pudo-nomes');
    if (!dl) { dl = document.createElement('datalist'); dl.id = 'tf-pudo-nomes'; document.body.appendChild(dl); }
    const unicos = [...new Set(Object.values(nomes).map(n => (n || '').trim()).filter(Boolean))].sort((a, b) => a.localeCompare(b, 'pt-BR'));
    dl.innerHTML = '';
    unicos.forEach(n => { const o = document.createElement('option'); o.value = n; dl.appendChild(o); });
  }

  function aplicar() {
    if (!pronto) return;
    const tab = document.getElementById(TABELA);
    if (!tab) return;
    const cab = tab.querySelector('thead tr');
    if (cab && !cab.querySelector('.tf-pudo-th')) {
      const th = document.createElement('th');
      th.className = 'ui-state-default tf-pudo-th';
      th.setAttribute('role', 'columnheader');
      th.innerHTML = '<span class="ui-column-title">Motorista</span>';
      th.title = 'Nome do motorista que faz a coleta neste PUDO (guardado neste navegador)';
      cab.appendChild(th);
    }
    const corpo = document.getElementById(TABELA + '_data');
    if (!corpo) return;
    [...corpo.rows].forEach(tr => {
      if (tr.querySelector('.tf-pudo-td') || tr.classList.contains('ui-datatable-empty-message')) return;
      const cod = codigoPudo(tr);
      const td = document.createElement('td');
      td.className = 'tf-pudo-td';
      td.setAttribute('role', 'gridcell');
      if (cod) {
        const inp = document.createElement('input');
        inp.type = 'text'; inp.className = 'tf-pudo-mot'; inp.maxLength = 40;
        inp.setAttribute('list', 'tf-pudo-nomes');
        inp.placeholder = 'motorista';
        inp.value = nomes[cod] || '';
        inp.title = 'Motorista do PUDO ' + cod;
        // O clique no campo não seleciona a linha da tabela.
        ['click', 'mousedown', 'keydown', 'keyup', 'keypress'].forEach(t => inp.addEventListener(t, ev => ev.stopPropagation()));
        inp.addEventListener('keydown', ev => { if (ev.key === 'Enter') { ev.preventDefault(); inp.blur(); } });
        inp.addEventListener('input', () => {
          const v = inp.value.toUpperCase();
          if (inp.value !== v) { const p = inp.selectionStart; inp.value = v; inp.setSelectionRange(p, p); }
          if (v.trim()) nomes[cod] = v.trim(); else delete nomes[cod];
          gravar();
        });
        inp.addEventListener('change', listaSugestoes);
        td.appendChild(inp);
      }
      tr.appendChild(td);
    });
  }

  chrome.storage.local.get(CHAVE).then(v => {
    nomes = v[CHAVE] || {};
    pronto = true;
    listaSugestoes();
    aplicar();
  }).catch(() => { pronto = true; aplicar(); });

  // Outra aba mudou os nomes: atualiza os campos que não estão sendo editados.
  chrome.storage.onChanged.addListener((mud, area) => {
    if (area !== 'local' || !mud[CHAVE]) return;
    nomes = mud[CHAVE].newValue || {};
    document.querySelectorAll('#' + CSS.escape(TABELA) + ' .tf-pudo-mot').forEach(inp => {
      if (document.activeElement === inp) return;
      const cod = codigoPudo(inp.closest('tr'));
      inp.value = nomes[cod] || '';
    });
    listaSugestoes();
  });

  let ag = 0;
  new MutationObserver(() => { if (!ag) ag = requestAnimationFrame(() => { ag = 0; aplicar(); }); })
    .observe(document.body, { childList: true, subtree: true });
})();
