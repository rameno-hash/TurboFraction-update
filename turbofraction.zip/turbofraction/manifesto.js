/*
 * TurboFraction — Envio de Remessa (/FractionWeb/pages/envioRemessa/envio.jad)
 * Aberta pelo link do manifesto na consulta da remessa: preenche o número na janela "Imprimir Envio de
 * Remessa" e clica em Enviar. O relatório abre nesta mesma aba (não em janela pop-up).
 */
(() => {
  'use strict';
  const esperar = ms => new Promise(r => setTimeout(r, ms));
  function aviso(msg, erro) {
    let d = document.getElementById('tf-man-aviso');
    if (!d) { d = document.createElement('div'); d.id = 'tf-man-aviso'; document.body.appendChild(d); }
    d.style.cssText = 'position:fixed;top:14px;left:50%;transform:translateX(-50%);z-index:99999;padding:10px 18px;border-radius:6px;color:#fff;font:bold 13px Arial,sans-serif;box-shadow:0 3px 12px rgba(0,0,0,.3);background:' + (erro ? '#C8102E' : '#1d7a35');
    d.textContent = msg;
  }
  async function reimprimir() {
    let ped;
    try { ped = (await chrome.storage.local.get('tf_imprimir_manifesto')).tf_imprimir_manifesto; } catch (e) { return; }
    if (!ped || Date.now() - ped.t > 120000) return;
    chrome.storage.local.remove('tf_imprimir_manifesto');
    let campo = null;
    for (let i = 0; i < 40 && !campo; i++) { campo = document.getElementById('form_imp_env_rem:id_manifesto'); if (!campo) await esperar(250); }
    const form = document.getElementById('form_imp_env_rem');
    const enviar = document.getElementById('form_imp_env_rem:botao_imp_env_rem');
    if (!campo || !form || !enviar) { aviso('Não encontrei a janela Imprimir desta tela para o manifesto ' + ped.n + '.', true); return; }
    aviso('Abrindo o manifesto ' + ped.n + ' para impressão…');
    campo.value = ped.n;
    campo.dispatchEvent(new Event('change', { bubbles: true }));   // validação do próprio site
    await esperar(1500);
    // Sem pop-up: o relatório abre nesta aba.
    form.target = '_self';
    enviar.click();
  }
  setTimeout(reimprimir, 300);
})();
