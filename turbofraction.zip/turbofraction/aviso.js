/*
 * TurboFraction — aviso de nova versão nas telas do Fraction.
 * O service worker consulta o versao.json publicado no GitHub; se houver versão mais nova,
 * aparece uma faixa no topo com o link do .zip. "Depois" esconde o aviso até o dia seguinte.
 */
(() => {
  'use strict';
  if (window.top !== window || !chrome?.storage?.local) return;

  const atual = chrome.runtime.getManifest().version;
  const maior = (a, b) => {
    const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number);
    for (let i = 0; i < Math.max(x.length, y.length); i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); }
    return false;
  };
  const hoje = new Date().toISOString().slice(0, 10);

  chrome.storage.local.get(['tf_atualizacao', 'tf_aviso_adiado']).then(v => {
    const nova = v.tf_atualizacao;
    if (!nova || !nova.versao || !maior(nova.versao, atual)) return;
    const adiado = v.tf_aviso_adiado || {};
    if (adiado.versao === nova.versao && adiado.dia === hoje) return;

    const faixa = document.createElement('div');
    faixa.id = 'tf-aviso-versao';
    faixa.setAttribute('role', 'status');
    faixa.style.cssText = 'position:fixed;top:0;left:0;right:0;z-index:2147483646;display:flex;align-items:center;gap:12px;' +
      'justify-content:center;flex-wrap:wrap;padding:8px 14px;background:#C8102E;color:#fff;font:13px Arial,sans-serif;box-shadow:0 2px 8px rgba(0,0,0,.25)';
    const texto = document.createElement('span');
    texto.innerHTML = '🔔 <b></b> disponível — você está usando a <span></span>.';
    texto.querySelector('b').textContent = 'TurboFraction ' + nova.versao;
    texto.querySelector('span').textContent = atual;
    const botao = (rotulo, estilo) => {
      const b = document.createElement('a');
      b.textContent = rotulo;
      b.style.cssText = 'padding:4px 12px;border-radius:4px;font-weight:bold;cursor:pointer;text-decoration:none;' + estilo;
      return b;
    };
    const baixar = botao('⬇ Baixar atualização', 'background:#fff;color:#C8102E');
    baixar.href = nova.download; baixar.target = '_blank'; baixar.rel = 'noopener';
    const como = botao('Como atualizar', 'color:#fff;text-decoration:underline;font-weight:normal');
    como.title = '1) Descompacte o .zip baixado no lugar da pasta "turbofraction" (substituindo os arquivos).\n' +
      '2) Abra chrome://extensions e clique no ↻ da TurboFraction.\n3) Recarregue o Fraction (F5).';
    como.addEventListener('click', () => alert(como.title));
    const depois = botao('Depois', 'color:#fff;border:1px solid rgba(255,255,255,.7)');
    depois.addEventListener('click', () => {
      chrome.storage.local.set({ tf_aviso_adiado: { versao: nova.versao, dia: hoje } });
      faixa.remove();
    });
    faixa.append(texto, baixar, como, depois);
    if (nova.notas && nova.notas.length) faixa.title = 'Novidades:\n• ' + [].concat(nova.notas).join('\n• ');
    document.body.appendChild(faixa);
  }).catch(() => {});
})();
