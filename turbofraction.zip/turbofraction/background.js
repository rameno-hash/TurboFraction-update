// TurboFraction — service worker
// O Fraction redireciona /FractionWeb/jad/consulta para um endereço http://, que o Chrome
// bloqueia dentro de uma página https. Aqui só observamos esse redirecionamento (não alteramos
// nada) para a página poder abrir a mesma chave de fluxo via https.

const CHAVE = 'ultimoRedirecionamentoConsulta';

chrome.webRequest.onBeforeRedirect.addListener(
  det => {
    if (/\/FractionWeb\/jad\/consulta\?execution=/.test(det.redirectUrl)) {
      chrome.storage.session.set({ [CHAVE]: { url: det.redirectUrl, quando: Date.now(), aba: det.tabId } });
    }
  },
  { urls: ['*://*.jadlog.com.br/FractionWeb/jad/consulta*', '*://*.jadlog.com/FractionWeb/jad/consulta*'] }
);

// Quantas abas da tela Envio de Remessa estão abertas (aviso antes de reimprimir manifesto por trás).
chrome.runtime.onMessage.addListener((msg, remetente, responder) => {
  if (!msg || msg.tipo !== 'abasEnvio') return;
  chrome.tabs.query({ url: ['*://*.jadlog.com.br/FractionWeb/pages/envioRemessa/*', '*://*.jadlog.com/FractionWeb/pages/envioRemessa/*'] })
    .then(t => responder({ n: t.length })).catch(() => responder({ n: 0 }));
  return true;
});

chrome.runtime.onMessage.addListener((msg, remetente, responder) => {
  if (msg && msg.tipo === CHAVE) {
    chrome.storage.session.get(CHAVE).then(v => {
      const r = v[CHAVE];
      const daAba = !remetente.tab || r?.aba === remetente.tab.id || r?.aba === -1;
      responder(r && r.quando >= (msg.desde || 0) - 500 && daAba ? { url: r.url } : {});
    });
    return true; // resposta assíncrona
  }
});

// Páginas de impressão da extensão: guardam os dados e abrem numa aba nova.
const PAGINAS = { abrirAcareacao: 'acareacao.html', abrirEtiqueta: 'etiqueta.html', abrirEtiquetaTexto: 'etiqueta-texto.html' };
chrome.runtime.onMessage.addListener((msg) => {
  const pagina = msg && PAGINAS[msg.tipo];
  if (pagina) {
    const id = 'p_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8);
    chrome.storage.session.set({ [id]: msg.dados || {} }).then(() => {
      chrome.tabs.create({ url: chrome.runtime.getURL(pagina + '#' + id) });
    });
  }
});

/* ---------- Verificação de nova versão (GitHub) ---------- */
// Publicação: o arquivo versao.json no repositório público abaixo diz qual é a versão mais nova e onde baixar.
const URL_VERSAO = 'https://raw.githubusercontent.com/rameno-hash/TurboFraction-update/main/versao.json';

function versaoMaior(a, b) {
  const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number);
  for (let i = 0; i < Math.max(x.length, y.length); i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); }
  return false;
}

// Instalada pela Chrome Web Store (o manifesto ganha update_url): a loja cuida das atualizações.
const DA_LOJA = 'update_url' in chrome.runtime.getManifest();

async function verificarAtualizacao() {
  if (DA_LOJA) return { loja: true, nova: null };
  try {
    const r = await fetch(URL_VERSAO + '?t=' + Date.now(), { cache: 'no-store' });
    if (!r.ok) return { erro: true };
    const info = await r.json();
    const atual = chrome.runtime.getManifest().version;
    if (info && info.versao && versaoMaior(info.versao, atual)) {
      await chrome.storage.local.set({ tf_atualizacao: { versao: info.versao, download: info.download, notas: info.notas || [], visto: Date.now() } });
      chrome.action.setBadgeBackgroundColor({ color: '#C8102E' });
      chrome.action.setBadgeText({ text: 'NOVA' });
      chrome.action.setTitle({ title: `TurboFraction ${info.versao} disponível (você usa a ${atual})` });
      return { nova: { versao: info.versao, download: info.download, notas: info.notas || [] } };
    } else {
      await chrome.storage.local.remove('tf_atualizacao');
      chrome.action.setBadgeText({ text: '' });
      chrome.action.setTitle({ title: 'TurboFraction — clique para verificar atualização' });
      return { nova: null };
    }
  } catch (e) { /* sem internet: tenta de novo mais tarde */ return { erro: true }; }
}

// Clique no ícone (janela popup.html): verificação na hora.
chrome.runtime.onMessage.addListener((msg, remetente, responder) => {
  if (msg && msg.tipo === 'verificarAgora') { verificarAtualizacao().then(responder); return true; }
});

chrome.runtime.onInstalled.addListener(() => { chrome.alarms.create('tf-versao', { periodInMinutes: 360 }); verificarAtualizacao(); });
chrome.runtime.onStartup.addListener(verificarAtualizacao);
chrome.alarms.onAlarm.addListener(a => { if (a.name === 'tf-versao') verificarAtualizacao(); });
